#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include "bib.h"
#include "callbacks.h"
#include "interface.h"
#include "support.h"
GtkWidget *espagent;
GtkWidget *prfilagent;
GtkWidget *modifprofilagent;
GtkWidget *reclamationagent;
GtkWidget *reclamationrecuagent;
GtkWidget *reclamationenvoiagent;
GtkWidget *horairetravailagent;
GtkWidget *succreclagent;
GtkWidget *failreclagent;



void
on_prfilagent_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
id A;

char chemin[]="listeagent.txt";
GtkWidget *prfilagent;
prfilagent=create_prfilagent();
gtk_widget_show(prfilagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"espagent")));
GtkWidget *labelnom;
GtkWidget *labelprenom;
GtkWidget *labelCIN;
GtkWidget *labeljour;
GtkWidget *labelmois;
GtkWidget *labelannee;
GtkWidget *labeladress;
GtkWidget *labelnum;
GtkWidget *labelpass;
GtkWidget *labelrole;
int i=1;
FILE*f;
f=fopen(chemin,"a+");
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %d\n",A.cin,A.nom,A.prenom,A.jour,A.mois,A.annee,A.adress,A.num,A.pass,&A.role)!=EOF)
{

}
labelnom=lookup_widget(prfilagent,"nomagent");
labelprenom=lookup_widget(prfilagent,"prenomagent");
labeljour=lookup_widget(prfilagent,"jouragent");
labelmois=lookup_widget(prfilagent,"moisagent");
labelannee=lookup_widget(prfilagent,"anneeagent");
labeladress=lookup_widget(prfilagent,"adressagent");
labelnum=lookup_widget(prfilagent,"phoneagent");
labelCIN=lookup_widget(prfilagent,"CINagent");
labelpass=lookup_widget(prfilagent,"passagent");

gtk_label_set_text(GTK_LABEL(labelnom),A.nom);
gtk_label_set_text(GTK_LABEL(labelprenom),A.prenom);
gtk_label_set_text(GTK_LABEL(labelCIN),A.cin);
gtk_label_set_text(GTK_LABEL(labeljour),A.jour);
gtk_label_set_text(GTK_LABEL(labelmois),A.mois);
gtk_label_set_text(GTK_LABEL(labelannee),A.annee);
gtk_label_set_text(GTK_LABEL(labeladress),A.adress);
gtk_label_set_text(GTK_LABEL(labelnum),A.num);
gtk_label_set_text(GTK_LABEL(labelpass),A.pass);
fclose(f);

}



void
on_reclagent_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *reclamationagent;
reclamationagent=create_reclamationagent();
gtk_widget_show(reclamationagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"espagent")));
}


void
on_horairetravailagent_clicked         (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *horairetravailagent;
horairetravailagent=create_horairetravailagent();
gtk_widget_show(horairetravailagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"espagent")));
}


void
on_exit2_clicked                       (GtkWidget      *button,
                                        gpointer         user_data)
{
gtk_main_quit();
}


void
on_modifprfilagent_clicked             (GtkWidget      *button,
                                        gpointer         user_data)
{

id A;
char chemin[]="listeagent.txt";

GtkWidget *modifprofilagent;
modifprofilagent=create_modifprofilagent();
gtk_widget_show(modifprofilagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"prfilagent")));
int i=1;

FILE*f;
f=fopen(chemin,"a+");

while(fscanf(f,"%s %s %s %s %s %s %s %s %s %d\n",A.cin,A.nom,A.prenom,A.jour,A.mois,A.annee,A.adress,A.num,A.pass,&A.role)!=EOF)
{i++;
}
GtkWidget *labelnom;
GtkWidget *labelprenom;
GtkWidget *labelCIN;
GtkWidget *labeljour;
GtkWidget *labelmois;
GtkWidget *labelannee;
GtkWidget *labeladress;
GtkWidget *labelnum;
GtkWidget *labelpass;
GtkWidget *labelrole;

labelnom=lookup_widget(modifprofilagent,"nomagent");
labelprenom=lookup_widget(modifprofilagent,"prenomagent");
labeljour=lookup_widget(modifprofilagent,"jouragent");
labelmois=lookup_widget(modifprofilagent,"moisagent");
labelannee=lookup_widget(modifprofilagent,"anneeagent");
labeladress=lookup_widget(modifprofilagent,"entryadressagent");
labelnum=lookup_widget(modifprofilagent,"entrynumagent");
labelCIN=lookup_widget(modifprofilagent,"CINagent");
labelpass=lookup_widget(modifprofilagent,"entrypassagent");

gtk_label_set_text(GTK_LABEL(labelnom),A.nom);
gtk_label_set_text(GTK_LABEL(labelprenom),A.prenom);
gtk_label_set_text(GTK_LABEL(labelCIN),A.cin);
gtk_label_set_text(GTK_LABEL(labeljour),A.jour);
gtk_label_set_text(GTK_LABEL(labelmois),A.mois);
gtk_label_set_text(GTK_LABEL(labelannee),A.annee);
gtk_entry_set_text(GTK_ENTRY(labeladress),A.adress);
gtk_entry_set_text(GTK_ENTRY(labelnum),A.num);
gtk_entry_set_text(GTK_ENTRY(labelpass),A.pass);

fclose(f);


}


void
on_retrnespagent1_clicked              (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *espagent;
espagent=create_espagent();
gtk_widget_show(espagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"prfilagent")));
}


void
on_retrnprfilagent_clicked             (GtkWidget      *button,
                                        gpointer         user_data)
{

id A;

char chemin[]="listeagent.txt";
GtkWidget *prfilagent;

prfilagent=create_prfilagent();
gtk_widget_show(prfilagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"modifprofilagent")));
GtkWidget *labelnom;
GtkWidget *labelprenom;
GtkWidget *labelCIN;
GtkWidget *labeljour;
GtkWidget *labelmois;
GtkWidget *labelannee;
GtkWidget *labeladress;
GtkWidget *labelnum;
GtkWidget *labelpass;
GtkWidget *labelrole;
int i=1;
FILE*f;
f=fopen(chemin,"a+");
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %d\n",A.cin,A.nom,A.prenom,A.jour,A.mois,A.annee,A.adress,A.num,A.pass,&A.role)!=EOF)
{

}
labelnom=lookup_widget(prfilagent,"nomagent");
labelprenom=lookup_widget(prfilagent,"prenomagent");
labeljour=lookup_widget(prfilagent,"jouragent");
labelmois=lookup_widget(prfilagent,"moisagent");
labelannee=lookup_widget(prfilagent,"anneeagent");
labeladress=lookup_widget(prfilagent,"adressagent");
labelnum=lookup_widget(prfilagent,"phoneagent");
labelCIN=lookup_widget(prfilagent,"CINagent");
labelpass=lookup_widget(prfilagent,"passagent");

gtk_label_set_text(GTK_LABEL(labelnom),A.nom);
gtk_label_set_text(GTK_LABEL(labelprenom),A.prenom);
gtk_label_set_text(GTK_LABEL(labelCIN),A.cin);
gtk_label_set_text(GTK_LABEL(labeljour),A.jour);
gtk_label_set_text(GTK_LABEL(labelmois),A.mois);
gtk_label_set_text(GTK_LABEL(labelannee),A.annee);
gtk_label_set_text(GTK_LABEL(labeladress),A.adress);
gtk_label_set_text(GTK_LABEL(labelnum),A.num);
gtk_label_set_text(GTK_LABEL(labelpass),A.pass);
fclose(f);

}



void
on_saveagent_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
id A;

char chemin[]="listeagent.txt";
GtkWidget *espagent;
espagent=create_espagent();
gtk_widget_show(espagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"modifprofilagent")));
GtkWidget *labelnom;
GtkWidget *labelprenom;
GtkWidget *labelCIN;
GtkWidget *labeljour;
GtkWidget *labelmois;
GtkWidget *labelannee;
GtkWidget *labeladress;
GtkWidget *labelnum;
GtkWidget *labelpass;
GtkWidget *labelrole;
int i=1;

labelnom=lookup_widget(button,"nomagent");
labelprenom=lookup_widget(button,"prenomagent");
labeljour=lookup_widget(button,"jouragent");
labelmois=lookup_widget(button,"moisagent");
labelannee=lookup_widget(button,"anneeagent");
labeladress=lookup_widget(button,"entryadressagent");
labelnum=lookup_widget(button,"entrynumagent");
labelCIN=lookup_widget(button,"CINagent");
labelpass=lookup_widget(button,"entrypassagent");

strcpy(A.nom,gtk_label_get_text(GTK_LABEL(labelnom)));
strcpy(A.prenom,gtk_label_get_text(GTK_LABEL(labelprenom)));
strcpy(A.cin,gtk_label_get_text(GTK_LABEL(labelCIN)));
strcpy(A.jour,gtk_label_get_text(GTK_LABEL(labeljour)));
strcpy(A.mois,gtk_label_get_text(GTK_LABEL(labelmois)));
strcpy(A.annee,gtk_label_get_text(GTK_LABEL(labelannee)));
strcpy(A.adress,gtk_entry_get_text(GTK_ENTRY(labeladress)));
strcpy(A.num,gtk_entry_get_text(GTK_ENTRY(labelnum)));
strcpy(A.pass,gtk_entry_get_text(GTK_ENTRY(labelpass)));
FILE*f;
f=fopen(chemin,"a+");
fprintf(f,"%s %s %s %s %s %s %s %s %s 6 \n",A.cin,A.nom,A.prenom,A.jour,A.mois,A.annee,A.adress,A.num,A.pass);
fclose(f);
}



void
on_reclmtionagentenvoi_clicked         (GtkWidget       *button,
                                        gpointer         user_data)

{
GtkWidget *reclamationenvoiagent;
reclamationenvoiagent=create_reclamationenvoiagent();
gtk_widget_show(reclamationenvoiagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationagent")));
}




void
on_reclmtionagentrecu_clicked          (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *reclamationrecuagent;
reclamationrecuagent=create_reclamationrecuagent();
gtk_widget_show(reclamationrecuagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationagent")));
int i=1;
char chemin[]="recla_agent.txt";
GtkWidget *labelrecu;
char cont[300];
FILE*f;
f=fopen(chemin,"a+");
while(fscanf(f,"%s \n",cont)!=EOF)
{
i++;
}
labelrecu=lookup_widget(reclamationrecuagent,"reclagentrecu");
gtk_label_set_text(GTK_LABEL(labelrecu),cont);
fclose(f);

}


void
on_retrnespagent2_clicked              (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *espagent;
espagent=create_espagent();
gtk_widget_show(espagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationagent")));
}


void
on_retrnreclagent1_clicked             (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *reclamationagent;
reclamationagent=create_reclamationagent();
gtk_widget_show(reclamationagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationrecuagent")));
}


void
on_retrnreclagent2_clicked             (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *reclamationagent;
reclamationagent=create_reclamationagent();
gtk_widget_show(reclamationagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationenvoiagent")));
}



void
on_okbuttonagent_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{
char jour[20],de[20],a[20];
GtkWidget *inputjour;
GtkWidget *inputde;
GtkWidget *inputa;
char chemin[]="horairetravailagent.txt";
inputjour=lookup_widget(button,"comboboxentryjour");
strcpy(jour,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputjour)));
inputde=lookup_widget(button,"comboboxentrycommence");
strcpy(de,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputde)));
inputa=lookup_widget(button,"comboboxentryfini");
strcpy(a,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputa)));
FILE*f;
f=fopen(chemin,"a+");
fprintf(f,"%s %s %s\n",jour,de,a);
fclose(f);

}


void
on_retrnespagent4_clicked              (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *espagent;
espagent=create_espagent();
gtk_widget_show(espagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"horairetravailagent")));
}


void
on_envoireclagent_clicked              (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *inputreclama;
GtkWidget *inputdest;
char dest[40],cont[100];
inputreclama=lookup_widget(button,"comboboxentryenvoi");
strcpy(dest,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputreclama)));
inputdest=lookup_widget(button,"entrycontenuagent");
strcpy(cont,gtk_entry_get_text(GTK_ENTRY(inputdest)));
if (strcmp(dest,"Agent de Nétoyage")==0)
{
FILE *f1;
f1=fopen("recla_agent.txt","a+");
fprintf(f1,"%s \n",cont);
fclose(f1);
}
else if (strcmp(dest,"Coach")==0)
{
FILE *f2;
f2=fopen("recla_coach.txt","a+");
fprintf(f2,"%s \n",cont);
fclose(f2);
}
else if (strcmp(dest,"Kinésithérapeute")==0)
{
FILE *f3;
f3=fopen("recla_kine.txt","a+");
fprintf(f3,"%s \n",cont);
fclose(f3);
}
else if (strcmp(dest,"Diététicien")==0)
{
FILE *f4;
f4=fopen("recla_diet.txt","a+");
fprintf(f4,"%s \n",cont);
fclose(f4);
}
else if (strcmp(dest,"Médecin Nutritioniste")==0)
{
FILE *f5;
f5=fopen("recla_docteur.txt","a+");
fprintf(f5,"%s \n",cont);
fclose(f5);
}
if (cont != " " && dest != " ")
{
GtkWidget *succreclagent;
succreclagent=create_succreclagent();
gtk_widget_show(succreclagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationenvoiagent")));
}
else
{
GtkWidget *failreclagent;
failreclagent=create_failreclagent();
gtk_widget_show(failreclagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationenvoiagent")));
}
}

void
on_retrnreclagent3_clicked             (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *reclamationagent;
reclamationagent=create_reclamationagent();
gtk_widget_show(reclamationagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"succreclagent")));
}


void
on_retrnreclagent4_clicked             (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *reclamationagent;
reclamationagent=create_reclamationagent();
gtk_widget_show(reclamationagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"failreclagent")));
}

