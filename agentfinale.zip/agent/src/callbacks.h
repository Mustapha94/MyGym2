#include <gtk/gtk.h>


void
on_prfilagent_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_reclagent_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_horairetravailagent_clicked         (GtkWidget      *button,
                                        gpointer         user_data);

void
on_exit2_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_modifprfilagent_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnespagent1_clicked              (GtkWidget      *button,
                                        gpointer         user_data);

void
on_retrnprfilagent_clicked             (GtkWidget      *button,
                                        gpointer         user_data);

void
on_saveagent_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_reclmtionagentenvoi_clicked         (GtkWidget       *button,
                                        gpointer         user_data);

void
on_reclmtionagentrecu_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnespagent2_clicked              (GtkWidget      *button,
                                        gpointer         user_data);

void
on_retrnreclagent1_clicked             (GtkWidget      *button,
                                        gpointer         user_data);

void
on_retrnreclagent2_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_okbuttonagent_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnespagent4_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnreclagent3_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnreclagent4_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_envoireclagent_clicked              (GtkWidget      *button,
                                        gpointer         user_data);

void
on_envoireclagent_clicked              (GtkWidget      *button,
                                        gpointer         user_data);



