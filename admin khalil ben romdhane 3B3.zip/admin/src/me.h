#include <gtk/gtk.h>

typedef struct
{
char cin[30];
char nom[30];
char prenom[30];
char login[100];
char mot[30];
char adresse[30];
char mail[30];
char num[30];
int jour;
int mois;
int annee;
}Personne;

void ajouterpersonne( Personne p);
void afficherpersonne(GtkWidget *liste);


