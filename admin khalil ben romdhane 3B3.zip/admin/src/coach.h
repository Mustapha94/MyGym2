#include <gtk/gtk.h>

struct Coach
{
char cin[30];
char nom[30];
char prenom[30];
char login[100];
char mot[30];
char adresse[30];
char mail[30];
char num[30];
char sp[30];
int jour;
int mois;
int annee;
};
typedef struct Coach coach;

void ajoutercoach(coach c);
int verif_coach(char x[]);
coach chercher_coach(char x[]);
 void supprimer_coach(char id[30]);
void modifier_coach(coach n);
