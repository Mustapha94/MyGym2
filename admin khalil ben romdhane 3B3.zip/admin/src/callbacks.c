#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonctions.h"

GtkWidget *menu_admin;
GtkWidget *gestion_page_d_accueil;
GtkWidget *statistique_admin;
GtkWidget *planning_des_horraires_de_travail;
GtkWidget *gestion_abonnement_factures;
GtkWidget *reclamation_admin;
GtkWidget *liste_deals;
GtkWidget *Affichage_du_deal;
GtkWidget *Ajouter_deal;
GtkWidget *Liste_event;
GtkWidget *Affichage_event;
GtkWidget *Ajouter_event;
GtkWidget *Info_coord_actuel_admin;
GtkWidget *modifier_info_coord_admin;
GtkWidget *afficher_taux_pres_adh_seance_admin;
GtkWidget *page_d_accueil_admin1;
GtkWidget *page_accueil_admin;
GtkWidget *Authentification_admin;
GtkWidget *espace_coach;
GtkWidget *espace_adherent;
GtkWidget *espace_medecin;
GtkWidget *espace_kine;
GtkWidget *espace_agent;
GtkWidget *espace_diet;

//mariem

#include "me.h"
#include "diet.h"
#include "nut.h"
#include "coach.h"
#include "rec.h"
#include "kine.h"
#include "treeviewm.h"
GtkWidget *nutaman;
GtkWidget *ajoutnut;
GtkWidget *infonut;
GtkWidget *treeviewnut;
GtkWidget *dietchercher;
GtkWidget *infodiet;
GtkWidget *comptediet;
GtkWidget *treeviewcdiet;
GtkWidget *comptekineaman;
GtkWidget *comptekine;
GtkWidget *kineinfo;
GtkWidget *treeviewcomptekine;
GtkWidget *reclammation;
GtkWidget *treeviewrecl;
GtkWidget *compte;
GtkWidget *trei;
GtkWidget *info;
GtkWidget  *lesplane;
GtkWidget  *Gestioncomptecoach;
GtkWidget  *editeprofildescoach;
GtkWidget  *coachrechercher;
GtkWidget *treeviewcomptecoach;
GtkWidget *listedesplanningdescoach;
GtkWidget *treeviewcoachp;
GtkWidget *treeviewpkine;
GtkWidget *listeplaningkine;
GtkWidget *listeplaningnut;
GtkWidget *treeviewpnut;
GtkWidget *treeviewpagent;
GtkWidget *listeplaningagent;
GtkWidget *treeviewplaningdiet;
GtkWidget *listeplaningdiet;

//mariem

void
on_button_info_coord_admin_clicked                    (GtkWidget      *button,
                                        gpointer         user_data)
{
gestion_page_d_accueil=lookup_widget(button,"gestion_page_d_accueil");
gtk_widget_destroy(gestion_page_d_accueil);
Info_coord_actuel_admin=lookup_widget(button,"Info_coord_actuel_admin");
Info_coord_actuel_admin=create_Info_coord_actuel_admin();
gtk_widget_show(Info_coord_actuel_admin);

FILE *f1;
char nom3[20];
char horraire3[50];
char tel3[50];
char email3[30];
char adresse3[40];

GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;

f1=fopen("info_coord.txt","a+");
if(f1!=NULL)
	
	{
		if(fscanf(f1,"%s %s %s %s %s \n",nom3,horraire3,tel3,email3,adresse3)!=EOF);
	output1=lookup_widget(Info_coord_actuel_admin,"labelkhalil1");
	gtk_label_set_text(GTK_LABEL(output1),nom3);
	output2=lookup_widget(Info_coord_actuel_admin,"labelkhalil2");
	gtk_label_set_text(GTK_LABEL(output2),horraire3);
	output3=lookup_widget(Info_coord_actuel_admin,"labelkhalil3");
	gtk_label_set_text(GTK_LABEL(output3),tel3);
	output4=lookup_widget(Info_coord_actuel_admin,"labelkhalil4");
	gtk_label_set_text(GTK_LABEL(output4),email3);
	output5=lookup_widget(Info_coord_actuel_admin,"labelkhalil5");
	gtk_label_set_text(GTK_LABEL(output5),adresse3);
	}
fclose(f1);
                     
}

void
on_button_event_admin_clicked                    (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
Evenement e;

gestion_page_d_accueil=lookup_widget(button,"gestion_page_d_accueil");
gtk_widget_destroy(gestion_page_d_accueil);
Liste_event=lookup_widget(button,"Liste_event");
Liste_event=create_Liste_event();
gtk_widget_show(Liste_event);

treeview1=lookup_widget(Liste_event,"treeview_liste_des_event_admin");
afficher_event(treeview1);
}

void
on_button_afficher_deal_choisi_admin_clicked                    (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *input;
char s[30];
input=lookup_widget(liste_deals,"entry_nom_deal_afficher_admin");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(input)));

liste_deals=lookup_widget(button,"liste_deals");
gtk_widget_destroy(liste_deals);
Affichage_du_deal=lookup_widget(button,"Affichage_du_deal");
Affichage_du_deal=create_Affichage_du_deal();
gtk_widget_show(Affichage_du_deal); 
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget *input6;

FILE *f;
Deal d;
	f=fopen("liste_desdeals.txt","r");
	if(f!=NULL)
	{
	while (fscanf(f,"%s %s %s %s %s 	\n",d.nom,d.date_debut,d.date_fin,d.prix,d.description)!=EOF)
	{if (strcmp(d.nom,s)==0)
{input1=lookup_widget(Affichage_du_deal,"entry_nom_deal_affichage_deal");     
gtk_entry_set_text(GTK_ENTRY(input1),d.nom);

input6=lookup_widget(Affichage_du_deal,"label_nom_du_deal_a_modifier_admin");
gtk_label_set_text(GTK_LABEL(input6),d.nom);

input2=lookup_widget(Affichage_du_deal,"entry_date_debut_affichage_deal");     
gtk_entry_set_text(GTK_ENTRY(input2),d.date_debut);
input3=lookup_widget(Affichage_du_deal,"entry_date_fin_affichage_deal");     
gtk_entry_set_text(GTK_ENTRY(input3),d.date_fin);
input4=lookup_widget(Affichage_du_deal,"entry_prix_affichage_deal");     
gtk_entry_set_text(GTK_ENTRY(input4),d.prix);
input5=lookup_widget(Affichage_du_deal,"entry_description_affichage_deal");     
gtk_entry_set_text(GTK_ENTRY(input5),d.description);}}
fclose(f);}
}


void
on_button_gestion_cp_utilisateur_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
compte=create_compte();
gtk_widget_show(compte);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"menu_admin")));

}


void
on_button_page_accueil_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
gestion_page_d_accueil=create_gestion_page_d_accueil();
gtk_widget_show(gestion_page_d_accueil);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"menu_admin")));

}



void
on_button_statistiques_admin_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
statistique_admin=create_statistique_admin();
gtk_widget_show(statistique_admin);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"menu_admin")));

GtkWidget *output;
GtkWidget *output1;
GtkWidget *treeview1;
GtkWidget *treeview2;
GtkWidget *treeview3;
GtkWidget *treeview4;
FILE *f;FILE *f1;
char s[30],s1[30],s2[30],s3[30],s4[30];
int rdv=0;
char rdv1[400];
int nb_s=0;
char nb_s1[400];

f=fopen("rendez_vous_coach.txt","r");
while(fscanf(f,"%s %s %s %s %s \n",s,s1,s2,s3,s4)!=EOF)
{rdv++;}
fclose(f);
f=fopen("rendez_vous_kine.txt","r");
while(fscanf(f,"%s %s %s %s %s \n",s,s1,s2,s3,s4)!=EOF)
{rdv++;}
fclose(f);
f=fopen("rendez_vous_medecin.txt","r");
while(fscanf(f,"%s %s %s %s %s \n",s,s1,s2,s3,s4)!=EOF)
{rdv++;}
fclose(f);
sprintf(rdv1,"%d",rdv);
output=lookup_widget(statistique_admin,"entry_nb_rdv_semaine_admin");
gtk_entry_set_text(GTK_ENTRY(output),rdv1);

f=fopen("nbseance_coach.txt","r");
while(fscanf(f,"%s %s %s %s %s \n",s,s1,s2,s3,s4)!=EOF)
{nb_s++;}
fclose(f);
f=fopen("nbseance_kine.txt","r");
while(fscanf(f,"%s %s %s %s %s \n",s,s1,s2,s3,s4)!=EOF)
{nb_s++;}
fclose(f);
f=fopen("nbseance_medecin.txt","r");
while(fscanf(f,"%s %s %s %s %s \n",s,s1,s2,s3,s4)!=EOF)
{nb_s++;}
fclose(f);
sprintf(nb_s1,"%d",nb_s);
output1=lookup_widget(statistique_admin,"entry_nb_seance_semaine_admin");
gtk_entry_set_text(GTK_ENTRY(output1),nb_s1);

treeview1=lookup_widget(statistique_admin,"treeview1_avis_salle_admin");
afficher_avissalle(treeview1);

treeview2=lookup_widget(statistique_admin,"treeview2_avis_coach_admin");
afficher_aviscoach(treeview2);

treeview3=lookup_widget(statistique_admin,"treeview4_avis_medecin");
afficher_avismedecin(treeview3);

treeview4=lookup_widget(statistique_admin,"treeview3_avis_kine_admin");
afficher_aviskine(treeview4);


}


void
on_button_planning_h_travail_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
lesplane=create_lesplane();
gtk_widget_show(lesplane);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"menu_admin")));

}

void
on_button_gestion_abonnements_factures_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
GtkWidget *treeview2;
GtkWidget *treeview3;
GtkWidget *treeview4;
GtkWidget *treeview5;

gestion_abonnement_factures=create_gestion_abonnement_factures();
gtk_widget_show(gestion_abonnement_factures);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"menu_admin")));

treeview1=lookup_widget(gestion_abonnement_factures,"treeview_liste_abonnement_admin");
afficher_abonnement_adherent(treeview1);

treeview2=lookup_widget(gestion_abonnement_factures,"treeview_liste_facture_coach_admin");
afficher_facture_coach(treeview2);

treeview3=lookup_widget(gestion_abonnement_factures,"treeview_liste_facture_medecin_admin");
afficher_facture_medecin(treeview3);

treeview4=lookup_widget(gestion_abonnement_factures,"treeview_liste_facture_kine_admin");
afficher_facture_kine(treeview4);

treeview5=lookup_widget(gestion_abonnement_factures,"treeview_liste_facture_agent_admin");
afficher_facture_agent(treeview5);

}


void
on_button_reclamation_admin_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
menu_admin=lookup_widget(button,"menu_admin");
gtk_widget_destroy(menu_admin);
reclammation=lookup_widget(button,"reclammation");
reclammation=create_reclammation();

gtk_widget_show(reclammation);
      

treeviewrecl=lookup_widget(reclammation,"treeviewrecl");

afficherreclamcoach(treeviewrecl);

}


void
on_button_deco_admin_clicked                        (GtkWidget      *button,
                                        gpointer         user_data)
{
page_d_accueil_admin1=create_page_d_accueil_admin1();
gtk_widget_show(page_d_accueil_admin1);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"menu_admin")));

GtkWidget *output;
GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;
GtkWidget *output6;
GtkWidget *output7;
GtkWidget *output8;
GtkWidget *output9;
GtkWidget *output10;
GtkWidget *output11;
FILE *f;FILE *f1; FILE *f2;
char s[30],s1[30],s2[30],s3[30],s4[30];

f=fopen("info_coord.txt","r");
while(fscanf(f,"%s %s %s %s %s \n",s,s1,s2,s3,s4)!=EOF)
output=lookup_widget(page_d_accueil_admin1,"label_nom_salle_page_accueil");
gtk_label_set_text(GTK_LABEL(output),s);
output1=lookup_widget(page_d_accueil_admin1,"label_tel_salle_page_accueil");
gtk_label_set_text(GTK_LABEL(output1),s2);
output2=lookup_widget(page_d_accueil_admin1,"label_email_salle_page_accueil");
gtk_label_set_text(GTK_LABEL(output2),s3);
output3=lookup_widget(page_d_accueil_admin1,"label_adresse_salle_page_accueil");
gtk_label_set_text(GTK_LABEL(output3),s4);
fclose(f);

f1=fopen("liste_desdeals.txt","r");
while(fscanf(f1,"%s %s %s %s %s \n",s,s1,s2,s3,s4)!=EOF)
output4=lookup_widget(page_d_accueil_admin1,"label_nom_actuel_deal_page_accueil");
gtk_label_set_text(GTK_LABEL(output4),s);
output5=lookup_widget(page_d_accueil_admin1,"label_dated_deal_page_accueil");
gtk_label_set_text(GTK_LABEL(output5),s1);
output6=lookup_widget(page_d_accueil_admin1,"label_datef_deal_page_accueil");
gtk_label_set_text(GTK_LABEL(output6),s2);
output7=lookup_widget(page_d_accueil_admin1,"label_prix_deal_page_accueil");
gtk_label_set_text(GTK_LABEL(output7),s3);
fclose(f1);

f2=fopen("liste_desevenements.txt","r");
while(fscanf(f2,"%s %s %s %s \n",s,s1,s2,s3)!=EOF)
output9=lookup_widget(page_d_accueil_admin1,"label_nom_event_page_accueil");
gtk_label_set_text(GTK_LABEL(output9),s);
output10=lookup_widget(page_d_accueil_admin1,"label_date_event_page_accueil");
gtk_label_set_text(GTK_LABEL(output10),s1);
output11=lookup_widget(page_d_accueil_admin1,"label_event_prix_page_accueil");
gtk_label_set_text(GTK_LABEL(output11),s2);

fclose(f2);
}



void
on_button_planning_semaine_admin_clicked                    (GtkWidget      *button,
                                        gpointer         user_data)
{
liste_deals=create_liste_deals();
gtk_widget_show(liste_deals);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"gestion_page_d_accueil")));
}



void
on_button_deals_admin_clicked                    (GtkWidget      *button,
                                        gpointer         user_data)
{

GtkWidget *treeview1;
Deal d;

gestion_page_d_accueil=lookup_widget(button,"gestion_page_d_accueil");
gtk_widget_destroy(gestion_page_d_accueil);
liste_deals=lookup_widget(button,"liste_deals");
liste_deals=create_liste_deals();
gtk_widget_show(liste_deals);

treeview1=lookup_widget(liste_deals,"treeview_liste_des_deals_admin");
afficher_deal(treeview1);
}


void
on_button_retour_menu_admin_accueil_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
gestion_page_d_accueil=lookup_widget(button,"gestion_page_d_accueil");
gtk_widget_destroy(gestion_page_d_accueil);
menu_admin=lookup_widget(button,"menu_admin");
menu_admin=create_menu_admin();
gtk_widget_show(menu_admin);
}



void
on_button_ajouter_nv_deal_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
liste_deals=lookup_widget(button,"liste_deals");
gtk_widget_destroy(liste_deals);
Ajouter_deal=lookup_widget(button,"Ajouter_deal");
Ajouter_deal=create_Ajouter_deal();
gtk_widget_show(Ajouter_deal);
}


void
on_button_retour_page_accueil_liste_deals_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{

liste_deals=lookup_widget(button,"liste_deals");
gtk_widget_destroy(liste_deals);
gestion_page_d_accueil=lookup_widget(button,"gestion_page_d_accueil");
gestion_page_d_accueil=create_gestion_page_d_accueil();
gtk_widget_show(gestion_page_d_accueil);


}


void
on_button_supprimer_deal_admin_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{

GtkWidget *input;
char s[30];
input=lookup_widget(Affichage_du_deal,"label_nom_du_deal_a_modifier_admin");
strcpy(s,gtk_label_get_text(GTK_LABEL(input)));
supprimer_deal(s);

GtkWidget *treeview1;
Deal d;

Affichage_du_deal=lookup_widget(button,"Affichage_du_deal");
gtk_widget_destroy(Affichage_du_deal);
liste_deals=lookup_widget(button,"liste_deals");
liste_deals=create_liste_deals();
gtk_widget_show(liste_deals);

treeview1=lookup_widget(liste_deals,"treeview_liste_des_deals_admin");
afficher_deal(treeview1);			

}

void
on_button_modifier_deal_admin_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{

GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;


GtkWidget *treeview1;

Deal d;

GtkWidget *input;
char s[30];
input=lookup_widget(Affichage_du_deal,"label_nom_du_deal_a_modifier_admin");
strcpy(s,gtk_label_get_text(GTK_LABEL(input)));

input1=lookup_widget(Affichage_du_deal,"entry_nom_deal_affichage_deal");
strcpy(d.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
input2=lookup_widget(Affichage_du_deal,"entry_date_debut_affichage_deal");
strcpy(d.date_debut,gtk_entry_get_text(GTK_ENTRY(input2)));
input3=lookup_widget(Affichage_du_deal,"entry_date_fin_affichage_deal");
strcpy(d.date_fin,gtk_entry_get_text(GTK_ENTRY(input3)));
input4=lookup_widget(Affichage_du_deal,"entry_prix_affichage_deal");
strcpy(d.prix,gtk_entry_get_text(GTK_ENTRY(input4)));
input5=lookup_widget(Affichage_du_deal,"entry_description_affichage_deal");
strcpy(d.description,gtk_entry_get_text(GTK_ENTRY(input5)));

modifier_deal(s,d);


Affichage_du_deal=lookup_widget(button,"Affichage_du_deal");
gtk_widget_destroy(Affichage_du_deal);
liste_deals=lookup_widget(button,"liste_deals");
liste_deals=create_liste_deals();
gtk_widget_show(liste_deals);

treeview1=lookup_widget(liste_deals,"treeview_liste_des_deals_admin");
afficher_deal(treeview1);
}


void
on_button_retour_affichage_liste_deals_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
Deal d;

Affichage_du_deal=lookup_widget(button,"Affichage_du_deal");
gtk_widget_destroy(Affichage_du_deal);
liste_deals=lookup_widget(button,"liste_deals");
liste_deals=create_liste_deals();
gtk_widget_show(liste_deals);

treeview1=lookup_widget(liste_deals,"treeview_liste_des_deals_admin");
afficher_deal(treeview1);
}



void
on_button_retour_ajouter_deal_liste_deals_clicked                    (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
Deal d;

Ajouter_deal=lookup_widget(button,"Ajouter_deal");
gtk_widget_destroy(Ajouter_deal);
liste_deals=lookup_widget(button,"liste_deals");
liste_deals=create_liste_deals();
gtk_widget_show(liste_deals);

treeview1=lookup_widget(liste_deals,"treeview_liste_des_deals_admin");
afficher_deal(treeview1);
}



void
on_button_valider_nv_deal_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *input1;
GtkWidget *inputjd;
GtkWidget *inputmd;
GtkWidget *inputad;
GtkWidget *inputjf;
GtkWidget *inputaf;
GtkWidget *inputmf;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget *treeview1;

Deal d;


char jd[4],md[4],ad[6],jf[4],mf[4],af[6];

input1=lookup_widget(button,"entry_nom_ajouter_deal");
strcpy(d.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
inputjd=lookup_widget(button,"combobox_jours_debut_ajouter_deal");
strcpy(jd,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputjd)));
inputmd=lookup_widget(button,"combobox_mois_debut_ajouter_deal");
strcpy(md,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputmd)));
inputad=lookup_widget(button,"combobox_annee_debut_ajouter_deal");
strcpy(ad,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputad)));
inputjf=lookup_widget(button,"combobox_jours_fin_ajouter_deal");
strcpy(jf,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputjf)));
inputmf=lookup_widget(button,"combobox_mois_fin_ajouter_deal");
strcpy(mf,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputmf)));
inputaf=lookup_widget(button,"combobox_annee_fin_ajouter_deal");
strcpy(af,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputaf)));
input4=lookup_widget(button,"entry_prix_ajouter_deal");
strcpy(d.prix,gtk_entry_get_text(GTK_ENTRY(input4)));
input5=lookup_widget(button,"entry_description_ajouter_deal");
strcpy(d.description,gtk_entry_get_text(GTK_ENTRY(input5)));


memset(d.date_debut, 0, sizeof(d.date_debut));
memset(d.date_fin, 0, sizeof(d.date_fin));
strcat(d.date_debut,jd);
strcat(d.date_debut,"/");
strcat(d.date_debut,md);
strcat(d.date_debut,"/");
strcat(d.date_debut,ad);
strcat(d.date_fin,jf);
strcat(d.date_fin,"/");
strcat(d.date_fin,mf);
strcat(d.date_fin,"/");
strcat(d.date_fin,af);

ajouter_deal(d);

Ajouter_deal=lookup_widget(button,"Ajouter_deal");
gtk_widget_destroy(Ajouter_deal);
liste_deals=lookup_widget(button,"liste_deals");
liste_deals=create_liste_deals();
gtk_widget_show(liste_deals);

treeview1=lookup_widget(liste_deals,"treeview_liste_des_deals_admin");
afficher_deal(treeview1);
}



void
on_button_supprimer_event_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *input;
char s[30];
input=lookup_widget(Affichage_event,"label_nom_du_event_a_modifier_admin");
strcpy(s,gtk_label_get_text(GTK_LABEL(input)));
supprimer_event(s);

GtkWidget *treeview1;
Evenement e;

Affichage_event=lookup_widget(button,"Affichage_event");
gtk_widget_destroy(Affichage_event);
Liste_event=lookup_widget(button,"Liste_event");
Liste_event=create_Liste_event();
gtk_widget_show(Liste_event);

treeview1=lookup_widget(Liste_event,"treeview_liste_des_event_admin");
afficher_event(treeview1);
}


void
on_button_modifier_event_admin_clicked (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;


GtkWidget *treeview1;

Evenement e;

GtkWidget *input;
char s[30];
input=lookup_widget(Affichage_event,"label_nom_du_event_a_modifier_admin");
strcpy(s,gtk_label_get_text(GTK_LABEL(input)));

input1=lookup_widget(Affichage_event,"entry_nom_event_affichage_event");
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
input2=lookup_widget(Affichage_event,"entry_date_affichage_event");
strcpy(e.date,gtk_entry_get_text(GTK_ENTRY(input2)));
input3=lookup_widget(Affichage_event,"entry_description_event_admin");
strcpy(e.description,gtk_entry_get_text(GTK_ENTRY(input3)));


modifier_event(s,e);


Affichage_event=lookup_widget(button,"Affichage_event");
gtk_widget_destroy(Affichage_event);
Liste_event=lookup_widget(button,"Liste_event");
Liste_event=create_Liste_event();
gtk_widget_show(Liste_event);

treeview1=lookup_widget(Liste_event,"treeview_liste_des_event_admin");
afficher_event(treeview1);
}




void
on_button_retour_page_accueil_liste_event_clicked
                                        (GtkWidget      *button,
                                        gpointer         user_data)
{
Liste_event=lookup_widget(button,"Liste_event");
gtk_widget_destroy(Liste_event);
gestion_page_d_accueil=lookup_widget(button,"gestion_page_d_accueil");
gestion_page_d_accueil=create_gestion_page_d_accueil();
gtk_widget_show(gestion_page_d_accueil);
}


void
on_button_ajouter_nv_event_clicked     (GtkWidget      *button,
                                        gpointer         user_data)
{
Liste_event=lookup_widget(button,"Liste_event");
gtk_widget_destroy(Liste_event);
Ajouter_event=lookup_widget(button,"Ajouter_event");
Ajouter_event=create_Ajouter_event();
gtk_widget_show(Ajouter_event);
}


void
on_button_valider_nv_event_clicked     (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *input1;
GtkWidget *inputjd;
GtkWidget *inputmd;
GtkWidget *inputad;
GtkWidget *input5;
GtkWidget *treeview1;

Evenement e;


char jd[4],md[4],ad[6];

input1=lookup_widget(button,"entry_nom_ajouter_event");
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
inputjd=lookup_widget(button,"combobox_jours_ajouter_event");
strcpy(jd,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputjd)));
inputmd=lookup_widget(button,"combobox_mois_ajouter_event");
strcpy(md,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputmd)));
inputad=lookup_widget(button,"combobox_annee_ajouter_event");
strcpy(ad,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputad)));
input5=lookup_widget(button,"entry_description_ajout_event_admin");
strcpy(e.description,gtk_entry_get_text(GTK_ENTRY(input5)));


memset(e.date, 0, sizeof(e.date));
strcat(e.date,jd);
strcat(e.date,"/");
strcat(e.date,md);
strcat(e.date,"/");
strcat(e.date,ad);

ajouter_event(e);

Ajouter_event=lookup_widget(button,"Ajouter_event");
gtk_widget_destroy(Ajouter_event);
Liste_event=lookup_widget(button,"Liste_event");
Liste_event=create_Liste_event();
gtk_widget_show(Liste_event);

treeview1=lookup_widget(Liste_event,"treeview_liste_des_event_admin");
afficher_event(treeview1);
}





void
on_button_retour_affichage_liste_event_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
Evenement e;

Affichage_event=lookup_widget(button,"Affichage_event");
gtk_widget_destroy(Affichage_event);
Liste_event=lookup_widget(button,"Liste_event");
Liste_event=create_Liste_event();
gtk_widget_show(Liste_event);

treeview1=lookup_widget(Liste_event,"treeview_liste_des_event_admin");
afficher_event(treeview1);
}




void
on_button_retour_page_d_accueil_info_admin_clicked
                                        (GtkWidget      *button,
                                        gpointer         user_data)
{
Info_coord_actuel_admin=lookup_widget(button,"Info_coord_actuel_admin");
gtk_widget_destroy(Info_coord_actuel_admin);
gestion_page_d_accueil=lookup_widget(button,"gestion_page_d_accueil");
gestion_page_d_accueil=create_gestion_page_d_accueil();
gtk_widget_show(gestion_page_d_accueil);
}


void
on_button_modifier_info_coord_admin_clicked
                                        (GtkWidget      *button,
                                        gpointer         user_data)
{
Info_coord_actuel_admin=lookup_widget(button,"Info_coord_actuel_admin");
gtk_widget_destroy(Info_coord_actuel_admin);
modifier_info_coord_admin=lookup_widget(button,"modifier_info_coord_admin");
modifier_info_coord_admin=create_modifier_info_coord_admin();
gtk_widget_show(modifier_info_coord_admin);


GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;

char nom[20],horaire[15],tel[10],email[30],adresse[30];
FILE *f;
f=fopen("info_coord.txt","r");
	if(f!=NULL)
          { if(fscanf(f,"%s %s %s %s %s \n",nom,horaire,tel,email,adresse)!=EOF);}
fclose(f);



output1=lookup_widget(modifier_info_coord_admin,"entry_nom_salle_modifier_admin");
gtk_entry_set_text(GTK_ENTRY(output1),nom);
output2=lookup_widget(modifier_info_coord_admin,"entry_horraire_info_modifier_admin");
gtk_entry_set_text(GTK_ENTRY(output2),horaire);
output3=lookup_widget(modifier_info_coord_admin,"entry_tel_info_modifier_admin");
gtk_entry_set_text(GTK_ENTRY(output3),tel);
output4=lookup_widget(modifier_info_coord_admin,"entry_email_modifier_info_admin");
gtk_entry_set_text(GTK_ENTRY(output4),email);
output5=lookup_widget(modifier_info_coord_admin,"entry_adresse_modifier_info_admin");
gtk_entry_set_text(GTK_ENTRY(output5),adresse);

}


void
on_button_valider_modification_info_acoord_dmin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;

char nom[20],horaire[50],tel[50],email[30],adresse[40];
FILE *f;

output1=lookup_widget(modifier_info_coord_admin,"entry_nom_salle_modifier_admin");
strcpy(nom,gtk_entry_get_text(GTK_ENTRY(output1)));
output2=lookup_widget(modifier_info_coord_admin,"entry_horraire_info_modifier_admin");
strcpy(horaire,gtk_entry_get_text(GTK_ENTRY(output2)));
output3=lookup_widget(modifier_info_coord_admin,"entry_tel_info_modifier_admin");
strcpy(tel,gtk_entry_get_text(GTK_ENTRY(output3)));
output4=lookup_widget(modifier_info_coord_admin,"entry_email_modifier_info_admin");
strcpy(email,gtk_entry_get_text(GTK_ENTRY(output4)));
output5=lookup_widget(modifier_info_coord_admin,"entry_adresse_modifier_info_admin");
strcpy(adresse,gtk_entry_get_text(GTK_ENTRY(output5)));

f=fopen("info_coord1.txt","a+");
fprintf(f,"%s %s %s %s %s \n",nom,horaire,tel,email,adresse);

remove("info_coord.txt");
rename("info_coord1.txt","info_coord.txt");
fclose(f);

modifier_info_coord_admin=lookup_widget(button,"modifier_info_coord_admin");
gtk_widget_destroy(modifier_info_coord_admin);
Info_coord_actuel_admin=lookup_widget(button,"Info_coord_actuel_admin");
Info_coord_actuel_admin=create_Info_coord_actuel_admin();
gtk_widget_show(Info_coord_actuel_admin);

FILE *f1;
char nom3[20];
char horraire3[50];
char tel3[50];
char email3[30];
char adresse3[40];

GtkWidget *out1;
GtkWidget *out2;
GtkWidget *out3;
GtkWidget *out4;
GtkWidget *out5;

f1=fopen("info_coord.txt","a+");
if(f1!=NULL)
	
	{
		if(fscanf(f1,"%s %s %s %s %s \n",nom3,horraire3,tel3,email3,adresse3)!=EOF);
	out1=lookup_widget(Info_coord_actuel_admin,"labelkhalil1");
	gtk_label_set_text(GTK_LABEL(out1),nom3);
	out2=lookup_widget(Info_coord_actuel_admin,"labelkhalil2");
	gtk_label_set_text(GTK_LABEL(out2),horraire3);
	out3=lookup_widget(Info_coord_actuel_admin,"labelkhalil3");
	gtk_label_set_text(GTK_LABEL(out3),tel3);
	out4=lookup_widget(Info_coord_actuel_admin,"labelkhalil4");
	gtk_label_set_text(GTK_LABEL(out4),email3);
	out5=lookup_widget(Info_coord_actuel_admin,"labelkhalil5");
	gtk_label_set_text(GTK_LABEL(out5),adresse3);
	}
fclose(f1);
}


void
on_button_retour_info_coord_modifier_admin_clicked
                                        (GtkWidget      *button,
                                        gpointer         user_data)
{
modifier_info_coord_admin=lookup_widget(button,"modifier_info_coord_admin");
gtk_widget_destroy(modifier_info_coord_admin);
Info_coord_actuel_admin=lookup_widget(button,"Info_coord_actuel_admin");
Info_coord_actuel_admin=create_Info_coord_actuel_admin();
gtk_widget_show(Info_coord_actuel_admin);

FILE *f1;
char nom3[20];
char horraire3[50];
char tel3[50];
char email3[30];
char adresse3[40];

GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;

f1=fopen("info_coord.txt","a+");
if(f1!=NULL)
	
	{
		if(fscanf(f1,"%s %s %s %s %s \n",nom3,horraire3,tel3,email3,adresse3)!=EOF);
	output1=lookup_widget(Info_coord_actuel_admin,"labelkhalil1");
	gtk_label_set_text(GTK_LABEL(output1),nom3);
	output2=lookup_widget(Info_coord_actuel_admin,"labelkhalil2");
	gtk_label_set_text(GTK_LABEL(output2),horraire3);
	output3=lookup_widget(Info_coord_actuel_admin,"labelkhalil3");
	gtk_label_set_text(GTK_LABEL(output3),tel3);
	output4=lookup_widget(Info_coord_actuel_admin,"labelkhalil4");
	gtk_label_set_text(GTK_LABEL(output4),email3);
	output5=lookup_widget(Info_coord_actuel_admin,"labelkhalil5");
	gtk_label_set_text(GTK_LABEL(output5),adresse3);
	}
fclose(f1);
}




void
on_button_afficher_event_choisi_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *input;
char s[30];
input=lookup_widget(Liste_event,"entry_nom_event_afficher_admin");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(input)));

Liste_event=lookup_widget(button,"Liste_event");
gtk_widget_destroy(Liste_event);
Affichage_event=lookup_widget(button,"Affichage_event");
Affichage_event=create_Affichage_event();
gtk_widget_show(Affichage_event); 
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget *input6;

FILE *f;
Evenement e;
	f=fopen("liste_desevenements.txt","r");
	if(f!=NULL)
	{
	while (fscanf(f,"%s %s %s 	\n",e.nom,e.date,e.description)!=EOF)
	{if (strcmp(e.nom,s)==0)
{input1=lookup_widget(Affichage_event,"entry_nom_event_affichage_event");     
gtk_entry_set_text(GTK_ENTRY(input1),e.nom);

input6=lookup_widget(Affichage_event,"label_nom_du_event_a_modifier_admin");
gtk_label_set_text(GTK_LABEL(input6),e.nom);

input2=lookup_widget(Affichage_event,"entry_date_affichage_event");     
gtk_entry_set_text(GTK_ENTRY(input2),e.date);
input3=lookup_widget(Affichage_event,"entry_description_event_admin");     
gtk_entry_set_text(GTK_ENTRY(input3),e.description);
}}
fclose(f);}
}


void
on_button_retour_ajouter_event_liste_event_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
Evenement d;

Ajouter_event=lookup_widget(button,"Ajouter_event");
gtk_widget_destroy(Ajouter_event);
Liste_event=lookup_widget(button,"Liste_event");
Liste_event=create_Liste_event();
gtk_widget_show(Liste_event);

treeview1=lookup_widget(Liste_event,"treeview_liste_des_event_admin");
afficher_event(treeview1);
}


//Abonnements et factures

void
on_button_retour_abonnement_facture_menu_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
gestion_abonnement_factures=lookup_widget(button,"gestion_abonnement_factures");
gtk_widget_destroy(gestion_abonnement_factures);
menu_admin=lookup_widget(button,"menu_admin");
menu_admin=create_menu_admin();
gtk_widget_show(menu_admin);
}


void
on_button_retour_facture_coach_menu_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
gestion_abonnement_factures=lookup_widget(button,"gestion_abonnement_factures");
gtk_widget_destroy(gestion_abonnement_factures);
menu_admin=lookup_widget(button,"menu_admin");
menu_admin=create_menu_admin();
gtk_widget_show(menu_admin);
}


void
on_button_retour_facture_medecin_menu_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
gestion_abonnement_factures=lookup_widget(button,"gestion_abonnement_factures");
gtk_widget_destroy(gestion_abonnement_factures);
menu_admin=lookup_widget(button,"menu_admin");
menu_admin=create_menu_admin();
gtk_widget_show(menu_admin);
}

void
on_button_retour_facture_kine_menu_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
gestion_abonnement_factures=lookup_widget(button,"gestion_abonnement_factures");
gtk_widget_destroy(gestion_abonnement_factures);
menu_admin=lookup_widget(button,"menu_admin");
menu_admin=create_menu_admin();
gtk_widget_show(menu_admin);
}



void
on_button_retour_facture_agent_menu_admin_clicked
                                        (GtkWidget      *button,
                                        gpointer         user_data)
{
gestion_abonnement_factures=lookup_widget(button,"gestion_abonnement_factures");
gtk_widget_destroy(gestion_abonnement_factures);
menu_admin=lookup_widget(button,"menu_admin");
menu_admin=create_menu_admin();
gtk_widget_show(menu_admin);
}

GtkWidget *modifier_abonnement_admin;

void
on_button_modifier_abonnement_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{


modifier_abonnement_admin=lookup_widget(button,"modifier_abonnement_admin");
modifier_abonnement_admin=create_modifier_abonnement_admin();
gtk_widget_show(modifier_abonnement_admin); 

}

GtkWidget *modifier_facture_coach_admin;
void
on_button_modifier_facture_coach_admin1_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{

modifier_facture_coach_admin=lookup_widget(button,"modifier_facture_coach_admin");
modifier_facture_coach_admin=create_modifier_facture_coach_admin();
gtk_widget_show(modifier_facture_coach_admin); 

}


//modifier facture medecin
GtkWidget *modifier_facture_medecin_admin;
void
on_button_modifier_facture_coach_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{

modifier_facture_medecin_admin=lookup_widget(button,"modifier_facture_medecin_admin");
modifier_facture_medecin_admin=create_modifier_facture_medecin_admin();
gtk_widget_show(modifier_facture_medecin_admin);
}



GtkWidget *modifier_facture_kine_admin;
void
on_button_modifier_facture_kine_admin_clicked
                                        (GtkWidget      *button,
                                        gpointer         user_data)
{

modifier_facture_kine_admin=lookup_widget(button,"modifier_facture_kine_admin");
modifier_facture_kine_admin=create_modifier_facture_kine_admin();
gtk_widget_show(modifier_facture_kine_admin);
}




GtkWidget *modifier_facture_agent_admin;
GtkWidget *valider_modification_abonnement_admin;
GtkWidget *valider_modification_facture_coach_admin;
GtkWidget *valider_modification_facture_medecin_admin;
GtkWidget *valider_modification_facture_kine_admin;
GtkWidget *valider_modification_facture_agent_admin;

void
on_button_modifier_facture_agent_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{

modifier_facture_agent_admin=lookup_widget(button,"modifier_facture_agent_admin");
modifier_facture_agent_admin=create_modifier_facture_agent_admin();
gtk_widget_show(modifier_facture_agent_admin);
}


void
on_button_valider_choix_cin_adh_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *input;

char s1[20];
adherent_f d;

memset(s1, 0, sizeof(s1));
input=lookup_widget(modifier_abonnement_admin,"entry_cin_modifier_adh_abonnement_admin");
strcpy(s1,gtk_entry_get_text(GTK_ENTRY(input)));

GtkWidget *input1;
GtkWidget *input6;

FILE *f;FILE *f1;
	f=fopen("liste_desadherents_abonnement.txt","r");
	if(f!=NULL)
	{
	while (fscanf(f," %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre)!=EOF)
	{
if (strcmp(d.cin,s1)==0)
{
input1=lookup_widget(modifier_abonnement_admin,"label_khalil_123");     
gtk_label_set_text(GTK_LABEL(input1),d.nom);

input6=lookup_widget(modifier_abonnement_admin,"label_khalil_1");
gtk_label_set_text(GTK_LABEL(input6),d.cin);

}}
fclose(f);}

}

void
on_button_valider_choix_cin_coach_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *input;

char s1[20];
coach_f d;

memset(s1, 0, sizeof(s1));
input=lookup_widget(modifier_facture_coach_admin,"entry_cin_modifier_coach_abonnement_admin");
strcpy(s1,gtk_entry_get_text(GTK_ENTRY(input)));

GtkWidget *input1;
GtkWidget *input6;

FILE *f;
	f=fopen("liste_descoachsfacture.txt","r");
	if(f!=NULL)
	{
	while (fscanf(f," %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre)!=EOF)
	{
if (strcmp(d.cin,s1)==0)
{
input1=lookup_widget(modifier_facture_coach_admin,"nom_facture_coach_admin1");     
gtk_label_set_text(GTK_LABEL(input1),d.nom);

input6=lookup_widget(modifier_facture_coach_admin,"cin_facture_coach_admin1");
gtk_label_set_text(GTK_LABEL(input6),d.cin);

}}
fclose(f);}
}



void
on_button_valider_choix_cin_medecin_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *input;

char s1[20];
medecin_f d;

memset(s1, 0, sizeof(s1));
input=lookup_widget(modifier_facture_medecin_admin,"entry_cin_modifier_medecin_abonnement_admin");
strcpy(s1,gtk_entry_get_text(GTK_ENTRY(input)));

GtkWidget *input1;
GtkWidget *input6;

FILE *f;
	f=fopen("liste_desmedecinsfacture.txt","r");
	if(f!=NULL)
	{
	while (fscanf(f," %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre)!=EOF)
	{
if (strcmp(d.cin,s1)==0)
{
input1=lookup_widget(modifier_facture_medecin_admin,"nom_facture_medecin_admin1");     
gtk_label_set_text(GTK_LABEL(input1),d.nom);

input6=lookup_widget(modifier_facture_medecin_admin,"cin_facture_medecin_admin1");
gtk_label_set_text(GTK_LABEL(input6),d.cin);

}}
fclose(f);}
}

void
on_button_valider_choix_cin_kine_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *input;

char s1[20];
kine_f d;

memset(s1, 0, sizeof(s1));
input=lookup_widget(modifier_facture_kine_admin,"entry_cin_modifier_kine_abonnement_admin");
strcpy(s1,gtk_entry_get_text(GTK_ENTRY(input)));

GtkWidget *input1;
GtkWidget *input6;

FILE *f;
	f=fopen("liste_deskinesfacture.txt","r");
	if(f!=NULL)
	{
	while (fscanf(f," %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre)!=EOF)
	{
if (strcmp(d.cin,s1)==0)
{
input1=lookup_widget(modifier_facture_kine_admin,"nom_facture_kine_admin1");     
gtk_label_set_text(GTK_LABEL(input1),d.nom);

input6=lookup_widget(modifier_facture_kine_admin,"cin_facture_kine_admin1");
gtk_label_set_text(GTK_LABEL(input6),d.cin);

}}
fclose(f);}
}


void
on_button_valider_choix_cin_agent_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *input;

char s1[20];
kine_f d;

memset(s1, 0, sizeof(s1));
input=lookup_widget(modifier_facture_agent_admin,"entry_cin_modifier_agent_abonnement_admin");
strcpy(s1,gtk_entry_get_text(GTK_ENTRY(input)));

GtkWidget *input1;
GtkWidget *input6;

FILE *f;
	f=fopen("liste_desagentsfacture.txt","r");
	if(f!=NULL)
	{
	while (fscanf(f," %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre)!=EOF)
	{
if (strcmp(d.cin,s1)==0)
{
input1=lookup_widget(modifier_facture_agent_admin,"nom_facture_agent_admin1");     
gtk_label_set_text(GTK_LABEL(input1),d.nom);

input6=lookup_widget(modifier_facture_agent_admin,"cin_facture_agent_admin1");
gtk_label_set_text(GTK_LABEL(input6),d.cin);

}}
fclose(f);}
}


void
on_button_verification_payement_admin1_clicked
                                        (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *input;
GtkWidget *input1;

char s[20];
char s1[20];
adherent_f d;
memset(s1, 0, sizeof(s1));
FILE *f;

input=lookup_widget(modifier_abonnement_admin,"entry_cin_modifier_adh_abonnement_admin");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(input)));
input1=lookup_widget(modifier_abonnement_admin,"combobox_mois_abonnement_admin");
strcpy(s1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)));
f=fopen("liste_desadherents_abonnement.txt","r");
while (fscanf(f," %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre)!=EOF)
{if (strcmp(s,d.cin)==0)
{if (strcmp(s1,"Janvier")==0)
	
{
GtkWidget *output;
modifier_abonnement_admin=lookup_widget(button,"modifier_abonnement_admin");
gtk_widget_destroy(modifier_abonnement_admin);
valider_modification_abonnement_admin=lookup_widget(button,"valider_modification_abonnement_admin");
valider_modification_abonnement_admin=create_valider_modification_abonnement_admin();
gtk_widget_show(valider_modification_abonnement_admin);
output=lookup_widget(valider_modification_abonnement_admin,"entry_adh_payer_admin5");
gtk_entry_set_text(GTK_ENTRY(output),d.janvier);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_abonnement_admin,"label_cin_abonnement_adh_valider_admin5");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_abonnement_admin,"label_mois_abonnement_adh_admin5");
gtk_label_set_text(GTK_LABEL(output2),"Janvier");}
else if (strcmp(s1,"Fevrier")==0)
{GtkWidget *output;
modifier_abonnement_admin=lookup_widget(button,"modifier_abonnement_admin");
gtk_widget_destroy(modifier_abonnement_admin);
valider_modification_abonnement_admin=lookup_widget(button,"valider_modification_abonnement_admin");
valider_modification_abonnement_admin=create_valider_modification_abonnement_admin();
gtk_widget_show(valider_modification_abonnement_admin);
output=lookup_widget(valider_modification_abonnement_admin,"entry_adh_payer_admin5");
gtk_entry_set_text(GTK_ENTRY(output),d.fevrier);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_abonnement_admin,"label_cin_abonnement_adh_valider_admin5");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_abonnement_admin,"label_mois_abonnement_adh_admin5");
gtk_label_set_text(GTK_LABEL(output2),"Fevrier");}
else if (strcmp(s1,"Mars")==0)
{GtkWidget *output;
modifier_abonnement_admin=lookup_widget(button,"modifier_abonnement_admin");
gtk_widget_destroy(modifier_abonnement_admin);
valider_modification_abonnement_admin=lookup_widget(button,"valider_modification_abonnement_admin");
valider_modification_abonnement_admin=create_valider_modification_abonnement_admin();
gtk_widget_show(valider_modification_abonnement_admin);
output=lookup_widget(valider_modification_abonnement_admin,"entry_adh_payer_admin5");
gtk_entry_set_text(GTK_ENTRY(output),d.mars);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_abonnement_admin,"label_cin_abonnement_adh_valider_admin5");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_abonnement_admin,"label_mois_abonnement_adh_admin5");
gtk_label_set_text(GTK_LABEL(output2),"Avril");}
else if (strcmp(s1,"Avril")==0)
{GtkWidget *output;
modifier_abonnement_admin=lookup_widget(button,"modifier_abonnement_admin");
gtk_widget_destroy(modifier_abonnement_admin);
valider_modification_abonnement_admin=lookup_widget(button,"valider_modification_abonnement_admin");
valider_modification_abonnement_admin=create_valider_modification_abonnement_admin();
gtk_widget_show(valider_modification_abonnement_admin);
output=lookup_widget(valider_modification_abonnement_admin,"entry_adh_payer_admin5");
gtk_entry_set_text(GTK_ENTRY(output),d.avril);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_abonnement_admin,"label_cin_abonnement_adh_valider_admin5");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_abonnement_admin,"label_mois_abonnement_adh_admin5");
gtk_label_set_text(GTK_LABEL(output2),"Avril");}
else if (strcmp(s1,"Mai")==0)
{GtkWidget *output;
modifier_abonnement_admin=lookup_widget(button,"modifier_abonnement_admin");
gtk_widget_destroy(modifier_abonnement_admin);
valider_modification_abonnement_admin=lookup_widget(button,"valider_modification_abonnement_admin");
valider_modification_abonnement_admin=create_valider_modification_abonnement_admin();
gtk_widget_show(valider_modification_abonnement_admin);
output=lookup_widget(valider_modification_abonnement_admin,"entry_adh_payer_admin5");
gtk_entry_set_text(GTK_ENTRY(output),d.mai);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_abonnement_admin,"label_cin_abonnement_adh_valider_admin5");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_abonnement_admin,"label_mois_abonnement_adh_admin5");
gtk_label_set_text(GTK_LABEL(output2),"Mai");}
else if (strcmp(s1,"Juin")==0)
{GtkWidget *output;
modifier_abonnement_admin=lookup_widget(button,"modifier_abonnement_admin");
gtk_widget_destroy(modifier_abonnement_admin);
valider_modification_abonnement_admin=lookup_widget(button,"valider_modification_abonnement_admin");
valider_modification_abonnement_admin=create_valider_modification_abonnement_admin();
gtk_widget_show(valider_modification_abonnement_admin);
output=lookup_widget(valider_modification_abonnement_admin,"entry_adh_payer_admin5");
gtk_entry_set_text(GTK_ENTRY(output),d.juin);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_abonnement_admin,"label_cin_abonnement_adh_valider_admin5");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_abonnement_admin,"label_mois_abonnement_adh_admin5");
gtk_label_set_text(GTK_LABEL(output2),"Juin");}
else if (strcmp(s1,"Juillet")==0)
{GtkWidget *output;
modifier_abonnement_admin=lookup_widget(button,"modifier_abonnement_admin");
gtk_widget_destroy(modifier_abonnement_admin);
valider_modification_abonnement_admin=lookup_widget(button,"valider_modification_abonnement_admin");
valider_modification_abonnement_admin=create_valider_modification_abonnement_admin();
gtk_widget_show(valider_modification_abonnement_admin);
output=lookup_widget(valider_modification_abonnement_admin,"entry_adh_payer_admin5");
gtk_entry_set_text(GTK_ENTRY(output),d.juillet);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_abonnement_admin,"label_cin_abonnement_adh_valider_admin5");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_abonnement_admin,"label_mois_abonnement_adh_admin5");
gtk_label_set_text(GTK_LABEL(output2),"Juillet");}
else if (strcmp(s1,"Aout")==0)
{GtkWidget *output;
modifier_abonnement_admin=lookup_widget(button,"modifier_abonnement_admin");
gtk_widget_destroy(modifier_abonnement_admin);
valider_modification_abonnement_admin=lookup_widget(button,"valider_modification_abonnement_admin");
valider_modification_abonnement_admin=create_valider_modification_abonnement_admin();
gtk_widget_show(valider_modification_abonnement_admin);
output=lookup_widget(valider_modification_abonnement_admin,"entry_adh_payer_admin5");
gtk_entry_set_text(GTK_ENTRY(output),d.aout);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_abonnement_admin,"label_cin_abonnement_adh_valider_admin5");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_abonnement_admin,"label_mois_abonnement_adh_admin5");
gtk_label_set_text(GTK_LABEL(output2),"Aout");}
else if (strcmp(s1,"Septembre")==0)
{GtkWidget *output;
modifier_abonnement_admin=lookup_widget(button,"modifier_abonnement_admin");
gtk_widget_destroy(modifier_abonnement_admin);
valider_modification_abonnement_admin=lookup_widget(button,"valider_modification_abonnement_admin");
valider_modification_abonnement_admin=create_valider_modification_abonnement_admin();
gtk_widget_show(valider_modification_abonnement_admin);
output=lookup_widget(valider_modification_abonnement_admin,"entry_adh_payer_admin5");
gtk_entry_set_text(GTK_ENTRY(output),d.septembre);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_abonnement_admin,"label_cin_abonnement_adh_valider_admin5");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_abonnement_admin,"label_mois_abonnement_adh_admin5");
gtk_label_set_text(GTK_LABEL(output2),"Septembre");}
else if (strcmp(s1,"Octobre")==0)
{GtkWidget *output;
modifier_abonnement_admin=lookup_widget(button,"modifier_abonnement_admin");
gtk_widget_destroy(modifier_abonnement_admin);
valider_modification_abonnement_admin=lookup_widget(button,"valider_modification_abonnement_admin");
valider_modification_abonnement_admin=create_valider_modification_abonnement_admin();
gtk_widget_show(valider_modification_abonnement_admin);
output=lookup_widget(valider_modification_abonnement_admin,"entry_adh_payer_admin5");
gtk_entry_set_text(GTK_ENTRY(output),d.octobre);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_abonnement_admin,"label_cin_abonnement_adh_valider_admin5");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_abonnement_admin,"label_mois_abonnement_adh_admin5");
gtk_label_set_text(GTK_LABEL(output2),"Octobre");}
else if (strcmp(s1,"Novembre")==0)
{GtkWidget *output;
modifier_abonnement_admin=lookup_widget(button,"modifier_abonnement_admin");
gtk_widget_destroy(modifier_abonnement_admin);
valider_modification_abonnement_admin=lookup_widget(button,"valider_modification_abonnement_admin");
valider_modification_abonnement_admin=create_valider_modification_abonnement_admin();
gtk_widget_show(valider_modification_abonnement_admin);
output=lookup_widget(valider_modification_abonnement_admin,"entry_adh_payer_admin5");
gtk_entry_set_text(GTK_ENTRY(output),d.novembre);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_abonnement_admin,"label_cin_abonnement_adh_valider_admin5");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_abonnement_admin,"label_mois_abonnement_adh_admin5");
gtk_label_set_text(GTK_LABEL(output2),"Novembre");}
else if (strcmp(s1,"Decembre")==0)
{GtkWidget *output;
modifier_abonnement_admin=lookup_widget(button,"modifier_abonnement_admin");
gtk_widget_destroy(modifier_abonnement_admin);
valider_modification_abonnement_admin=lookup_widget(button,"valider_modification_abonnement_admin");
valider_modification_abonnement_admin=create_valider_modification_abonnement_admin();
gtk_widget_show(valider_modification_abonnement_admin);
output=lookup_widget(valider_modification_abonnement_admin,"entry_adh_payer_admin5");
gtk_entry_set_text(GTK_ENTRY(output),d.decembre);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_abonnement_admin,"label_cin_abonnement_adh_valider_admin5");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_abonnement_admin,"label_mois_abonnement_adh_admin5");
gtk_label_set_text(GTK_LABEL(output2),"Decembre");}}}
fclose(f);
}

void
on_button_verification_payement_coach_admin1_clicked
                                        (GtkWidget      *button,
                                        gpointer         user_data)
{

GtkWidget *input;
GtkWidget *input1;

char s[20];
char s1[20];
coach_f d;
memset(s1, 0, sizeof(s1));
FILE *f;

input=lookup_widget(modifier_facture_coach_admin,"entry_cin_modifier_coach_abonnement_admin");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(input)));
input1=lookup_widget(modifier_facture_coach_admin,"combobox_mois_facture_coach_admin");
strcpy(s1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)));
f=fopen("liste_descoachsfacture.txt","r");
while (fscanf(f," %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre)!=EOF)
{if (strcmp(s,d.cin)==0)
{if (strcmp(s1,"Janvier")==0)
	
{
GtkWidget *output;
modifier_facture_coach_admin=lookup_widget(button,"modifier_facture_coach_admin");
gtk_widget_destroy(modifier_facture_coach_admin);
valider_modification_facture_coach_admin=lookup_widget(button,"valider_modification_facture_coach_admin");
valider_modification_facture_coach_admin=create_valider_modification_facture_coach_admin();
gtk_widget_show(valider_modification_facture_coach_admin);
output=lookup_widget(valider_modification_facture_coach_admin,"entry_coach_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.janvier);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_coach_admin,"label_cin_facture_coach_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_coach_admin,"label_mois_facture_coach_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Janvier");}
else if (strcmp(s1,"Fevrier")==0)
{GtkWidget *output;
modifier_facture_coach_admin=lookup_widget(button,"modifier_facture_coach_admin");
gtk_widget_destroy(modifier_facture_coach_admin);
valider_modification_facture_coach_admin=lookup_widget(button,"valider_modification_facture_coach_admin");
valider_modification_facture_coach_admin=create_valider_modification_facture_coach_admin();
gtk_widget_show(valider_modification_facture_coach_admin);
output=lookup_widget(valider_modification_facture_coach_admin,"entry_coach_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.fevrier);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_coach_admin,"label_cin_facture_coach_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_coach_admin,"label_mois_facture_coach_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Fevrier");}
else if (strcmp(s1,"Mars")==0)
{GtkWidget *output;
modifier_facture_coach_admin=lookup_widget(button,"modifier_facture_coach_admin");
gtk_widget_destroy(modifier_facture_coach_admin);
valider_modification_facture_coach_admin=lookup_widget(button,"valider_modification_facture_coach_admin");
valider_modification_facture_coach_admin=create_valider_modification_facture_coach_admin();
gtk_widget_show(valider_modification_facture_coach_admin);
output=lookup_widget(valider_modification_facture_coach_admin,"entry_coach_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.mars);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_coach_admin,"label_cin_facture_coach_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_coach_admin,"label_mois_facture_coach_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Mars");}
else if (strcmp(s1,"Avril")==0)
{GtkWidget *output;
modifier_facture_coach_admin=lookup_widget(button,"modifier_facture_coach_admin");
gtk_widget_destroy(modifier_facture_coach_admin);
valider_modification_facture_coach_admin=lookup_widget(button,"valider_modification_facture_coach_admin");
valider_modification_facture_coach_admin=create_valider_modification_facture_coach_admin();
gtk_widget_show(valider_modification_facture_coach_admin);
output=lookup_widget(valider_modification_facture_coach_admin,"entry_coach_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.avril);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_coach_admin,"label_cin_facture_coach_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_coach_admin,"label_mois_facture_coach_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Avril");}
else if (strcmp(s1,"Mai")==0)
{GtkWidget *output;
modifier_facture_coach_admin=lookup_widget(button,"modifier_facture_coach_admin");
gtk_widget_destroy(modifier_facture_coach_admin);
valider_modification_facture_coach_admin=lookup_widget(button,"valider_modification_facture_coach_admin");
valider_modification_facture_coach_admin=create_valider_modification_facture_coach_admin();
gtk_widget_show(valider_modification_facture_coach_admin);
output=lookup_widget(valider_modification_facture_coach_admin,"entry_coach_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.mai);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_coach_admin,"label_cin_facture_coach_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_coach_admin,"label_mois_facture_coach_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Mai");}
else if (strcmp(s1,"Juin")==0)
{GtkWidget *output;
modifier_facture_coach_admin=lookup_widget(button,"modifier_facture_coach_admin");
gtk_widget_destroy(modifier_facture_coach_admin);
valider_modification_facture_coach_admin=lookup_widget(button,"valider_modification_facture_coach_admin");
valider_modification_facture_coach_admin=create_valider_modification_facture_coach_admin();
gtk_widget_show(valider_modification_facture_coach_admin);
output=lookup_widget(valider_modification_facture_coach_admin,"entry_coach_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.juin);GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_coach_admin,"label_cin_facture_coach_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_coach_admin,"label_mois_facture_coach_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Juin");}
else if (strcmp(s1,"Juillet")==0)
{GtkWidget *output;
modifier_facture_coach_admin=lookup_widget(button,"modifier_facture_coach_admin");
gtk_widget_destroy(modifier_facture_coach_admin);
valider_modification_facture_coach_admin=lookup_widget(button,"valider_modification_facture_coach_admin");
valider_modification_facture_coach_admin=create_valider_modification_facture_coach_admin();
gtk_widget_show(valider_modification_facture_coach_admin);
output=lookup_widget(valider_modification_facture_coach_admin,"entry_coach_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.juillet);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_coach_admin,"label_cin_facture_coach_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_coach_admin,"label_mois_facture_coach_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Juillet");}
else if (strcmp(s1,"Aout")==0)
{GtkWidget *output;
modifier_facture_coach_admin=lookup_widget(button,"modifier_facture_coach_admin");
gtk_widget_destroy(modifier_facture_coach_admin);
valider_modification_facture_coach_admin=lookup_widget(button,"valider_modification_facture_coach_admin");
valider_modification_facture_coach_admin=create_valider_modification_facture_coach_admin();
gtk_widget_show(valider_modification_facture_coach_admin);
output=lookup_widget(valider_modification_facture_coach_admin,"entry_coach_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.aout);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_coach_admin,"label_cin_facture_coach_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_coach_admin,"label_mois_facture_coach_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Aout");}
else if (strcmp(s1,"Septembre")==0)
{GtkWidget *output;
modifier_facture_coach_admin=lookup_widget(button,"modifier_facture_coach_admin");
gtk_widget_destroy(modifier_facture_coach_admin);
valider_modification_facture_coach_admin=lookup_widget(button,"valider_modification_facture_coach_admin");
valider_modification_facture_coach_admin=create_valider_modification_facture_coach_admin();
gtk_widget_show(valider_modification_facture_coach_admin);
output=lookup_widget(valider_modification_facture_coach_admin,"entry_coach_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.septembre);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_coach_admin,"label_cin_facture_coach_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_coach_admin,"label_mois_facture_coach_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Septembre");}
else if (strcmp(s1,"Octobre")==0)
{GtkWidget *output;
modifier_facture_coach_admin=lookup_widget(button,"modifier_facture_coach_admin");
gtk_widget_destroy(modifier_facture_coach_admin);
valider_modification_facture_coach_admin=lookup_widget(button,"valider_modification_facture_coach_admin");
valider_modification_facture_coach_admin=create_valider_modification_facture_coach_admin();
gtk_widget_show(valider_modification_facture_coach_admin);
output=lookup_widget(valider_modification_facture_coach_admin,"entry_coach_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.octobre);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_coach_admin,"label_cin_facture_coach_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_coach_admin,"label_mois_facture_coach_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Octobre");}
else if (strcmp(s1,"Novembre")==0)
{GtkWidget *output;
modifier_facture_coach_admin=lookup_widget(button,"modifier_facture_coach_admin");
gtk_widget_destroy(modifier_facture_coach_admin);
valider_modification_facture_coach_admin=lookup_widget(button,"valider_modification_facture_coach_admin");
valider_modification_facture_coach_admin=create_valider_modification_facture_coach_admin();
gtk_widget_show(valider_modification_facture_coach_admin);
output=lookup_widget(valider_modification_facture_coach_admin,"entry_coach_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.novembre);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_coach_admin,"label_cin_facture_coach_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_coach_admin,"label_mois_facture_coach_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Novembre");}
else if (strcmp(s1,"Decembre")==0)
{GtkWidget *output;
modifier_facture_coach_admin=lookup_widget(button,"modifier_facture_coach_admin");
gtk_widget_destroy(modifier_facture_coach_admin);
valider_modification_facture_coach_admin=lookup_widget(button,"valider_modification_facture_coach_admin");
valider_modification_facture_coach_admin=create_valider_modification_facture_coach_admin();
gtk_widget_show(valider_modification_facture_coach_admin);
output=lookup_widget(valider_modification_facture_coach_admin,"entry_coach_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.decembre);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_coach_admin,"label_cin_facture_coach_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_coach_admin,"label_mois_facture_coach_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Decembre");}}}
fclose(f);

}


void
on_button_verification_payement_medecin_admin1_clicked
                                        (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *input;
GtkWidget *input1;

char s[20];
char s1[20];
medecin_f d;
memset(s1, 0, sizeof(s1));
FILE *f;

input=lookup_widget(modifier_facture_medecin_admin,"entry_cin_modifier_medecin_abonnement_admin");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(input)));
input1=lookup_widget(modifier_facture_medecin_admin,"combobox_mois_facture_medecin_admin");
strcpy(s1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)));
f=fopen("liste_desmedecinsfacture.txt","r");
while (fscanf(f," %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre)!=EOF)
{if (strcmp(s,d.cin)==0)

{if (strcmp(s1,"Janvier")==0)
	
{
GtkWidget *output;
modifier_facture_medecin_admin=lookup_widget(button,"modifier_facture_medecin_admin");
gtk_widget_destroy(modifier_facture_medecin_admin);
valider_modification_facture_medecin_admin=lookup_widget(button,"valider_modification_facture_medecin_admin");
valider_modification_facture_medecin_admin=create_valider_modification_facture_medecin_admin();
gtk_widget_show(valider_modification_facture_medecin_admin);
output=lookup_widget(valider_modification_facture_medecin_admin,"entry_medecin_payer_admin5");
gtk_entry_set_text(GTK_ENTRY(output),d.janvier);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_medecin_admin,"label_cin_facture_medecin_valider_admin5");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_medecin_admin,"label_mois_facture_medecin_admin5");
gtk_label_set_text(GTK_LABEL(output2),"Janvier");}
else if (strcmp(s1,"Fevrier")==0)
{GtkWidget *output;
modifier_facture_medecin_admin=lookup_widget(button,"modifier_facture_medecin_admin");
gtk_widget_destroy(modifier_facture_medecin_admin);
valider_modification_facture_medecin_admin=lookup_widget(button,"valider_modification_facture_medecin_admin");
valider_modification_facture_medecin_admin=create_valider_modification_facture_medecin_admin();
gtk_widget_show(valider_modification_facture_medecin_admin);
output=lookup_widget(valider_modification_facture_medecin_admin,"entry_medecin_payer_admin5");
gtk_entry_set_text(GTK_ENTRY(output),d.fevrier);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_medecin_admin,"label_cin_facture_medecin_valider_admin5");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_medecin_admin,"label_mois_facture_medecin_admin5");
gtk_label_set_text(GTK_LABEL(output2),"Fevrier");}
else if (strcmp(s1,"Mars")==0)
{GtkWidget *output;
modifier_facture_medecin_admin=lookup_widget(button,"modifier_facture_medecin_admin");
gtk_widget_destroy(modifier_facture_medecin_admin);
valider_modification_facture_medecin_admin=lookup_widget(button,"valider_modification_facture_medecin_admin");
valider_modification_facture_medecin_admin=create_valider_modification_facture_medecin_admin();
gtk_widget_show(valider_modification_facture_medecin_admin);
output=lookup_widget(valider_modification_facture_medecin_admin,"entry_medecin_payer_admin5");
gtk_entry_set_text(GTK_ENTRY(output),d.mars);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_medecin_admin,"label_cin_facture_medecin_valider_admin5");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_medecin_admin,"label_mois_facture_medecin_admin5");
gtk_label_set_text(GTK_LABEL(output2),"Mars");}
else if (strcmp(s1,"Avril")==0)
{GtkWidget *output;
modifier_facture_medecin_admin=lookup_widget(button,"modifier_facture_medecin_admin");
gtk_widget_destroy(modifier_facture_medecin_admin);
valider_modification_facture_medecin_admin=lookup_widget(button,"valider_modification_facture_medecin_admin");
valider_modification_facture_medecin_admin=create_valider_modification_facture_medecin_admin();
gtk_widget_show(valider_modification_facture_medecin_admin);
output=lookup_widget(valider_modification_facture_medecin_admin,"entry_medecin_payer_admin5");
gtk_entry_set_text(GTK_ENTRY(output),d.avril);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_medecin_admin,"label_cin_facture_medecin_valider_admin5");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_medecin_admin,"label_mois_facture_medecin_admin5");
gtk_label_set_text(GTK_LABEL(output2),"Avril");}
else if (strcmp(s1,"Mai")==0)
{GtkWidget *output;
modifier_facture_medecin_admin=lookup_widget(button,"modifier_facture_medecin_admin");
gtk_widget_destroy(modifier_facture_medecin_admin);
valider_modification_facture_medecin_admin=lookup_widget(button,"valider_modification_facture_medecin_admin");
valider_modification_facture_medecin_admin=create_valider_modification_facture_medecin_admin();
gtk_widget_show(valider_modification_facture_medecin_admin);
output=lookup_widget(valider_modification_facture_medecin_admin,"entry_medecin_payer_admin5");
gtk_entry_set_text(GTK_ENTRY(output),d.mai);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_medecin_admin,"label_cin_facture_medecin_valider_admin5");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_medecin_admin,"label_mois_facture_medecin_admin5");
gtk_label_set_text(GTK_LABEL(output2),"Mai");}
else if (strcmp(s1,"Juin")==0)
{GtkWidget *output;
modifier_facture_medecin_admin=lookup_widget(button,"modifier_facture_medecin_admin");
gtk_widget_destroy(modifier_facture_medecin_admin);
valider_modification_facture_medecin_admin=lookup_widget(button,"valider_modification_facture_medecin_admin");
valider_modification_facture_medecin_admin=create_valider_modification_facture_medecin_admin();
gtk_widget_show(valider_modification_facture_medecin_admin);
output=lookup_widget(valider_modification_facture_medecin_admin,"entry_medecin_payer_admin5");
gtk_entry_set_text(GTK_ENTRY(output),d.juin);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_medecin_admin,"label_cin_facture_medecin_valider_admin5");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_medecin_admin,"label_mois_facture_medecin_admin5");
gtk_label_set_text(GTK_LABEL(output2),"Juin");}
else if (strcmp(s1,"Juillet")==0)
{GtkWidget *output;
modifier_facture_medecin_admin=lookup_widget(button,"modifier_facture_medecin_admin");
gtk_widget_destroy(modifier_facture_medecin_admin);
valider_modification_facture_medecin_admin=lookup_widget(button,"valider_modification_facture_medecin_admin");
valider_modification_facture_medecin_admin=create_valider_modification_facture_medecin_admin();
gtk_widget_show(valider_modification_facture_medecin_admin);
output=lookup_widget(valider_modification_facture_medecin_admin,"entry_medecin_payer_admin5");
gtk_entry_set_text(GTK_ENTRY(output),d.juillet);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_medecin_admin,"label_cin_facture_medecin_valider_admin5");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_medecin_admin,"label_mois_facture_medecin_admin5");
gtk_label_set_text(GTK_LABEL(output2),"Juillet");}
else if (strcmp(s1,"Aout")==0)
{GtkWidget *output;
modifier_facture_medecin_admin=lookup_widget(button,"modifier_facture_medecin_admin");
gtk_widget_destroy(modifier_facture_medecin_admin);
valider_modification_facture_medecin_admin=lookup_widget(button,"valider_modification_facture_medecin_admin");
valider_modification_facture_medecin_admin=create_valider_modification_facture_medecin_admin();
gtk_widget_show(valider_modification_facture_medecin_admin);
output=lookup_widget(valider_modification_facture_medecin_admin,"entry_medecin_payer_admin5");
gtk_entry_set_text(GTK_ENTRY(output),d.aout);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_medecin_admin,"label_cin_facture_medecin_valider_admin5");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_medecin_admin,"label_mois_facture_medecin_admin5");
gtk_label_set_text(GTK_LABEL(output2),"Aout");}
else if (strcmp(s1,"Septembre")==0)
{GtkWidget *output;
modifier_facture_medecin_admin=lookup_widget(button,"modifier_facture_medecin_admin");
gtk_widget_destroy(modifier_facture_medecin_admin);
valider_modification_facture_medecin_admin=lookup_widget(button,"valider_modification_facture_medecin_admin");
valider_modification_facture_medecin_admin=create_valider_modification_facture_medecin_admin();
gtk_widget_show(valider_modification_facture_medecin_admin);
output=lookup_widget(valider_modification_facture_medecin_admin,"entry_medecin_payer_admin5");
gtk_entry_set_text(GTK_ENTRY(output),d.septembre);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_medecin_admin,"label_cin_facture_medecin_valider_admin5");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_medecin_admin,"label_mois_facture_medecin_admin5");
gtk_label_set_text(GTK_LABEL(output2),"Septembre");}
else if (strcmp(s1,"Octobre")==0)
{GtkWidget *output;
modifier_facture_medecin_admin=lookup_widget(button,"modifier_facture_medecin_admin");
gtk_widget_destroy(modifier_facture_medecin_admin);
valider_modification_facture_medecin_admin=lookup_widget(button,"valider_modification_facture_medecin_admin");
valider_modification_facture_medecin_admin=create_valider_modification_facture_medecin_admin();
gtk_widget_show(valider_modification_facture_medecin_admin);
output=lookup_widget(valider_modification_facture_medecin_admin,"entry_medecin_payer_admin5");
gtk_entry_set_text(GTK_ENTRY(output),d.octobre);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_medecin_admin,"label_cin_facture_medecin_valider_admin5");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_medecin_admin,"label_mois_facture_medecin_admin5");
gtk_label_set_text(GTK_LABEL(output2),"Octobre");}
else if (strcmp(s1,"Novembre")==0)
{GtkWidget *output;
modifier_facture_medecin_admin=lookup_widget(button,"modifier_facture_medecin_admin");
gtk_widget_destroy(modifier_facture_medecin_admin);
valider_modification_facture_medecin_admin=lookup_widget(button,"valider_modification_facture_medecin_admin");
valider_modification_facture_medecin_admin=create_valider_modification_facture_medecin_admin();
gtk_widget_show(valider_modification_facture_medecin_admin);
output=lookup_widget(valider_modification_facture_medecin_admin,"entry_medecin_payer_admin5");
gtk_entry_set_text(GTK_ENTRY(output),d.novembre);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_medecin_admin,"label_cin_facture_medecin_valider_admin5");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_medecin_admin,"label_mois_facture_medecin_admin5");
gtk_label_set_text(GTK_LABEL(output2),"Novembre");}
else if (strcmp(s1,"Decembre")==0)
{GtkWidget *output;
modifier_facture_medecin_admin=lookup_widget(button,"modifier_facture_medecin_admin");
gtk_widget_destroy(modifier_facture_medecin_admin);
valider_modification_facture_medecin_admin=lookup_widget(button,"valider_modification_facture_medecin_admin");
valider_modification_facture_medecin_admin=create_valider_modification_facture_medecin_admin();
gtk_widget_show(valider_modification_facture_medecin_admin);
output=lookup_widget(valider_modification_facture_medecin_admin,"entry_medecin_payer_admin5");
gtk_entry_set_text(GTK_ENTRY(output),d.decembre);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_medecin_admin,"label_cin_facture_medecin_valider_admin5");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_medecin_admin,"label_mois_facture_medecin_admin5");
gtk_label_set_text(GTK_LABEL(output2),"Decembre");}}}
fclose(f);
}


void
on_button_verification_payement_kine_admin1_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *input;
GtkWidget *input1;

char s[20];
char s1[20];
kine_f d;
memset(s1, 0, sizeof(s1));
FILE *f;

input=lookup_widget(modifier_facture_kine_admin,"entry_cin_modifier_kine_abonnement_admin");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(input)));
input1=lookup_widget(modifier_facture_kine_admin,"combobox_mois_facture_kine_admin");
strcpy(s1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)));
f=fopen("liste_deskinesfacture.txt","r");
while (fscanf(f," %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre)!=EOF)
{if (strcmp(s,d.cin)==0)
{if (strcmp(s1,"Janvier")==0)
	
{GtkWidget *output;
modifier_facture_kine_admin=lookup_widget(button,"modifier_facture_kine_admin");
gtk_widget_destroy(modifier_facture_kine_admin);
valider_modification_facture_kine_admin=lookup_widget(button,"valider_modification_facture_kine_admin");
valider_modification_facture_kine_admin=create_valider_modification_facture_kine_admin();
gtk_widget_show(valider_modification_facture_kine_admin);
output=lookup_widget(valider_modification_facture_kine_admin,"entry_kine_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.janvier);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_kine_admin,"label_cin_facture_kine_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_kine_admin,"label_mois_facture_kine_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Janvier");}
else if (strcmp(s1,"Fevrier")==0)
{GtkWidget *output;
modifier_facture_kine_admin=lookup_widget(button,"modifier_facture_kine_admin");
gtk_widget_destroy(modifier_facture_kine_admin);
valider_modification_facture_kine_admin=lookup_widget(button,"valider_modification_facture_kine_admin");
valider_modification_facture_kine_admin=create_valider_modification_facture_kine_admin();
gtk_widget_show(valider_modification_facture_kine_admin);
output=lookup_widget(valider_modification_facture_kine_admin,"entry_kine_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.fevrier);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_kine_admin,"label_cin_facture_kine_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_kine_admin,"label_mois_facture_kine_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Fevrier");}
else if (strcmp(s1,"Mars")==0)
{GtkWidget *output;
modifier_facture_kine_admin=lookup_widget(button,"modifier_facture_kine_admin");
gtk_widget_destroy(modifier_facture_kine_admin);
valider_modification_facture_kine_admin=lookup_widget(button,"valider_modification_facture_kine_admin");
valider_modification_facture_kine_admin=create_valider_modification_facture_kine_admin();
gtk_widget_show(valider_modification_facture_kine_admin);
output=lookup_widget(valider_modification_facture_kine_admin,"entry_kine_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.mars);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_kine_admin,"label_cin_facture_kine_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_kine_admin,"label_mois_facture_kine_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Mars");}
else if (strcmp(s1,"Avril")==0)
{GtkWidget *output;
modifier_facture_kine_admin=lookup_widget(button,"modifier_facture_kine_admin");
gtk_widget_destroy(modifier_facture_kine_admin);
valider_modification_facture_kine_admin=lookup_widget(button,"valider_modification_facture_kine_admin");
valider_modification_facture_kine_admin=create_valider_modification_facture_kine_admin();
gtk_widget_show(valider_modification_facture_kine_admin);
output=lookup_widget(valider_modification_facture_kine_admin,"entry_kine_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.avril);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_kine_admin,"label_cin_facture_kine_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_kine_admin,"label_mois_facture_kine_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Avril");}
else if (strcmp(s1,"Mai")==0)
{GtkWidget *output;
modifier_facture_kine_admin=lookup_widget(button,"modifier_facture_kine_admin");
gtk_widget_destroy(modifier_facture_kine_admin);
valider_modification_facture_kine_admin=lookup_widget(button,"valider_modification_facture_kine_admin");
valider_modification_facture_kine_admin=create_valider_modification_facture_kine_admin();
gtk_widget_show(valider_modification_facture_kine_admin);
output=lookup_widget(valider_modification_facture_kine_admin,"entry_kine_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.mai);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_kine_admin,"label_cin_facture_kine_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_kine_admin,"label_mois_facture_kine_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Mai");}
else if (strcmp(s1,"Juin")==0)
{GtkWidget *output;
modifier_facture_kine_admin=lookup_widget(button,"modifier_facture_kine_admin");
gtk_widget_destroy(modifier_facture_kine_admin);
valider_modification_facture_kine_admin=lookup_widget(button,"valider_modification_facture_kine_admin");
valider_modification_facture_kine_admin=create_valider_modification_facture_kine_admin();
gtk_widget_show(valider_modification_facture_kine_admin);
output=lookup_widget(valider_modification_facture_kine_admin,"entry_kine_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.juin);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_kine_admin,"label_cin_facture_kine_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_kine_admin,"label_mois_facture_kine_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Juin");}
else if (strcmp(s1,"Juillet")==0)
{GtkWidget *output;
modifier_facture_kine_admin=lookup_widget(button,"modifier_facture_kine_admin");
gtk_widget_destroy(modifier_facture_kine_admin);
valider_modification_facture_kine_admin=lookup_widget(button,"valider_modification_facture_kine_admin");
valider_modification_facture_kine_admin=create_valider_modification_facture_kine_admin();
gtk_widget_show(valider_modification_facture_kine_admin);
output=lookup_widget(valider_modification_facture_kine_admin,"entry_kine_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.juillet);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_kine_admin,"label_cin_facture_kine_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_kine_admin,"label_mois_facture_kine_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Juillet");}
else if (strcmp(s1,"Aout")==0)
{GtkWidget *output;
modifier_facture_kine_admin=lookup_widget(button,"modifier_facture_kine_admin");
gtk_widget_destroy(modifier_facture_kine_admin);
valider_modification_facture_kine_admin=lookup_widget(button,"valider_modification_facture_kine_admin");
valider_modification_facture_kine_admin=create_valider_modification_facture_kine_admin();
gtk_widget_show(valider_modification_facture_kine_admin);
output=lookup_widget(valider_modification_facture_kine_admin,"entry_kine_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.aout);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_kine_admin,"label_cin_facture_kine_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_kine_admin,"label_mois_facture_kine_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Aout");}
else if (strcmp(s1,"Septembre")==0)
{GtkWidget *output;
modifier_facture_kine_admin=lookup_widget(button,"modifier_facture_kine_admin");
gtk_widget_destroy(modifier_facture_kine_admin);
valider_modification_facture_kine_admin=lookup_widget(button,"valider_modification_facture_kine_admin");
valider_modification_facture_kine_admin=create_valider_modification_facture_kine_admin();
gtk_widget_show(valider_modification_facture_kine_admin);
output=lookup_widget(valider_modification_facture_kine_admin,"entry_kine_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.septembre);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_kine_admin,"label_cin_facture_kine_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_kine_admin,"label_mois_facture_kine_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Septembre");}
else if (strcmp(s1,"Octobre")==0)
{GtkWidget *output;
modifier_facture_kine_admin=lookup_widget(button,"modifier_facture_kine_admin");
gtk_widget_destroy(modifier_facture_kine_admin);
valider_modification_facture_kine_admin=lookup_widget(button,"valider_modification_facture_kine_admin");
valider_modification_facture_kine_admin=create_valider_modification_facture_kine_admin();
gtk_widget_show(valider_modification_facture_kine_admin);
output=lookup_widget(valider_modification_facture_kine_admin,"entry_kine_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.octobre);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_kine_admin,"label_cin_facture_kine_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_kine_admin,"label_mois_facture_kine_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Octobre");}
else if (strcmp(s1,"Novembre")==0)
{GtkWidget *output;
modifier_facture_kine_admin=lookup_widget(button,"modifier_facture_kine_admin");
gtk_widget_destroy(modifier_facture_kine_admin);
valider_modification_facture_kine_admin=lookup_widget(button,"valider_modification_facture_kine_admin");
valider_modification_facture_kine_admin=create_valider_modification_facture_kine_admin();
gtk_widget_show(valider_modification_facture_kine_admin);
output=lookup_widget(valider_modification_facture_kine_admin,"entry_kine_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.novembre);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_kine_admin,"label_cin_facture_kine_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_kine_admin,"label_mois_facture_kine_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Novembre");}
else if (strcmp(s1,"Decembre")==0)
{GtkWidget *output;
modifier_facture_kine_admin=lookup_widget(button,"modifier_facture_kine_admin");
gtk_widget_destroy(modifier_facture_kine_admin);
valider_modification_facture_kine_admin=lookup_widget(button,"valider_modification_facture_kine_admin");
valider_modification_facture_kine_admin=create_valider_modification_facture_kine_admin();
gtk_widget_show(valider_modification_facture_kine_admin);
output=lookup_widget(valider_modification_facture_kine_admin,"entry_kine_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.decembre);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_kine_admin,"label_cin_facture_kine_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_kine_admin,"label_mois_facture_kine_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Decembre");}}}
fclose(f);
}


void
on_button_verification_payement_agent_admin1_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *input;
GtkWidget *input1;

char s[20];
char s1[20];
agent_f d;
memset(s1, 0, sizeof(s1));
FILE *f;

input=lookup_widget(modifier_facture_agent_admin,"entry_cin_modifier_agent_abonnement_admin");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(input)));
input1=lookup_widget(modifier_facture_agent_admin,"combobox_mois_facture_agent_admin");
strcpy(s1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)));
f=fopen("liste_desagentsfacture.txt","r");
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre)!=EOF)
{if (strcmp(s,d.cin)==0)
{if (strcmp(s1,"Janvier")==0)
	
{GtkWidget *output;
modifier_facture_agent_admin=lookup_widget(button,"modifier_facture_agent_admin");
gtk_widget_destroy(modifier_facture_agent_admin);
valider_modification_facture_agent_admin=lookup_widget(button,"valider_modification_facture_agent_admin");
valider_modification_facture_agent_admin=create_valider_modification_facture_agent_admin();
gtk_widget_show(valider_modification_facture_agent_admin);
output=lookup_widget(valider_modification_facture_agent_admin,"entry_agent_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.janvier);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_agent_admin,"label_cin_facture_agent_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_agent_admin,"label_mois_facture_agent_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Janvier");}
else if (strcmp(s1,"Fevrier")==0)
{GtkWidget *output;
modifier_facture_agent_admin=lookup_widget(button,"modifier_facture_agent_admin");
gtk_widget_destroy(modifier_facture_agent_admin);
valider_modification_facture_agent_admin=lookup_widget(button,"valider_modification_facture_agent_admin");
valider_modification_facture_agent_admin=create_valider_modification_facture_agent_admin();
gtk_widget_show(valider_modification_facture_agent_admin);
output=lookup_widget(valider_modification_facture_agent_admin,"entry_agent_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.fevrier);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_agent_admin,"label_cin_facture_agent_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_agent_admin,"label_mois_facture_agent_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Fevrier");}
else if (strcmp(s1,"Mars")==0)
{GtkWidget *output;
modifier_facture_agent_admin=lookup_widget(button,"modifier_facture_agent_admin");
gtk_widget_destroy(modifier_facture_agent_admin);
valider_modification_facture_agent_admin=lookup_widget(button,"valider_modification_facture_agent_admin");
valider_modification_facture_agent_admin=create_valider_modification_facture_agent_admin();
gtk_widget_show(valider_modification_facture_agent_admin);
output=lookup_widget(valider_modification_facture_agent_admin,"entry_agent_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.mars);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_agent_admin,"label_cin_facture_agent_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_agent_admin,"label_mois_facture_agent_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Mars");}
else if (strcmp(s1,"Avril")==0)
{GtkWidget *output;
modifier_facture_agent_admin=lookup_widget(button,"modifier_facture_agent_admin");
gtk_widget_destroy(modifier_facture_agent_admin);
valider_modification_facture_agent_admin=lookup_widget(button,"valider_modification_facture_agent_admin");
valider_modification_facture_agent_admin=create_valider_modification_facture_agent_admin();
gtk_widget_show(valider_modification_facture_agent_admin);
output=lookup_widget(valider_modification_facture_agent_admin,"entry_agent_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.avril);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_agent_admin,"label_cin_facture_agent_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_agent_admin,"label_mois_facture_agent_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Avril");}
else if (strcmp(s1,"Mai")==0)
{GtkWidget *output;
modifier_facture_agent_admin=lookup_widget(button,"modifier_facture_agent_admin");
gtk_widget_destroy(modifier_facture_agent_admin);
valider_modification_facture_agent_admin=lookup_widget(button,"valider_modification_facture_agent_admin");
valider_modification_facture_agent_admin=create_valider_modification_facture_agent_admin();
gtk_widget_show(valider_modification_facture_agent_admin);
output=lookup_widget(valider_modification_facture_agent_admin,"entry_agent_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.mai);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_agent_admin,"label_cin_facture_agent_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_agent_admin,"label_mois_facture_agent_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Mai");}
else if (strcmp(s1,"Juin")==0)
{GtkWidget *output;
modifier_facture_agent_admin=lookup_widget(button,"modifier_facture_agent_admin");
gtk_widget_destroy(modifier_facture_agent_admin);
valider_modification_facture_agent_admin=lookup_widget(button,"valider_modification_facture_agent_admin");
valider_modification_facture_agent_admin=create_valider_modification_facture_agent_admin();
gtk_widget_show(valider_modification_facture_agent_admin);
output=lookup_widget(valider_modification_facture_agent_admin,"entry_agent_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.juin);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_agent_admin,"label_cin_facture_agent_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_agent_admin,"label_mois_facture_agent_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Juin");}
else if (strcmp(s1,"Juillet")==0)
{GtkWidget *output;
modifier_facture_agent_admin=lookup_widget(button,"modifier_facture_agent_admin");
gtk_widget_destroy(modifier_facture_agent_admin);
valider_modification_facture_agent_admin=lookup_widget(button,"valider_modification_facture_agent_admin");
valider_modification_facture_agent_admin=create_valider_modification_facture_agent_admin();
gtk_widget_show(valider_modification_facture_agent_admin);
output=lookup_widget(valider_modification_facture_agent_admin,"entry_agent_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.juillet);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_agent_admin,"label_cin_facture_agent_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_agent_admin,"label_mois_facture_agent_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Juillet");}
else if (strcmp(s1,"Aout")==0)
{GtkWidget *output;
modifier_facture_agent_admin=lookup_widget(button,"modifier_facture_agent_admin");
gtk_widget_destroy(modifier_facture_agent_admin);
valider_modification_facture_agent_admin=lookup_widget(button,"valider_modification_facture_agent_admin");
valider_modification_facture_agent_admin=create_valider_modification_facture_agent_admin();
gtk_widget_show(valider_modification_facture_agent_admin);
output=lookup_widget(valider_modification_facture_agent_admin,"entry_agent_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.aout);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_agent_admin,"label_cin_facture_agent_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_agent_admin,"label_mois_facture_agent_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Aout");}
else if (strcmp(s1,"Septembre")==0)
{GtkWidget *output;
modifier_facture_agent_admin=lookup_widget(button,"modifier_facture_agent_admin");
gtk_widget_destroy(modifier_facture_agent_admin);
valider_modification_facture_agent_admin=lookup_widget(button,"valider_modification_facture_agent_admin");
valider_modification_facture_agent_admin=create_valider_modification_facture_agent_admin();
gtk_widget_show(valider_modification_facture_agent_admin);
output=lookup_widget(valider_modification_facture_agent_admin,"entry_agent_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.septembre);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_agent_admin,"label_cin_facture_agent_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_agent_admin,"label_mois_facture_agent_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Septembre");}
else if (strcmp(s1,"Octobre")==0)
{GtkWidget *output;
modifier_facture_agent_admin=lookup_widget(button,"modifier_facture_agent_admin");
gtk_widget_destroy(modifier_facture_agent_admin);
valider_modification_facture_agent_admin=lookup_widget(button,"valider_modification_facture_agent_admin");
valider_modification_facture_agent_admin=create_valider_modification_facture_agent_admin();
gtk_widget_show(valider_modification_facture_agent_admin);
output=lookup_widget(valider_modification_facture_agent_admin,"entry_agent_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.octobre);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_agent_admin,"label_cin_facture_agent_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_agent_admin,"label_mois_facture_agent_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Octobre");}
else if (strcmp(s1,"Novembre")==0)
{GtkWidget *output;
modifier_facture_agent_admin=lookup_widget(button,"modifier_facture_agent_admin");
gtk_widget_destroy(modifier_facture_agent_admin);
valider_modification_facture_agent_admin=lookup_widget(button,"valider_modification_facture_agent_admin");
valider_modification_facture_agent_admin=create_valider_modification_facture_agent_admin();
gtk_widget_show(valider_modification_facture_agent_admin);
output=lookup_widget(valider_modification_facture_agent_admin,"entry_agent_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.novembre);
GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_agent_admin,"label_cin_facture_agent_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_agent_admin,"label_mois_facture_agent_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Novembre");}
else if (strcmp(s1,"Decembre")==0)
{GtkWidget *output;
modifier_facture_agent_admin=lookup_widget(button,"modifier_facture_agent_admin");
gtk_widget_destroy(modifier_facture_agent_admin);
valider_modification_facture_agent_admin=lookup_widget(button,"valider_modification_facture_agent_admin");
valider_modification_facture_agent_admin=create_valider_modification_facture_agent_admin();
gtk_widget_show(valider_modification_facture_agent_admin);
output=lookup_widget(valider_modification_facture_agent_admin,"entry_agent_payer_admin");
gtk_entry_set_text(GTK_ENTRY(output),d.decembre);

GtkWidget *output1;
GtkWidget *output2;
output1=lookup_widget(valider_modification_facture_agent_admin,"label_cin_facture_agent_valider_admin1");
gtk_label_set_text(GTK_LABEL(output1),d.cin);
output2=lookup_widget(valider_modification_facture_agent_admin,"label_mois_facture_agent_admin1");
gtk_label_set_text(GTK_LABEL(output2),"Decembre");}}}
fclose(f);
}



void
on_button_retour_verification_gestion_abonnement_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
modifier_abonnement_admin=lookup_widget(button,"modifier_abonnement_admin");
gtk_widget_destroy(modifier_abonnement_admin);

}



void
on_button_retour_verification_coach_gestion_facture_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
modifier_facture_coach_admin=lookup_widget(button,"modifier_facture_coach_admin");
gtk_widget_destroy(modifier_facture_coach_admin);
}




void
on_button_retour_verification_medecin_gestion_facture_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
modifier_facture_medecin_admin=lookup_widget(button,"modifier_facture_medecin_admin");
gtk_widget_destroy(modifier_facture_medecin_admin);
}




void
on_button_retour_verification_kine_gestion_facture_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
modifier_facture_kine_admin=lookup_widget(button,"modifier_facture_kine_admin");
gtk_widget_destroy(modifier_facture_kine_admin);
}




void
on_button_retour_verification_agent_gestion_facture_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
modifier_facture_agent_admin=lookup_widget(button,"modifier_facture_agent_admin");
gtk_widget_destroy(modifier_facture_agent_admin);
}




void
on_button_valider_modification_abonnement_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *input;
GtkWidget *input1;
GtkWidget *input2;

char s[20];
char s1[20];
char s2[20];
adherent_f d;
memset(s1, 0, sizeof(s1));
FILE *f;
FILE *f1;

input=lookup_widget(valider_modification_abonnement_admin,"label_cin_abonnement_adh_valider_admin5");
strcpy(s,gtk_label_get_text(GTK_LABEL(input)));
input1=lookup_widget(valider_modification_abonnement_admin,"label_mois_abonnement_adh_admin5");
strcpy(s1,gtk_label_get_text(GTK_LABEL(input1)));
input2=lookup_widget(valider_modification_abonnement_admin,"entry_adh_payer_admin5");
strcpy(s2,gtk_entry_get_text(GTK_ENTRY(input2)));
f=fopen("liste_desadherents_abonnement.txt","r");
f1=fopen("liste_desadherents_abonnement1.txt","a+");
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre)!=EOF)
{if (strcmp(s,d.cin)!=0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp("Janvier",s1)==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,s2,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp("Fevrier",s1)==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,s2,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp("Mars",s1)==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,s2,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp("Avril",s1)==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,s2,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Mai")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,s2,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Juin")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,s2,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Juillet")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,s2,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Aout")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,s2,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Septembre")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,s2,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Octobre")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,s2,d.novembre,d.decembre);
}
else if (strcmp(s1,"Novembre")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,s2,d.decembre);
}
else if (strcmp(s1,"Decembre")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,s2);
}}
fclose(f);
fclose(f1);
remove("liste_desadherents_abonnement.txt");
rename("liste_desadherents_abonnement1.txt","liste_desadherents_abonnement.txt");
valider_modification_abonnement_admin=lookup_widget(button,"valider_modification_abonnement_admin");
gtk_widget_destroy(valider_modification_abonnement_admin);

GtkWidget *treeview1;
GtkWidget *treeview2;
GtkWidget *treeview3;
GtkWidget *treeview4;
GtkWidget *treeview5;
treeview1=lookup_widget(gestion_abonnement_factures,"treeview_liste_abonnement_admin");
afficher_abonnement_adherent(treeview1);

treeview2=lookup_widget(gestion_abonnement_factures,"treeview_liste_facture_coach_admin");
afficher_facture_coach(treeview2);

treeview3=lookup_widget(gestion_abonnement_factures,"treeview_liste_facture_medecin_admin");
afficher_facture_medecin(treeview3);

treeview4=lookup_widget(gestion_abonnement_factures,"treeview_liste_facture_kine_admin");
afficher_facture_kine(treeview4);

treeview5=lookup_widget(gestion_abonnement_factures,"treeview_liste_facture_agent_admin");
afficher_facture_agent(treeview5);
}


void
on_button_valider_modification_facture_coach_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *input;
GtkWidget *input1;
GtkWidget *input2;

char s[20];
char s1[20];
char s2[20];
coach_f d;
memset(s1, 0, sizeof(s1));
FILE *f;
FILE *f1;

input=lookup_widget(valider_modification_facture_coach_admin,"label_cin_facture_coach_valider_admin1");
strcpy(s,gtk_label_get_text(GTK_LABEL(input)));
input1=lookup_widget(valider_modification_facture_coach_admin,"label_mois_facture_coach_admin1");
strcpy(s1,gtk_label_get_text(GTK_LABEL(input1)));
input2=lookup_widget(valider_modification_facture_coach_admin,"entry_coach_payer_admin");
strcpy(s2,gtk_entry_get_text(GTK_ENTRY(input2)));
f=fopen("liste_descoachsfacture.txt","r");
f1=fopen("liste_descoachsfacture1.txt","a+");
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre)!=EOF)
{if (strcmp(s,d.cin)!=0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp("Janvier",s1)==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,s2,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp("Fevrier",s1)==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,s2,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp("Mars",s1)==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,s2,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp("Avril",s1)==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,s2,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Mai")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,s2,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Juin")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,s2,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Juillet")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,s2,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Aout")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,s2,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Septembre")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,s2,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Octobre")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,s2,d.novembre,d.decembre);
}
else if (strcmp(s1,"Novembre")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,s2,d.decembre);
}
else if (strcmp(s1,"Decembre")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,s2);
}}
fclose(f);
fclose(f1);
remove("liste_descoachsfacture.txt");
rename("liste_descoachsfacture1.txt","liste_descoachsfacture.txt");
valider_modification_facture_coach_admin=lookup_widget(button,"valider_modification_facture_coach_admin");
gtk_widget_destroy(valider_modification_facture_coach_admin);

GtkWidget *treeview1;
GtkWidget *treeview2;
GtkWidget *treeview3;
GtkWidget *treeview4;
GtkWidget *treeview5;
treeview1=lookup_widget(gestion_abonnement_factures,"treeview_liste_abonnement_admin");
afficher_abonnement_adherent(treeview1);

treeview2=lookup_widget(gestion_abonnement_factures,"treeview_liste_facture_coach_admin");
afficher_facture_coach(treeview2);

treeview3=lookup_widget(gestion_abonnement_factures,"treeview_liste_facture_medecin_admin");
afficher_facture_medecin(treeview3);

treeview4=lookup_widget(gestion_abonnement_factures,"treeview_liste_facture_kine_admin");
afficher_facture_kine(treeview4);

treeview5=lookup_widget(gestion_abonnement_factures,"treeview_liste_facture_agent_admin");
afficher_facture_agent(treeview5);
}

void
on_button_valider_modification_facture_medecin_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *input;
GtkWidget *input1;
GtkWidget *input2;

char s[20];
char s1[20];
char s2[20];
medecin_f d;
memset(s1, 0, sizeof(s1));
FILE *f;
FILE *f1;

input=lookup_widget(valider_modification_facture_medecin_admin,"label_cin_facture_medecin_valider_admin5");
strcpy(s,gtk_label_get_text(GTK_LABEL(input)));
input1=lookup_widget(valider_modification_facture_medecin_admin,"label_mois_facture_medecin_admin5");
strcpy(s1,gtk_label_get_text(GTK_LABEL(input1)));
input2=lookup_widget(valider_modification_facture_medecin_admin,"entry_medecin_payer_admin5");
strcpy(s2,gtk_entry_get_text(GTK_ENTRY(input2)));
f=fopen("liste_desmedecinsfacture.txt","r");
f1=fopen("liste_desmedecinsfacture1.txt","a+");
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre)!=EOF)
{if (strcmp(s,d.cin)!=0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp("Janvier",s1)==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,s2,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp("Fevrier",s1)==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,s2,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp("Mars",s1)==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,s2,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp("Avril",s1)==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,s2,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Mai")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,s2,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Juin")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,s2,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Juillet")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,s2,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Aout")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,s2,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Septembre")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,s2,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Octobre")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,s2,d.novembre,d.decembre);
}
else if (strcmp(s1,"Novembre")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,s2,d.decembre);
}
else if (strcmp(s1,"Decembre")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,s2);
}}
fclose(f);
fclose(f1);
remove("liste_desmedecinsfacture.txt");
rename("liste_desmedecinsfacture1.txt","liste_desmedecinsfacture.txt");
valider_modification_facture_medecin_admin=lookup_widget(button,"valider_modification_facture_medecin_admin");
gtk_widget_destroy(valider_modification_facture_medecin_admin);

GtkWidget *treeview1;
GtkWidget *treeview2;
GtkWidget *treeview3;
GtkWidget *treeview4;
GtkWidget *treeview5;
treeview1=lookup_widget(gestion_abonnement_factures,"treeview_liste_abonnement_admin");
afficher_abonnement_adherent(treeview1);

treeview2=lookup_widget(gestion_abonnement_factures,"treeview_liste_facture_coach_admin");
afficher_facture_coach(treeview2);

treeview3=lookup_widget(gestion_abonnement_factures,"treeview_liste_facture_medecin_admin");
afficher_facture_medecin(treeview3);

treeview4=lookup_widget(gestion_abonnement_factures,"treeview_liste_facture_kine_admin");
afficher_facture_kine(treeview4);

treeview5=lookup_widget(gestion_abonnement_factures,"treeview_liste_facture_agent_admin");
afficher_facture_agent(treeview5);
}


void
on_button_valider_modification_facture_kine_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *input;
GtkWidget *input1;
GtkWidget *input2;

char s[20];
char s1[20];
char s2[20];
kine_f d;
memset(s1, 0, sizeof(s1));
FILE *f;
FILE *f1;

input=lookup_widget(valider_modification_facture_kine_admin,"label_cin_facture_kine_valider_admin1");
strcpy(s,gtk_label_get_text(GTK_LABEL(input)));
input1=lookup_widget(valider_modification_facture_kine_admin,"label_mois_facture_kine_admin1");
strcpy(s1,gtk_label_get_text(GTK_LABEL(input1)));
input2=lookup_widget(valider_modification_facture_kine_admin,"entry_kine_payer_admin");
strcpy(s2,gtk_entry_get_text(GTK_ENTRY(input2)));
f=fopen("liste_deskinesfacture.txt","r");
f1=fopen("liste_deskinesfacture1.txt","a+");
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre)!=EOF)
{if (strcmp(s,d.cin)!=0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp("Janvier",s1)==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,s2,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp("Fevrier",s1)==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,s2,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp("Mars",s1)==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,s2,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp("Avril",s1)==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,s2,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Mai")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,s2,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Juin")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,s2,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Juillet")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,s2,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Aout")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,s2,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Septembre")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,s2,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Octobre")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,s2,d.novembre,d.decembre);
}
else if (strcmp(s1,"Novembre")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,s2,d.decembre);
}
else if (strcmp(s1,"Decembre")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,s2);
}}
fclose(f);
fclose(f1);
remove("liste_deskinesfacture.txt");
rename("liste_deskinesfacture1.txt","liste_deskinesfacture.txt");
valider_modification_facture_kine_admin=lookup_widget(button,"valider_modification_facture_kine_admin");
gtk_widget_destroy(valider_modification_facture_kine_admin);

GtkWidget *treeview1;
GtkWidget *treeview2;
GtkWidget *treeview3;
GtkWidget *treeview4;
GtkWidget *treeview5;
treeview1=lookup_widget(gestion_abonnement_factures,"treeview_liste_abonnement_admin");
afficher_abonnement_adherent(treeview1);

treeview2=lookup_widget(gestion_abonnement_factures,"treeview_liste_facture_coach_admin");
afficher_facture_coach(treeview2);

treeview3=lookup_widget(gestion_abonnement_factures,"treeview_liste_facture_medecin_admin");
afficher_facture_medecin(treeview3);

treeview4=lookup_widget(gestion_abonnement_factures,"treeview_liste_facture_kine_admin");
afficher_facture_kine(treeview4);

treeview5=lookup_widget(gestion_abonnement_factures,"treeview_liste_facture_agent_admin");
afficher_facture_agent(treeview5);
}


void
on_button_valider_modification_facture_agent_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *input;
GtkWidget *input1;
GtkWidget *input2;

char s[20];
char s1[20];
char s2[20];
agent_f d;
memset(s1, 0, sizeof(s1));
FILE *f;
FILE *f1;

input=lookup_widget(valider_modification_facture_agent_admin,"label_cin_facture_agent_valider_admin1");
strcpy(s,gtk_label_get_text(GTK_LABEL(input)));
input1=lookup_widget(valider_modification_facture_agent_admin,"label_mois_facture_agent_admin1");
strcpy(s1,gtk_label_get_text(GTK_LABEL(input1)));
input2=lookup_widget(valider_modification_facture_agent_admin,"entry_agent_payer_admin");
strcpy(s2,gtk_entry_get_text(GTK_ENTRY(input2)));
f=fopen("liste_desagentsfacture.txt","r");
f1=fopen("liste_desagentsfacture1.txt","a+");
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre)!=EOF)
{if (strcmp(s,d.cin)!=0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp("Janvier",s1)==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,s2,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp("Fevrier",s1)==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,s2,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp("Mars",s1)==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,s2,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp("Avril",s1)==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,s2,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Mai")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,s2,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Juin")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,s2,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Juillet")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,s2,d.aout,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Aout")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,s2,d.septembre,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Septembre")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,s2,d.octobre,d.novembre,d.decembre);
}
else if (strcmp(s1,"Octobre")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,s2,d.novembre,d.decembre);
}
else if (strcmp(s1,"Novembre")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,s2,d.decembre);
}
else if (strcmp(s1,"Decembre")==0)
{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,s2);
}}
fclose(f);
fclose(f1);
remove("liste_desagentsfacture.txt");
rename("liste_desagentsfacture1.txt","liste_desagentsfacture.txt");
valider_modification_facture_agent_admin=lookup_widget(button,"valider_modification_facture_agent_admin");
gtk_widget_destroy(valider_modification_facture_agent_admin);

GtkWidget *treeview1;
GtkWidget *treeview2;
GtkWidget *treeview3;
GtkWidget *treeview4;
GtkWidget *treeview5;
treeview1=lookup_widget(gestion_abonnement_factures,"treeview_liste_abonnement_admin");
afficher_abonnement_adherent(treeview1);

treeview2=lookup_widget(gestion_abonnement_factures,"treeview_liste_facture_coach_admin");
afficher_facture_coach(treeview2);

treeview3=lookup_widget(gestion_abonnement_factures,"treeview_liste_facture_medecin_admin");
afficher_facture_medecin(treeview3);

treeview4=lookup_widget(gestion_abonnement_factures,"treeview_liste_facture_kine_admin");
afficher_facture_kine(treeview4);

treeview5=lookup_widget(gestion_abonnement_factures,"treeview_liste_facture_agent_admin");
afficher_facture_agent(treeview5);
}



//statistiques et Avis


void
on_button_afficher_taux_presence_adh_seance_admin_clicked
                                        (GtkWidget      *button,
                                        gpointer         user_data)
{
afficher_taux_pres_adh_seance_admin=create_afficher_taux_pres_adh_seance_admin();
gtk_widget_show(afficher_taux_pres_adh_seance_admin);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"statistique_admin")));
}




void
on_button_valider_taux_admin_clicked   (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *input;
GtkWidget *output;
GtkWidget *output1;

char s[400];
char s2[400];
int v;
int i=0;
float s1;
adherent_f d;

FILE *f;

input=lookup_widget(afficher_taux_pres_adh_seance_admin,"entry_nb_present_adh_taux_admin1");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(input)));
v=atoi(s);
f=fopen("liste_desadherents_abonnement.txt","r");
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s\n",d.nom,d.prenom,d.cin,d.janvier,d.fevrier,d.mars,d.avril,d.mai,d.juin,d.juillet,d.aout,d.septembre,d.octobre,d.novembre,d.decembre)!=EOF)
{i++;}
fclose(f);
s1=v*100/(float)i;
memset(s2,0,sizeof(s2));
sprintf(s2,"%.2f",s1);

output=lookup_widget(afficher_taux_pres_adh_seance_admin,"label_message_taux_admin1");
gtk_label_set_text(GTK_LABEL(output),"Le taux de présence est: ");
strcat(s2," %");
output1=lookup_widget(afficher_taux_pres_adh_seance_admin,"label_taux_final_admin1");
gtk_label_set_text(GTK_LABEL(output1),s2);
}


void
on_button_retour_taux_presence_menu_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
menu_admin=create_menu_admin();
gtk_widget_show(menu_admin);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"statistique_admin")));
}


void
on_retour_avis_salle_menu_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
menu_admin=create_menu_admin();
gtk_widget_show(menu_admin);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"statistique_admin")));
}


void
on_retour_avis_coach_menu_admin1_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
menu_admin=create_menu_admin();
gtk_widget_show(menu_admin);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"statistique_admin")));
}


void
on_retour_avis_kine_menu_admin_clicked (GtkWidget       *button,
                                        gpointer         user_data)
{
menu_admin=create_menu_admin();
gtk_widget_show(menu_admin);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"statistique_admin")));
}


void
on_retour_avis_medecin_menu_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
menu_admin=create_menu_admin();
gtk_widget_show(menu_admin);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"statistique_admin")));
}

void
on_button_retour_choix_taux_stats_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
statistique_admin=create_statistique_admin();
gtk_widget_show(statistique_admin);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"afficher_taux_pres_adh_seance_admin")));

GtkWidget *output;
GtkWidget *output1;
GtkWidget *treeview1;
GtkWidget *treeview2;
GtkWidget *treeview3;
GtkWidget *treeview4;
FILE *f;FILE *f1;
char s[30],s1[30],s2[30],s3[30],s4[30];
int rdv=0;
char rdv1[400];
int nb_s=0;
char nb_s1[400];

f=fopen("rendez_vous_coach.txt","r");
while(fscanf(f,"%s %s %s %s %s \n",s,s1,s2,s3,s4)!=EOF)
{rdv++;}
fclose(f);
f=fopen("rendez_vous_kine.txt","r");
while(fscanf(f,"%s %s %s %s %s \n",s,s1,s2,s3,s4)!=EOF)
{rdv++;}
fclose(f);
f=fopen("rendez_vous_medecin.txt","r");
while(fscanf(f,"%s %s %s %s %s \n",s,s1,s2,s3,s4)!=EOF)
{rdv++;}
fclose(f);
sprintf(rdv1,"%d",rdv);
output=lookup_widget(statistique_admin,"entry_nb_rdv_semaine_admin");
gtk_entry_set_text(GTK_ENTRY(output),rdv1);

f=fopen("nbseance_coach.txt","r");
while(fscanf(f,"%s %s %s %s %s \n",s,s1,s2,s3,s4)!=EOF)
{nb_s++;}
fclose(f);
f=fopen("nbseance_kine.txt","r");
while(fscanf(f,"%s %s %s %s %s \n",s,s1,s2,s3,s4)!=EOF)
{nb_s++;}
fclose(f);
f=fopen("nbseance_medecin.txt","r");
while(fscanf(f,"%s %s %s %s %s \n",s,s1,s2,s3,s4)!=EOF)
{nb_s++;}
fclose(f);
sprintf(nb_s1,"%d",nb_s);
output1=lookup_widget(statistique_admin,"entry_nb_seance_semaine_admin");
gtk_entry_set_text(GTK_ENTRY(output1),nb_s1);

treeview1=lookup_widget(statistique_admin,"treeview1_avis_salle_admin");
afficher_avissalle(treeview1);

treeview2=lookup_widget(statistique_admin,"treeview2_avis_coach_admin");
afficher_aviscoach(treeview2);

treeview3=lookup_widget(statistique_admin,"treeview4_avis_medecin");
afficher_avismedecin(treeview3);

treeview4=lookup_widget(statistique_admin,"treeview3_avis_kine_admin");
afficher_aviskine(treeview4);
}

//page d'accueil

void
on_button_se_connecter_page_accueil1_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
Authentification_admin=create_Authentification_admin();
gtk_widget_show(Authentification_admin);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"page_d_accueil_admin1")));
}


void
on_button_home_menu_admin_clicked      (GtkWidget       *button,
                                        gpointer         user_data)
{
page_accueil_admin=create_page_accueil_admin();
gtk_widget_show(page_accueil_admin);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"menu_admin")));

GtkWidget *output;
GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;
GtkWidget *output6;
GtkWidget *output7;
GtkWidget *output8;
GtkWidget *output9;
GtkWidget *output10;
GtkWidget *output11;
FILE *f;FILE *f1; FILE *f2;
char s[30],s1[30],s2[30],s3[30],s4[30];

f=fopen("info_coord.txt","r");
while(fscanf(f,"%s %s %s %s %s \n",s,s1,s2,s3,s4)!=EOF)
output=lookup_widget(page_accueil_admin,"label_nom_salle_page_accueil1");
gtk_label_set_text(GTK_LABEL(output),s);
output1=lookup_widget(page_accueil_admin,"label_tel_salle_page_accueil1");
gtk_label_set_text(GTK_LABEL(output1),s2);
output2=lookup_widget(page_accueil_admin,"label_email_salle_page_accueil1");
gtk_label_set_text(GTK_LABEL(output2),s3);
output3=lookup_widget(page_accueil_admin,"label_adresse_salle_page_accueil1");
gtk_label_set_text(GTK_LABEL(output3),s4);
fclose(f);

f1=fopen("liste_desdeals.txt","r");
while(fscanf(f1,"%s %s %s %s %s \n",s,s1,s2,s3,s4)!=EOF)
output4=lookup_widget(page_accueil_admin,"label_nom_actuel_deal_page_accueil1");
gtk_label_set_text(GTK_LABEL(output4),s);
output5=lookup_widget(page_accueil_admin,"label_dated_deal_page_accueil1");
gtk_label_set_text(GTK_LABEL(output5),s1);
output6=lookup_widget(page_accueil_admin,"label_datef_deal_page_accueil1");
gtk_label_set_text(GTK_LABEL(output6),s2);
output7=lookup_widget(page_accueil_admin,"label_prix_deal_page_accueil1");
gtk_label_set_text(GTK_LABEL(output7),s3);
fclose(f1);

f2=fopen("liste_desevenements.txt","r");
while(fscanf(f2,"%s %s %s %s \n",s,s1,s2,s3)!=EOF)
output9=lookup_widget(page_accueil_admin,"label_nom_event_page_accueil1");
gtk_label_set_text(GTK_LABEL(output9),s);
output10=lookup_widget(page_accueil_admin,"label_date_event_page_accueil1");
gtk_label_set_text(GTK_LABEL(output10),s1);
output11=lookup_widget(page_accueil_admin,"label_event_prix_page_accueil1");
gtk_label_set_text(GTK_LABEL(output11),s2);

fclose(f2);
}


void
on_button_quitter_app_clicked          (GtkWidget       *button,
                                        gpointer         user_data)
{
gtk_main_quit();
}


void
on_button_retour_page_accueil_menu_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
menu_admin=create_menu_admin();
gtk_widget_show(menu_admin);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"page_accueil_admin")));
}


void
on_button_se_deco_accueil_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
page_d_accueil_admin1=create_page_d_accueil_admin1();
gtk_widget_show(page_d_accueil_admin1);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"page_accueil_admin")));

GtkWidget *output;
GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;
GtkWidget *output6;
GtkWidget *output7;
GtkWidget *output8;
GtkWidget *output9;
GtkWidget *output10;
GtkWidget *output11;
FILE *f;FILE *f1; FILE *f2;
char s[30],s1[30],s2[30],s3[30],s4[30];

f=fopen("info_coord.txt","r");
while(fscanf(f,"%s %s %s %s %s \n",s,s1,s2,s3,s4)!=EOF)
output=lookup_widget(page_d_accueil_admin1,"label_nom_salle_page_accueil");
gtk_label_set_text(GTK_LABEL(output),s);
output1=lookup_widget(page_d_accueil_admin1,"label_tel_salle_page_accueil");
gtk_label_set_text(GTK_LABEL(output1),s2);
output2=lookup_widget(page_d_accueil_admin1,"label_email_salle_page_accueil");
gtk_label_set_text(GTK_LABEL(output2),s3);
output3=lookup_widget(page_d_accueil_admin1,"label_adresse_salle_page_accueil");
gtk_label_set_text(GTK_LABEL(output3),s4);
fclose(f);

f1=fopen("liste_desdeals.txt","r");
while(fscanf(f1,"%s %s %s %s %s \n",s,s1,s2,s3,s4)!=EOF)
output4=lookup_widget(page_d_accueil_admin1,"label_nom_actuel_deal_page_accueil");
gtk_label_set_text(GTK_LABEL(output4),s);
output5=lookup_widget(page_d_accueil_admin1,"label_dated_deal_page_accueil");
gtk_label_set_text(GTK_LABEL(output5),s1);
output6=lookup_widget(page_d_accueil_admin1,"label_datef_deal_page_accueil");
gtk_label_set_text(GTK_LABEL(output6),s2);
output7=lookup_widget(page_d_accueil_admin1,"label_prix_deal_page_accueil");
gtk_label_set_text(GTK_LABEL(output7),s3);
fclose(f1);

f2=fopen("liste_desevenements.txt","r");
while(fscanf(f2,"%s %s %s %s \n",s,s1,s2,s3)!=EOF)
output9=lookup_widget(page_d_accueil_admin1,"label_nom_event_page_accueil");
gtk_label_set_text(GTK_LABEL(output9),s);
output10=lookup_widget(page_d_accueil_admin1,"label_date_event_page_accueil");
gtk_label_set_text(GTK_LABEL(output10),s1);
output11=lookup_widget(page_d_accueil_admin1,"label_event_prix_page_accueil");
gtk_label_set_text(GTK_LABEL(output11),s2);

fclose(f2);
}


//MARIEM


//compte dieteticien 

void
on_Cdiet_clicked                       (GtkWidget     *button,
                                        gpointer         user_data)
{
comptediet=create_comptediet();
gtk_widget_show(comptediet);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"compte")));
      

treeviewcdiet=lookup_widget(comptediet,"treeviewcdiet");

afficherlistecomptediet(treeviewcdiet);

}


void
on_Cadherent_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
compte=lookup_widget(objet_graphique,"compte");
gtk_widget_destroy(compte);
trei=lookup_widget(objet_graphique,"trei");
trei=create_trei();

gtk_widget_show(trei);
      

treeview1=lookup_widget(trei,"treeview1");

afficherpersonne(treeview1);
}


void
on_Ccoch_clicked                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
Gestioncomptecoach=create_Gestioncomptecoach();
gtk_widget_show(Gestioncomptecoach);
gtk_widget_hide(GTK_WIDGET(lookup_widget(objet_graphique,"compte")));
      

treeviewcomptecoach=lookup_widget(Gestioncomptecoach,"treeviewcomptecoach");

afficherlistecoach(treeviewcomptecoach);
}


void
on_Cnuti_clicked                       (GtkWidget       *button,
                                        gpointer         user_data)
{
infonut=create_infonut();
gtk_widget_show(infonut);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"compte")));
treeviewnut=lookup_widget(infonut,"treeviewnut");

afficherlistecomptenut(treeviewnut);
}


void
on_Ckine_clicked                       (GtkWidget       *button,
                                        gpointer         user_data)
{
compte=lookup_widget(button,"compte");
gtk_widget_destroy(compte);
comptekine=lookup_widget(button,"comptekine");
comptekine=create_comptekine();

gtk_widget_show(comptekine);
      

treeviewcomptekine=lookup_widget(comptekine,"treeviewcomptekine");

afficherlistecomptekine(treeviewcomptekine);
}

void
on_reretourmenu_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
menu_admin=create_menu_admin();
gtk_widget_show(menu_admin);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"compte")));
}

void
on_Retourcompte_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
compte=create_compte();
gtk_widget_show(compte);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"trei")));
}



void
on_cherchercoach_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_Ajadh_clicked                       (GtkWidget       *button,
                                        gpointer         user_data)
{
info=create_info();
gtk_widget_show(info);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"trei")));
}


void
on_retourlista_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
info=lookup_widget(objet_graphique,"info");
gtk_widget_destroy(info);
trei=lookup_widget(objet_graphique,"trei");
trei=create_trei();

gtk_widget_show(trei);
      

treeview1=lookup_widget(trei,"treeview1");

afficherpersonne(treeview1); 
}


//planing diet//
void
on_plandiete_clicked                   (GtkWidget        *button,
                                        gpointer         user_data)
{
lesplane=lookup_widget(button,"lesplane");
gtk_widget_destroy(lesplane);
listeplaningdiet=lookup_widget(button,"listeplaningdiet");
listeplaningdiet=create_listeplaningdiet();

gtk_widget_show(listeplaningdiet);
      

treeviewplaningdiet=lookup_widget(listeplaningdiet,"treeviewplaningdiet");

afficherlistediet(treeviewplaningdiet);
}


//liste des coachs //

void
on_plancoche_clicked                   (GtkWidget        *button,
                                        gpointer         user_data)
{
lesplane=lookup_widget(button,"lesplane");
gtk_widget_destroy(lesplane);
listedesplanningdescoach=lookup_widget(button,"listedesplanningdescoach");
listedesplanningdescoach=create_listedesplanningdescoach();

gtk_widget_show(listedesplanningdescoach);
      

treeviewcoachp=lookup_widget(listedesplanningdescoach,"treeviewcoachp");

afficherlistePcoach(treeviewcoachp);
}


//planing nutri//
void
on_planenutr_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
lesplane=lookup_widget(button,"lesplane");
gtk_widget_destroy(lesplane);
listeplaningnut=lookup_widget(button,"listeplaningnut");
listeplaningnut=create_listeplaningnut();

gtk_widget_show(listeplaningnut);
      

treeviewpnut=lookup_widget(listeplaningnut,"treeviewpnut");

afficherlistenut(treeviewpnut);

}


//planing kine // 
void
on_plankine_clicked                    (GtkWidget        *button,
                                        gpointer         user_data)
{

lesplane=lookup_widget(button,"lesplane");
gtk_widget_destroy(lesplane);
listeplaningkine=lookup_widget(button,"listeplaningkine");
listeplaningkine=create_listeplaningkine();

gtk_widget_show(listeplaningkine);
      

treeviewpkine=lookup_widget(listeplaningkine,"treeviewpkine");

afficherlistekine(treeviewpkine);
}


//planing agent/
void
on_planeage_clicked                    (GtkWidget      *button,
                                        gpointer         user_data)
{
lesplane=lookup_widget(button,"lesplane");
gtk_widget_destroy(lesplane);
listeplaningagent=lookup_widget(button,"listeplaningagent");
listeplaningagent=create_listeplaningagent();

gtk_widget_show(listeplaningagent);
      

treeviewpagent=lookup_widget(listeplaningagent,"treeviewpagent");

afficherlisteagent(treeviewpagent);
}

void
on_retouraumenuaparirdesreclamcoach_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
menu_admin=create_menu_admin();
gtk_widget_show(menu_admin);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclammation")));
}


void
on_supprimyinfo_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_modifylesinfo_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_retourGestioncompteaparirdelalistedescoach_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget  *Gestioncomptecoach;
GtkWidget  *compte;
compte=create_compte();
gtk_widget_show(compte);
gtk_widget_hide(GTK_WIDGET(lookup_widget(objet_graphique,"Gestioncomptecoach")));
}


void
on_ajoutcoach_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
editeprofildescoach=create_editeprofildescoach();
gtk_widget_show(editeprofildescoach);
gtk_widget_hide(GTK_WIDGET(lookup_widget(objet_graphique,"Gestioncomptecoach")));
}



//afficher coach//
void
on_affichecoachchercher_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

coach e ;
int test;
char msg[50] ;
coachrechercher=create_coachrechercher();
gtk_widget_show(coachrechercher);
gtk_widget_hide(GTK_WIDGET(lookup_widget(objet_graphique,"Gestioncomptecoach")));
char s[30];
GtkWidget *inputrecherche;
GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;
GtkWidget *output6;
GtkWidget *output7;
GtkWidget *output8;
GtkWidget *output9;
GtkWidget *output;

inputrecherche=lookup_widget(objet_graphique,"entryrecherchecoach");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(inputrecherche)));

output1=lookup_widget(coachrechercher,"cherchercincoach");
output2=lookup_widget(coachrechercher,"cherchernomcoach");
output3=lookup_widget(coachrechercher,"chercherprenomcoach");
output4=lookup_widget(coachrechercher,"chercheradressecoach");
output5=lookup_widget(coachrechercher,"cherchermailcoach");
output6=lookup_widget(coachrechercher,"cherchernum");
output7=lookup_widget(coachrechercher,"chercherlogin");
output8=lookup_widget(coachrechercher,"chercherpasse");
output9=lookup_widget(coachrechercher,"cherchersp");

output=lookup_widget(coachrechercher,"Inexistant");

test=verif_coach(s);
if(test==1)
{
  e=chercher_coach(s);
gtk_label_set_text(GTK_LABEL(output),"");
gtk_entry_set_text(GTK_ENTRY(output1),e.cin);
gtk_entry_set_text(GTK_ENTRY(output2),e.nom);
gtk_entry_set_text(GTK_ENTRY(output3),e.prenom);
gtk_entry_set_text(GTK_ENTRY(output4),e.adresse);
gtk_entry_set_text(GTK_ENTRY(output5),e.mail);
gtk_entry_set_text(GTK_ENTRY(output6),e.num);
gtk_entry_set_text(GTK_ENTRY(output7),e.login);
gtk_entry_set_text(GTK_ENTRY(output8),e.mot);
gtk_entry_set_text(GTK_ENTRY(output9),e.sp);
}

if (test!=1)
	{
		gtk_label_set_text(GTK_LABEL(output),"identifiant inexistant ");
		
	}
}




void
on_affichelalistedescoach_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

editeprofildescoach=lookup_widget(objet_graphique,"editeprofildescoach");
gtk_widget_destroy(editeprofildescoach);
Gestioncomptecoach=lookup_widget(objet_graphique,"Gestioncomptecoach");
Gestioncomptecoach=create_Gestioncomptecoach();

gtk_widget_show(Gestioncomptecoach);
      

treeviewcomptecoach=lookup_widget(Gestioncomptecoach,"treeviewcomptecoach");

afficherlistecoach(treeviewcomptecoach); 
}


//ajouter coach //

void
on_ajoutercoach_clicked                (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
coach c;

GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget *input6;
GtkWidget *input7;
GtkWidget *input8;
GtkWidget *input9;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;

input1=lookup_widget(objet_graphique,"cincoach");
strcpy(c.cin,gtk_entry_get_text(GTK_ENTRY(input1)));
input2=lookup_widget(objet_graphique,"nomcoach");
strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
input3=lookup_widget(objet_graphique,"prenomcoach");
strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
input4=lookup_widget(objet_graphique,"adressecoach");
strcpy(c.adresse,gtk_entry_get_text(GTK_ENTRY(input4)));
input5=lookup_widget(objet_graphique,"emailcoach");
strcpy(c.mail,gtk_entry_get_text(GTK_ENTRY(input5)));
input6=lookup_widget(objet_graphique,"ntelcoach");
strcpy(c.num,gtk_entry_get_text(GTK_ENTRY(input6)));
input7=lookup_widget(objet_graphique,"logincoach");
strcpy(c.login,gtk_entry_get_text(GTK_ENTRY(input7)));
input8=lookup_widget(objet_graphique,"passecoach");
strcpy(c.mot,gtk_entry_get_text(GTK_ENTRY(input8)));
input9=lookup_widget(objet_graphique,"spcoach");
strcpy(c.sp,gtk_entry_get_text(GTK_ENTRY(input9)));

jour=lookup_widget(objet_graphique,"spinbuttonjcoach");
mois=lookup_widget(objet_graphique,"spinbuttonmcoach");
annee=lookup_widget(objet_graphique,"spinbuttonancoach");
c.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
c.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
c.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

ajoutercoach(c);
}


void
on_retourlistedescoach_clicked         (GtkWidget       *button,
                                        gpointer         user_data)
{
editeprofildescoach=lookup_widget(button,"editeprofildescoach");
gtk_widget_destroy(editeprofildescoach);
Gestioncomptecoach=lookup_widget(button,"Gestioncomptecoach");
Gestioncomptecoach=create_Gestioncomptecoach();

gtk_widget_show(Gestioncomptecoach);
      

treeviewcomptecoach=lookup_widget(Gestioncomptecoach,"treeviewcomptecoach");

afficherlistecoach(treeviewcomptecoach); 
}



void
on_retourlisteGestion_clicked          (GtkWidget       *button,
                                        gpointer         user_data)
{
coachrechercher=lookup_widget(button,"coachrechercher");
gtk_widget_destroy(coachrechercher);
Gestioncomptecoach=lookup_widget(button,"Gestioncomptecoach");
Gestioncomptecoach=create_Gestioncomptecoach();

gtk_widget_show(Gestioncomptecoach);
      

treeviewcomptecoach=lookup_widget(Gestioncomptecoach,"treeviewcomptecoach");

afficherlistecoach(treeviewcomptecoach); 

}



//supprimer coach //
void
on_Supprimerlecoachexistant__clicked   (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
coach e;


char s[30];
GtkWidget *input;


input=lookup_widget(Gestioncomptecoach,"entryrecherchecoach");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(input)));
supprimer_coach(s);



//Gestioncomptecoach=lookup_widget(objet_graphique,"Gestioncomptecoach");
//gtk_widget_destroy(Gestioncomptecoach);
//coachrechercher=lookup_widget(objet_graphique,"coachrechercher");
//coachrechercher=create_coachrechercher();

//gtk_widget_show(coachrechercher);
Gestioncomptecoach=create_Gestioncomptecoach();
gtk_widget_show(Gestioncomptecoach);
gtk_widget_hide(GTK_WIDGET(lookup_widget(objet_graphique,"coachrechercher")));      

treeviewcomptecoach=lookup_widget(Gestioncomptecoach,"treeviewcomptecoach");

afficherlistecoach(treeviewcomptecoach);

}



//modifier coach //

void
on_Modifierlecoachexistant_clicked     (GtkWidget       *button,
                                        gpointer         user_data)
{
coach e;
char s[20];

GtkWidget *input;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;
GtkWidget *output6;
GtkWidget *output9;
input=lookup_widget(Gestioncomptecoach,"entryrecherchecoach");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(input)));


output2=lookup_widget(coachrechercher,"cherchernomcoach");
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(output2)));

output3=lookup_widget(coachrechercher,"chercherprenomcoach");
strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(output3)));

output4=lookup_widget(coachrechercher,"chercheradressecoach");
strcpy(e.adresse,gtk_entry_get_text(GTK_ENTRY(output4)));

output5=lookup_widget(coachrechercher,"cherchermailcoach");
strcpy(e.mail,gtk_entry_get_text(GTK_ENTRY(output5)));

output6=lookup_widget(coachrechercher,"cherchernum");
strcpy(e.num,gtk_entry_get_text(GTK_ENTRY(output6)));

output9=lookup_widget(coachrechercher,"cherchersp");
strcpy(e.sp,gtk_entry_get_text(GTK_ENTRY(output9)));
{
FILE*f;
FILE*fsup;
char cin[20],nom[20],prenom[20],adresse[20],mail[20],num[20],login[20],mot[20],sp[20];
int jour,mois,annee;
fsup=fopen("coachesup.txt","a+");
f=fopen("coachee.txt","r");
while (fscanf(f,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",cin,nom,prenom,&jour,&mois,&annee,adresse,mail,num,login,mot,sp) !=EOF)
{
if(strcmp(s,cin)!=0)
{
 fprintf(fsup,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s\n",cin,nom,prenom,jour,mois,annee,adresse,mail,num,login,mot,sp); 
}     
else 
{
fprintf(fsup,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s\n",cin,e.nom,e.prenom,jour,mois,annee,e.adresse,e.mail,e.num,login,mot,e.sp);
}
}
fclose(f);
fclose(fsup);
remove("coachee.txt");
rename("coachesup.txt","coachee.txt");
}
Gestioncomptecoach=create_Gestioncomptecoach();
gtk_widget_show(Gestioncomptecoach);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"coachrechercher")));
treeviewcomptecoach=lookup_widget(Gestioncomptecoach,"treeviewcomptecoach");
afficherlistecoach(treeviewcomptecoach); 

}


void
on_retourduplaningauplane_clicked      (GtkWidget       *button,
                                        gpointer         user_data)
{
lesplane=create_lesplane();
gtk_widget_show(lesplane);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"listedesplanningdescoach")));
}


void
on_retourdeplaningkineauplane_clicked  (GtkWidget        *button,
                                        gpointer         user_data)
{
lesplane=create_lesplane();
gtk_widget_show(lesplane);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"listeplaningkine")));
}


void
on_retourduplaningkineauplane_clicked  (GtkWidget       *button,
                                        gpointer         user_data)
{
lesplane=create_lesplane();
gtk_widget_show(lesplane);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"listeplaningnut")));
}


void
on_retourplaningagentauplane_clicked   (GtkWidget       *button,
                                        gpointer         user_data)
{
lesplane=create_lesplane();
gtk_widget_show(lesplane);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"listeplaningagent")));
}

void
on_retourplaningdietauplane_clicked    (GtkWidget       *button,
                                        gpointer         user_data)
{
lesplane=create_lesplane();
gtk_widget_show(lesplane);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"listeplaningdiet")));
}


void
on_ajouterunnvkine_clicked             (GtkWidget       *button,
                                        gpointer         user_data)
{
kineinfo=create_kineinfo();
gtk_widget_show(kineinfo);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"comptekine")));
}


void
on_retourdelalistekineaucompte__clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
menu_admin=create_menu_admin();
gtk_widget_show(menu_admin);
gtk_widget_hide(GTK_WIDGET(lookup_widget(objet_graphique,"comptekine")));
}


void
on_Affichekinechercher_clicked         (GtkWidget       *button,
                                        gpointer         user_data)
{
kine t;
int test;

comptekineaman=create_comptekineaman();
gtk_widget_show(comptekineaman);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"comptekine")));
char m[30];
GtkWidget *input;
GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;
GtkWidget *output6;
GtkWidget *output7;
GtkWidget *output8;
GtkWidget *output9;
GtkWidget *output;

input=lookup_widget(button,"chercherkine");
strcpy(m,gtk_entry_get_text(GTK_ENTRY(input)));

output1=lookup_widget(comptekineaman,"cinkinee");
output2=lookup_widget(comptekineaman,"nomkinee");
output3=lookup_widget(comptekineaman,"prenomkinee");
output4=lookup_widget(comptekineaman,"adressekinee");
output5=lookup_widget(comptekineaman,"mailkinee");
output6=lookup_widget(comptekineaman,"numkinee");
output7=lookup_widget(comptekineaman,"loginkinee");
output8=lookup_widget(comptekineaman,"passekinee");
output9=lookup_widget(comptekineaman,"spkinee");

output=lookup_widget(comptekineaman,"Inexistantkine");

test=verif_kine(m);
if(test==1)
{
  t=chercher_kine(m);
gtk_label_set_text(GTK_LABEL(output),"");
gtk_entry_set_text(GTK_ENTRY(output1),t.cin);
gtk_entry_set_text(GTK_ENTRY(output2),t.nom);
gtk_entry_set_text(GTK_ENTRY(output3),t.prenom);
gtk_entry_set_text(GTK_ENTRY(output4),t.adresse);
gtk_entry_set_text(GTK_ENTRY(output5),t.mail);
gtk_entry_set_text(GTK_ENTRY(output6),t.num);
gtk_entry_set_text(GTK_ENTRY(output7),t.login);
gtk_entry_set_text(GTK_ENTRY(output8),t.mot);
gtk_entry_set_text(GTK_ENTRY(output9),t.sp);
}

if (test!=1)
	{
		gtk_label_set_text(GTK_LABEL(output),"identifiant inexistant ");
		
	}
}


void
on_afficherinfotreeview_clicked        (GtkWidget       *button,
                                        gpointer         user_data)
{
kineinfo=lookup_widget(button,"kineinfo");
gtk_widget_destroy(kineinfo);
comptekine=lookup_widget(button,"comptekine");
comptekine=create_comptekine();

gtk_widget_show(comptekine);
      

treeviewcomptekine=lookup_widget(comptekine,"treeviewcomptekine");

afficherlistecomptekine(treeviewcomptekine);
}


void
on_ajouterkine_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{
kine n;
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget *input6;
GtkWidget *input7;
GtkWidget *input8;
GtkWidget *input9;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;

input1=lookup_widget(button,"cinkine");
strcpy(n.cin,gtk_entry_get_text(GTK_ENTRY(input1)));
input2=lookup_widget(button,"nomkine");
strcpy(n.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
input3=lookup_widget(button,"prenomkine");
strcpy(n.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
input4=lookup_widget(button,"adressekine");
strcpy(n.adresse,gtk_entry_get_text(GTK_ENTRY(input4)));
input5=lookup_widget(button,"mailkine");
strcpy(n.mail,gtk_entry_get_text(GTK_ENTRY(input5)));
input6=lookup_widget(button,"numkine");
strcpy(n.num,gtk_entry_get_text(GTK_ENTRY(input6)));
input7=lookup_widget(button,"loginkine");
strcpy(n.login,gtk_entry_get_text(GTK_ENTRY(input7)));
input8=lookup_widget(button,"passekine");
strcpy(n.mot,gtk_entry_get_text(GTK_ENTRY(input8)));
input9=lookup_widget(button,"spkine");
strcpy(n.sp,gtk_entry_get_text(GTK_ENTRY(input9)));

jour=lookup_widget(button,"spinbuttonjkine");
mois=lookup_widget(button,"spinbuttonmkine");
annee=lookup_widget(button,"spinbuttonankine");
n.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
n.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
n.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

ajouterkine(n);
}


void
on_supprimerlesinfocomptekine_clicked  (GtkWidget       *button,
                                        gpointer         user_data)
{
kine t;

char m[30];
GtkWidget *input;


input=lookup_widget(comptekine,"chercherkine");
strcpy(m,gtk_entry_get_text(GTK_ENTRY(input)));
supprimer_kine(m);




comptekine=create_comptekine();
gtk_widget_show(comptekine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"comptekineaman")));      


treeviewcomptekine=lookup_widget(comptekine,"treeviewcomptekine");

afficherlistecomptekine(treeviewcomptekine); 
}


void
on_modifiercomptekineaman_clicked      (GtkWidget      *button,
                                        gpointer         user_data)
{
kine t;
char m[20];

GtkWidget *input;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;
GtkWidget *output6;
GtkWidget *output9;

input=lookup_widget(comptekine,"chercherkine");
strcpy(m,gtk_entry_get_text(GTK_ENTRY(input)));

output2=lookup_widget(comptekineaman,"nomkinee");
strcpy(t.nom,gtk_entry_get_text(GTK_ENTRY(output2)));
output3=lookup_widget(comptekineaman,"prenomkinee");
strcpy(t.prenom,gtk_entry_get_text(GTK_ENTRY(output3)));
output4=lookup_widget(comptekineaman,"adressekinee");
strcpy(t.adresse,gtk_entry_get_text(GTK_ENTRY(output4)));
output5=lookup_widget(comptekineaman,"mailkinee");
strcpy(t.mail,gtk_entry_get_text(GTK_ENTRY(output5)));
output6=lookup_widget(comptekineaman,"numkinee");
strcpy(t.num,gtk_entry_get_text(GTK_ENTRY(output6)));
output9=lookup_widget(comptekineaman,"spkinee");
strcpy(t.sp,gtk_entry_get_text(GTK_ENTRY(output9)));
{
FILE*fkc;
FILE*fsupkc;
char cin[20],nom[20],prenom[20],adresse[20],mail[20],num[20],login[20],mot[20],sp[20];
int jour,mois,annee;
fsupkc=fopen("kinesup.txt","a+");
fkc=fopen("kinee.txt","r");
while (fscanf(fkc,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",cin,nom,prenom,&jour,&mois,&annee,adresse,mail,num,login,mot,sp) !=EOF)
  {
if(strcmp(m,cin)!=0)
	{
 fprintf(fsupkc,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s\n",cin,nom,prenom,jour,mois,annee,adresse,mail,num,login,mot,sp); 
	}     
else 
	{
fprintf(fsupkc,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s\n",cin,t.nom,t.prenom,jour,mois,annee,t.adresse,t.mail,t.num,login,mot,t.sp);
	}
   }
fclose(fkc);
fclose(fsupkc);
remove("kinee.txt");
rename("kinesup.txt","kinee.txt");
}
comptekine=create_comptekine();
gtk_widget_show(comptekine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"comptekineaman")));
treeviewcomptekine=lookup_widget(comptekine,"treeviewcomptekine");

afficherlistecomptekine(treeviewcomptekine);
}


//ajouter un diet 
void
on_ajouterunnvdiet_clicked             (GtkWidget       *button,
                                        gpointer         user_data)
{
infodiet=create_infodiet();
gtk_widget_show(infodiet);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"comptediet")));
}




void
on_retourdudietauplan_clicked          (GtkWidget      *button,
                                        gpointer         user_data)
{
compte=create_compte();
gtk_widget_show(compte);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"comptediet")));
}




        //afficher les info tree
void
on_afficherdiet_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
diet z;
int test;

dietchercher=create_dietchercher();
gtk_widget_show(dietchercher);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"comptediet")));
char s[30];
GtkWidget *input;
GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;
GtkWidget *output6;
GtkWidget *output7;
GtkWidget *output8;
GtkWidget *output9;
GtkWidget *output;

input=lookup_widget(button,"rechercherdiet");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(input)));

output1=lookup_widget(dietchercher,"dcin");
output2=lookup_widget(dietchercher,"ndnom");
output3=lookup_widget(dietchercher,"dprenom");
output4=lookup_widget(dietchercher,"dadresse");
output5=lookup_widget(dietchercher,"dmail");
output6=lookup_widget(dietchercher,"dnum");
output7=lookup_widget(dietchercher,"dlogin");
output8=lookup_widget(dietchercher,"dpasse");
output9=lookup_widget(dietchercher,"dsp");

output=lookup_widget(comptediet,"Inexistantdiet");

test=verif_diet(s);
if(test==1)
{
  z=chercher_diet(s);
gtk_label_set_text(GTK_LABEL(output),"");
gtk_entry_set_text(GTK_ENTRY(output1),z.cin);
gtk_entry_set_text(GTK_ENTRY(output2),z.nom);
gtk_entry_set_text(GTK_ENTRY(output3),z.prenom);
gtk_entry_set_text(GTK_ENTRY(output4),z.adresse);
gtk_entry_set_text(GTK_ENTRY(output5),z.mail);
gtk_entry_set_text(GTK_ENTRY(output6),z.num);
gtk_entry_set_text(GTK_ENTRY(output7),z.login);
gtk_entry_set_text(GTK_ENTRY(output8),z.mot);
gtk_entry_set_text(GTK_ENTRY(output9),z.sp);
}

if (test!=1)
        {
                gtk_label_set_text(GTK_LABEL(output),"identifiant inexistant ");

        }
}





//afficher diet 
void
on_afficherlediet_clicked              (GtkWidget      *button,
                                        gpointer         user_data)
{

infodiet=lookup_widget(button,"infodiet");
gtk_widget_destroy(infodiet);
comptekine=lookup_widget(button,"comptediet");
comptediet=create_comptediet();

gtk_widget_show(comptediet);


treeviewcdiet=lookup_widget(comptediet,"treeviewcdiet");

afficherlistecomptediet(treeviewcdiet); 


}



//enregistrer un diet
void
on_ajouterlediet_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{
diet i;
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget *input6;
GtkWidget *input7;
GtkWidget *input8;
GtkWidget *input9;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;

input1=lookup_widget(infodiet,"cindiet");
strcpy(i.cin,gtk_entry_get_text(GTK_ENTRY(input1)));
input2=lookup_widget(infodiet,"nomdiet");
strcpy(i.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
input3=lookup_widget(infodiet,"prenomdiet");
strcpy(i.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
input4=lookup_widget(infodiet,"adressediet");
strcpy(i.adresse,gtk_entry_get_text(GTK_ENTRY(input4)));
input5=lookup_widget(infodiet,"maildiet");
strcpy(i.mail,gtk_entry_get_text(GTK_ENTRY(input5)));
input6=lookup_widget(infodiet,"numdiet");
strcpy(i.num,gtk_entry_get_text(GTK_ENTRY(input6)));
input7=lookup_widget(infodiet,"logindiet");
strcpy(i.login,gtk_entry_get_text(GTK_ENTRY(input7)));
input8=lookup_widget(infodiet,"pasdiet");
strcpy(i.mot,gtk_entry_get_text(GTK_ENTRY(input8)));
input9=lookup_widget(infodiet,"spdiet");
strcpy(i.sp,gtk_entry_get_text(GTK_ENTRY(input9)));

jour=lookup_widget(infodiet,"spinbuttonjdiet");
mois=lookup_widget(infodiet,"spinbuttonmdiet");
annee=lookup_widget(infodiet,"spinbuttonandiet");
i.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
i.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
i.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

ajouterdiet(i);
}



//supprimer diet 


void
on_supprimerdiet_clicked               (GtkWidget        *button,
                                        gpointer         user_data)
{
diet z;


char s[30];
GtkWidget *input;
input=lookup_widget(comptediet,"rechercherdiet");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(input)));


supprimer_diet(s);




comptediet=create_comptediet();
gtk_widget_show(comptediet);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"dietchercher")));   

treeviewcdiet=lookup_widget(comptediet,"treeviewcdiet");

afficherlistecomptediet(treeviewcdiet); 


}


//modifier diet 
void
on_modifierdiet_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
diet z;
char s[20];

GtkWidget *input;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;
GtkWidget *output6;
GtkWidget *output9;
input=lookup_widget(comptediet,"rechercherdiet");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(input)));


output2=lookup_widget(dietchercher,"dnom");
strcpy(z.nom,gtk_entry_get_text(GTK_ENTRY(output2)));

output3=lookup_widget(dietchercher,"dprenom");
strcpy(z.prenom,gtk_entry_get_text(GTK_ENTRY(output3)));

output4=lookup_widget(dietchercher,"dadresse");
strcpy(z.adresse,gtk_entry_get_text(GTK_ENTRY(output4)));

output5=lookup_widget(dietchercher,"dmail");
strcpy(z.mail,gtk_entry_get_text(GTK_ENTRY(output5)));

output6=lookup_widget(dietchercher,"dnum");
strcpy(z.num,gtk_entry_get_text(GTK_ENTRY(output6)));

output9=lookup_widget(dietchercher,"dsp");
strcpy(z.sp,gtk_entry_get_text(GTK_ENTRY(output9)));
 {
FILE*fd;
FILE*fsupd;
char cin[20],nom[20],prenom[20],adresse[20],mail[20],num[20],login[20],mot[20],sp[20];
int jour,mois,annee;
fsupd=fopen("dietesup.txt","a+");
fd=fopen("dietee.txt","r");
while (fscanf(fd,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",cin,nom,prenom,&jour,&mois,&annee,adresse,mail,num,login,mot,sp) !=EOF)
	{
if(strcmp(s,cin)!=0)
   {
 fprintf(fsupd,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s\n",cin,nom,prenom,jour,mois,annee,adresse,mail,num,login,mot,sp); 
   }     
else 
  	{
fprintf(fsupd,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s\n",cin,z.nom,z.prenom,jour,mois,annee,z.adresse,z.mail,z.num,login,mot,z.sp);
        }
}
fclose(fd);
fclose(fsupd);
remove("dietesup.txt");
rename("dietesup.txt","dietee.txt");
}
comptediet=create_comptediet();
gtk_widget_show(comptediet);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"dietchercher")));   

treeviewcdiet=lookup_widget(comptediet,"treeviewcdiet");

afficherlistecomptediet(treeviewcdiet); 
}



//retour diet 
void
on_retourdietliste_clicked             (GtkWidget      *button,
                                        gpointer         user_data)
{
comptediet=create_comptediet();
gtk_widget_show(comptediet);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"dietchercher")));
treeviewcdiet=lookup_widget(comptediet,"treeviewcdiet");

afficherlistecomptediet(treeviewcdiet); 
}


void
on_ajouterunnvnut_clicked              (GtkWidget       *button,
                                        gpointer         user_data)
{
ajoutnut=create_ajoutnut();
gtk_widget_show(ajoutnut);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"infonut")));
}


void
on_cherchernutee_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{
nut y;
int test;

nutaman=create_nutaman();
gtk_widget_show(nutaman);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"infonut")));
char m[30];
GtkWidget *input;
GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;
GtkWidget *output6;
GtkWidget *output7;
GtkWidget *output8;
GtkWidget *output9;
GtkWidget *output;

input=lookup_widget(button,"cherchernut");
strcpy(m,gtk_entry_get_text(GTK_ENTRY(input)));

output1=lookup_widget(nutaman,"cinnut");
output2=lookup_widget(nutaman,"nomnut");
output3=lookup_widget(nutaman,"prenomnut");
output4=lookup_widget(nutaman,"adressenut");
output5=lookup_widget(nutaman,"mailnut");
output6=lookup_widget(nutaman,"numnut");
output7=lookup_widget(nutaman,"loginnut");
output8=lookup_widget(nutaman,"passenut");
output9=lookup_widget(nutaman,"spnut");

output=lookup_widget(nutaman,"Inexistnatnut");

test=verif_nut(m);
if(test==1)
{
  y=chercher_nut(m);
gtk_label_set_text(GTK_LABEL(output),"");
gtk_entry_set_text(GTK_ENTRY(output1),y.cin);
gtk_entry_set_text(GTK_ENTRY(output2),y.nom);
gtk_entry_set_text(GTK_ENTRY(output3),y.prenom);
gtk_entry_set_text(GTK_ENTRY(output4),y.adresse);
gtk_entry_set_text(GTK_ENTRY(output5),y.mail);
gtk_entry_set_text(GTK_ENTRY(output6),y.num);
gtk_entry_set_text(GTK_ENTRY(output7),y.login);
gtk_entry_set_text(GTK_ENTRY(output8),y.mot);
gtk_entry_set_text(GTK_ENTRY(output9),y.sp);
}

if (test!=1)
	{
		gtk_label_set_text(GTK_LABEL(output),"identifiant inexistant ");
		
	}
}


void
on_afficher_nut__clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{
ajoutnut=lookup_widget(button,"ajoutnut");
gtk_widget_destroy(ajoutnut);
infonut=lookup_widget(button,"infonut");
infonut=create_infonut();

gtk_widget_show(infonut);
      

treeviewnut=lookup_widget(infonut,"treeviewnut");

afficherlistecomptenut(treeviewnut);
}


void
on_ajouternut_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
nut u;
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget *input6;
GtkWidget *input7;
GtkWidget *input8;
GtkWidget *input9;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;

input1=lookup_widget(button,"nutcin");
strcpy(u.cin,gtk_entry_get_text(GTK_ENTRY(input1)));
input2=lookup_widget(button,"nutnom");
strcpy(u.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
input3=lookup_widget(button,"nutprenom");
strcpy(u.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
input4=lookup_widget(button,"nutadresse");
strcpy(u.adresse,gtk_entry_get_text(GTK_ENTRY(input4)));
input5=lookup_widget(button,"nutmail");
strcpy(u.mail,gtk_entry_get_text(GTK_ENTRY(input5)));
input6=lookup_widget(button,"nutnum");
strcpy(u.num,gtk_entry_get_text(GTK_ENTRY(input6)));
input7=lookup_widget(button,"nutlogin");
strcpy(u.login,gtk_entry_get_text(GTK_ENTRY(input7)));
input8=lookup_widget(button,"nutpasse");
strcpy(u.mot,gtk_entry_get_text(GTK_ENTRY(input8)));
input9=lookup_widget(button,"nutsp");
strcpy(u.sp,gtk_entry_get_text(GTK_ENTRY(input9)));

jour=lookup_widget(button,"spinbuttonjnut");
mois=lookup_widget(button,"spinbuttonmnut");
annee=lookup_widget(button,"spinbuttonannut");
u.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
u.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
u.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

ajouternut(u);
}


void
on_retournut_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
nutaman=lookup_widget(button,"nutaman");
gtk_widget_destroy(nutaman);
infonut=lookup_widget(button,"infonut");
infonut=create_infonut();

gtk_widget_show(infonut);
      

treeviewnut=lookup_widget(infonut,"treeviewnut");

afficherlistecomptenut(treeviewnut);
}


void
on_supprimernut_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
nut y;

char m[30];
GtkWidget *input;


input=lookup_widget(infonut,"cherchernut");
strcpy(m,gtk_entry_get_text(GTK_ENTRY(input)));
supprimer_nut(m);


nutaman=lookup_widget(button,"nutaman");
gtk_widget_destroy(nutaman);
infonut=lookup_widget(button,"infonut");
infonut=create_infonut();

gtk_widget_show(infonut);
      

treeviewnut=lookup_widget(infonut,"treeviewnut");

afficherlistecomptenut(treeviewnut);
}


void
on_modifiernut_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{
nut y;
char s[20];

GtkWidget *input;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;
GtkWidget *output6;
GtkWidget *output9;

input=lookup_widget(infonut,"cherchernut");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(input)));

output2=lookup_widget(nutaman,"nomnut");
strcpy(y.nom,gtk_entry_get_text(GTK_ENTRY(output2)));
output3=lookup_widget(nutaman,"prenomnut");
strcpy(y.prenom,gtk_entry_get_text(GTK_ENTRY(output3)));
output4=lookup_widget(nutaman,"adressenut");
strcpy(y.adresse,gtk_entry_get_text(GTK_ENTRY(output4)));
output5=lookup_widget(nutaman,"mailnut");
strcpy(y.mail,gtk_entry_get_text(GTK_ENTRY(output5)));
output6=lookup_widget(nutaman,"numnut");
strcpy(y.num,gtk_entry_get_text(GTK_ENTRY(output6)));
output9=lookup_widget(nutaman,"spnut");
strcpy(y.sp,gtk_entry_get_text(GTK_ENTRY(output9)));
{
FILE*fn;
FILE*fsupn;
char cin[20],nom[20],prenom[20],adresse[20],mail[20],num[20],login[20],mot[20],sp[20];
int jour,mois,annee;

fn=fopen("nutrii.txt","r");
fsupn=fopen("nutriisup.txt","a+");
while (fscanf(fn,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",cin,nom,prenom,&jour,&mois,&annee,adresse,mail,num,login,mot,sp) !=EOF)
  {
if(strcmp(s,cin)!=0)
	{
 fprintf(fsupn,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s\n",cin,nom,prenom,jour,mois,annee,adresse,mail,num,login,mot,sp); 
	}     
else 
	{
fprintf(fsupn,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s\n",cin,y.nom,y.prenom,jour,mois,annee,y.adresse,y.mail,y.num,login,mot,y.sp);
	}
   }
fclose(fn);
fclose(fsupn);
remove("nutrii.txt");
rename("nutriisup.txt","nutrii.txt");
}
nutaman=lookup_widget(button,"nutaman");
gtk_widget_destroy(nutaman);
infonut=lookup_widget(button,"infonut");
infonut=create_infonut();

gtk_widget_show(infonut);
      

treeviewnut=lookup_widget(infonut,"treeviewnut");

afficherlistecomptenut(treeviewnut);
}

//retour plane //
void
on_Retourplans_clicked                 (GtkWidget        *button,
                                        gpointer         user_data)
{
menu_admin=create_menu_admin();
gtk_widget_show(menu_admin);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"lesplane")));
}




void
on_button_login_admin1_clicked         (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *login1;
GtkWidget *mdp1;
GtkWidget *verif;
int t;
char v[20],mdp[20],login[20];
espace_adherent=create_espace_adherent();
menu_admin=create_menu_admin();
espace_kine=create_espace_kine();
espace_agent=create_espace_agent();
login1=lookup_widget(button,"entry_login_admin");
mdp1=lookup_widget(button,"entry_mdp_admin");
verif=lookup_widget(button,"error d'authentification");
strcpy(login,gtk_entry_get_text(GTK_ENTRY(login1)));
strcpy(mdp,gtk_entry_get_text(GTK_ENTRY(mdp1)));
t=authentif(login,mdp);
switch (t)
{case -1 : strcpy(v,"-1");break;

case 1 : strcpy(v,"Admin");
gtk_widget_show(menu_admin);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Authentification_admin")));
break;

case 3 : strcpy(v,"Coach");
gtk_widget_show(espace_coach);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Authentification_admin")));
break;

case 2 : strcpy(v,"Adhérent");
gtk_widget_show(espace_adherent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Authentification_admin")));
break;

case 5 : strcpy(v,"Médecin nutritionniste");
gtk_widget_show(espace_medecin);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Authentification_admin")));

case 4 : strcpy(v,"Kinésithérapeute");
gtk_widget_show(espace_kine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Authentification_admin")));
break;

case 6 : strcpy(v,"Agent de Nétoyage");
gtk_widget_show(espace_agent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Authentification_admin")));
break;

case 7 : strcpy(v,"Diététicien");
gtk_widget_show(espace_diet);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Authentification_admin")));
break;

}
gtk_label_set_text(GTK_LABEL(verif),v);
}


void
on_button_retour_auth_page_accueil_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
page_d_accueil_admin1=create_page_d_accueil_admin1();
gtk_widget_show(page_d_accueil_admin1);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Authentification_admin")));
}


void
on_retour_nut__clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{
lesplane=create_lesplane();
gtk_widget_show(lesplane);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"infonut")));
}

