#include <gtk/gtk.h>

struct Diet
{
char cin[30];
char nom[30];
char prenom[30];
char login[100];
char mot[30];
char adresse[30];
char mail[30];
char num[30];
char sp[30];
int jour;
int mois;
int annee;
};
typedef struct Diet diet;

void ajouterdiet(diet w);
int verif_diet(char x[]);
diet chercher_diet(char x[]);
void supprimer_diet(char id[]);
