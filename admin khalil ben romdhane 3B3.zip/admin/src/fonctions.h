#include <gtk/gtk.h>
int authentif(char login[],char password[]);
//DEAL
typedef struct
{
char nom[30];
char date_debut[11];
char date_fin[11];
char prix[10];
char description[350];
}Deal;

void ajouter_deal(Deal d);

void afficher_deal(GtkWidget *liste);

void supprimer_deal(char s[]);

void modifier_deal(char s[], Deal d);

//EVENEMENT
typedef struct
{
char nom[30];
char date[11];
char description[350];
}Evenement;

void ajouter_event(Evenement e);

void afficher_event(GtkWidget *liste);

void supprimer_event(char s[]);

void modifier_event(char s[], Evenement e);

//ADHERENT
typedef struct
{
char nom[20];
char prenom[20];
char cin[9];
char janvier[5];
char fevrier[5];
char mars[5];
char avril[5];
char mai[5];
char juin[5];
char juillet[5];
char aout[5];
char septembre[5];
char octobre[5];
char novembre[5];
char decembre[5];
}adherent_f;

void afficher_abonnement_adherent(GtkWidget *liste);

//COACH
typedef struct
{
char nom[20];
char prenom[20];
char cin[9];
char janvier[5];
char fevrier[5];
char mars[5];
char avril[5];
char mai[5];
char juin[5];
char juillet[5];
char aout[5];
char septembre[5];
char octobre[5];
char novembre[5];
char decembre[5];
}coach_f;

void afficher_facture_coach(GtkWidget *liste);

//MEDECIN

typedef struct
{
char nom[20];
char prenom[20];
char cin[9];
char janvier[5];
char fevrier[5];
char mars[5];
char avril[5];
char mai[5];
char juin[5];
char juillet[5];
char aout[5];
char septembre[5];
char octobre[5];
char novembre[5];
char decembre[5];
}medecin_f;

void afficher_facture_medecin(GtkWidget *liste);

//KINE

typedef struct
{
char nom[20];
char prenom[20];
char cin[9];
char janvier[5];
char fevrier[5];
char mars[5];
char avril[5];
char mai[5];
char juin[5];
char juillet[5];
char aout[5];
char septembre[5];
char octobre[5];
char novembre[5];
char decembre[5];
}kine_f;

void afficher_facture_kine(GtkWidget *liste);

//AGENT

typedef struct
{
char nom[20];
char prenom[20];
char cin[9];
char janvier[5];
char fevrier[5];
char mars[5];
char avril[5];
char mai[5];
char juin[5];
char juillet[5];
char aout[5];
char septembre[5];
char octobre[5];
char novembre[5];
char decembre[5];
}agent_f;

void afficher_facture_agent(GtkWidget *liste);


//Statistiques et avis

void afficher_avissalle(GtkWidget *liste);

void afficher_aviscoach(GtkWidget *liste);

void afficher_avismedecin(GtkWidget *liste);

void afficher_aviskine(GtkWidget *liste);



