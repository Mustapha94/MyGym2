#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif



#include <gdk/gdk.h>
#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "treeviewm.h"
#include "coach.h"



enum   
{       
        CIN_COACH,
        NOM_COACH,
	PRENOM_COACH,
	AGE_COACH,
	ADRESSE_COACH,
	MAIL_COACH,
	NUM_COACH,
       	LOGIN_COACH,
	MOT_COACH,
	SP_COACH,
        COLUMNS_COACH
};

void afficherlistecoach(GtkWidget *treeview)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;

	char coachcin[50];
	char coachnom[50];
	char coachprenom[50];
	char coachage[50];
	char coachadresse[50];
	char coachmail[50];
	char coachnum[50];
	char coachlogin[50];
	char coachmot[50];
	char coachsp[50];
	
FILE *f;

	store=NULL;
	
		
	if (store==NULL)
	{

	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Cin", renderer, "text", CIN_COACH, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);


	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Nom", renderer, "text", NOM_COACH, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);


	 
	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Prénom", renderer, "text", PRENOM_COACH, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);
	
	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Age", renderer, "text", AGE_COACH, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);





	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Adresse", renderer, "text", ADRESSE_COACH, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);




	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Mail", renderer, "text", MAIL_COACH, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);



	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Numéro de telephone ", renderer, "text", NUM_COACH, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);

	
	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Login ", renderer, "text", LOGIN_COACH, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);





	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Mot de passe  ", renderer, "text", MOT_COACH, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);


	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Spécialité  ", renderer, "text", SP_COACH, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);
	
}
		store=gtk_list_store_new (COLUMNS_COACH , G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING);

	f = fopen("coachee.txt","r");


	if(f ==NULL)
	{
		printf("erreur d'ouverture ");
		return;
	}		
	else
	{
		while(fscanf(f,"%s %s %s %s %s %s %s %s  %s %s \n",coachcin,coachnom,coachprenom,coachage,coachadresse,coachmail,coachnum,coachlogin,coachmot,coachsp) !=EOF)
		{
			gtk_list_store_append (store, &iter);
			gtk_list_store_set (store, &iter, CIN_COACH, coachcin, NOM_COACH, coachnom, PRENOM_COACH,coachprenom, AGE_COACH, coachage, ADRESSE_COACH, coachadresse, MAIL_COACH, coachmail, NUM_COACH, coachnum, LOGIN_COACH, coachlogin, MOT_COACH, coachmot ,SP_COACH,coachsp, -1);
					
		}
		
		fclose(f);
		
	}
		
	gtk_tree_view_set_model (GTK_TREE_VIEW (treeview), GTK_TREE_MODEL (store));
	
	g_object_unref (store);
}










///*************************************************treeview des planing ///


enum   
{       
	CINP,
        JOURP,
        DEP,
	AP,
	COMMENTAIRE,
        COLUMNS_PCOACH
};


void afficherlistePcoach(GtkWidget *treeview)
{


	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;


	char cin[20];
	char jour[10];
	char de[10];
	char a[10];
	char commentaire[600];


FILE *fc;

	store=NULL;
	
		
	if (store==NULL)
	{


	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Cin", renderer, "text", CINP, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);

	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Jour", renderer, "text", JOURP, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);


	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("De", renderer, "text", DEP, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);


	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("à", renderer, "text", AP, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);


	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Commentaire    ", renderer, "text",COMMENTAIRE, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);
	}

	store=gtk_list_store_new (COLUMNS_PCOACH , G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

fc=fopen("planingcoach.txt","r");

	if(fc==NULL)
	{
		printf("erreur d'ouverture ");
		return;
	}		
	else
	{
		while(fscanf(fc,"%s %s %s %s %s ",cin,jour,de,a,commentaire) !=EOF)
		{
			gtk_list_store_append (store, &iter);
			gtk_list_store_set (store, &iter, CINP, cin, JOURP, jour, DEP, de, AP, a, COMMENTAIRE, commentaire,  -1);
					
		}
		
		fclose(fc);
		
	}
		
	gtk_tree_view_set_model (GTK_TREE_VIEW (treeview), GTK_TREE_MODEL (store));
	
	g_object_unref (store);
}

///*******************************planing des kine ///
enum   
{       
	CINPK,
        JOURPK,
        DEPK,
	APK,
	COMMENTAIREK,
        COLUMNS_PKINE
};

void afficherlistekine(GtkWidget *treeview)
{


	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;


	char cinK[20];
	char jourK[10];
	char deK[10];
	char aK[10];
	char commentaireK[600];


FILE *fk;

	store=NULL;
	
		
	if (store==NULL)
	{


	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Cin", renderer, "text", CINPK, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);

	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Jour", renderer, "text", JOURPK, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);


	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("De", renderer, "text", DEPK, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);


	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("à", renderer, "text", APK, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);


	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Commentaire    ", renderer, "text",COMMENTAIREK, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);
	}

	store=gtk_list_store_new (COLUMNS_PKINE, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

fk=fopen("planingkine.txt","r");

	if(fk==NULL)
	{
		printf("erreur d'ouverture ");
		return;
	}		
	else
	{
		while(fscanf(fk,"%s %s %s %s %s ",cinK,jourK,deK,aK,commentaireK) !=EOF)
		{
			gtk_list_store_append (store, &iter);
			gtk_list_store_set (store, &iter, CINPK, cinK, JOURPK, jourK, DEPK, deK, APK, aK, COMMENTAIREK, commentaireK,  -1);
					
		}
		
		fclose(fk);
		
	}
		
	gtk_tree_view_set_model (GTK_TREE_VIEW (treeview), GTK_TREE_MODEL (store));
	
	g_object_unref (store);
}





////*****************************planing nut/






enum   
{       
	CINPN,
        JOURPN,
        DEPN,
	APN,
	COMMENTAIREN,
        COLUMNS_PNUT
};

void afficherlistenut(GtkWidget *treeview)
{


	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;


	char cinN[20];
	char jourN[10];
	char deN[10];
	char aN[10];
	char commentaireN[600];


FILE *fn;

	store=NULL;
	
		
	if (store==NULL)
	{


	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Cin", renderer, "text", CINPN, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);

	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Jour", renderer, "text", JOURPN, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);


	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("De", renderer, "text", DEPN, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);


	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("à", renderer, "text", APN, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);


	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Commentaire    ", renderer, "text",COMMENTAIREN, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);
	}

	store=gtk_list_store_new (COLUMNS_PNUT, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

fn=fopen("planingnut.txt","r");

	if(fn==NULL)
	{
		printf("erreur d'ouverture ");
		return;
	}		
	else
	{
		while(fscanf(fn,"%s %s %s %s %s ",cinN,jourN,deN,aN,commentaireN) !=EOF)
		{
			gtk_list_store_append (store, &iter);
			gtk_list_store_set (store, &iter, CINPN, cinN, JOURPN, jourN, DEPN, deN, APN, aN, COMMENTAIREN, commentaireN,  -1);
					
		}
		
		fclose(fn);
		
	}
		
	gtk_tree_view_set_model (GTK_TREE_VIEW (treeview), GTK_TREE_MODEL (store));
	
	g_object_unref (store);
}


//**************planing agents de netoyage /


enum   
{       
	CINPA,
        JOURPA,
        DEPA,
	APA,
	COMMENTAIREA,
        COLUMNS_PAGENT
};

void afficherlisteagent(GtkWidget *treeview)
{


	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;


	char cinA[20];
	char jourA[10];
	char deA[10];
	char aA[10];
	char commentaireA[600];


FILE *fa;

	store=NULL;
	
		
	if (store==NULL)
	{


	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Cin", renderer, "text", CINPA, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);

	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Jour", renderer, "text", JOURPA, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);


	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("De", renderer, "text", DEPA, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);


	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("à", renderer, "text", APA, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);


	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Commentaire    ", renderer, "text",COMMENTAIREA, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);
	}

	store=gtk_list_store_new (COLUMNS_PAGENT, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

fa=fopen("planingagent.txt","r");

	if(fa==NULL)
	{
		printf("erreur d'ouverture ");
		return;
	}		
	else
	{
		while(fscanf(fa,"%s %s %s %s %s ",cinA,jourA,deA,aA,commentaireA) !=EOF)
		{
			gtk_list_store_append (store, &iter);
			gtk_list_store_set (store, &iter, CINPA, cinA, JOURPA, jourA, DEPA, deA, APA, aA, COMMENTAIREA, commentaireA,  -1);
					
		}
		
		fclose(fa);
		
	}
		
	gtk_tree_view_set_model (GTK_TREE_VIEW (treeview), GTK_TREE_MODEL (store));
	
	g_object_unref (store);
}



//***************planing des diéteticien /



enum   
{       
	CINPD,
        JOURPD,
        DEPD,
	APD,
	COMMENTAIRED,
        COLUMNS_PDIET
};

void afficherlistediet(GtkWidget *treeview)
{


	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;


	char cinD[20];
	char jourD[10];
	char deD[10];
	char aD[10];
	char commentaireD[600];


FILE *fd;

	store=NULL;
	
		
	if (store==NULL)
	{


	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Cin", renderer, "text", CINPD, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);

	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Jour", renderer, "text", JOURPD, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);


	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("De", renderer, "text", DEPD, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);


	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("à", renderer, "text", APD, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);


	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Commentaire    ", renderer, "text",COMMENTAIRED, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);
	}

	store=gtk_list_store_new (COLUMNS_PDIET, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

fd=fopen("planingdiet.txt","r");

	if(fd==NULL)
	{
		printf("erreur d'ouverture ");
		return;
	}		
	else
	{
		while(fscanf(fd,"%s %s %s %s %s ",cinD,jourD,deD,aD,commentaireD) !=EOF)
		{
			gtk_list_store_append (store, &iter);
			gtk_list_store_set (store, &iter, CINPD, cinD, JOURPD, jourD, DEPD, deD, APD, aD, COMMENTAIRED, commentaireD,  -1);
					
		}
		
		fclose(fd);
		
	}
		
	gtk_tree_view_set_model (GTK_TREE_VIEW (treeview), GTK_TREE_MODEL (store));
	
	g_object_unref (store);
}






//**********************************liste des compte kine/
enum   
{       
        CIN_CKINE,
        NOM_CKINE,
	PRENOM_CKINE,
	AGE_CKINE,
	ADRESSE_CKINE,
	MAIL_CKINE,
	NUM_CKINE,
       	LOGIN_CKINE,
	MOT_CKINE,
	SP_CKINE,
        COLUMNS_CKINE
};

void afficherlistecomptekine(GtkWidget *treeview)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;

	char kinecin[50];
	char kinenom[50];
	char kineprenom[50];
	char kineage[50];
	char kineadresse[50];
	char kinemail[50];
	char kinenum[50];
	char kinelogin[50];
	char kinemot[50];
	char kinesp[50];
	
FILE *fkc;

	store=NULL;
	
		
	if (store==NULL)
	{

	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Cin", renderer, "text", CIN_CKINE, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);


	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Nom", renderer, "text", NOM_CKINE, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);


	 
	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Prénom", renderer, "text", PRENOM_CKINE, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);
	
	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Age", renderer, "text", AGE_CKINE, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);





	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Adresse", renderer, "text", ADRESSE_CKINE, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);




	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Mail", renderer, "text", MAIL_CKINE, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);



	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Numéro de telephone ", renderer, "text", NUM_CKINE, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);

	
	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Login ", renderer, "text", LOGIN_CKINE, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);





	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Mot de passe  ", renderer, "text", MOT_CKINE, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);


	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Spécialité  ", renderer, "text", SP_CKINE, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);
	
}
		store=gtk_list_store_new (COLUMNS_CKINE, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING);

	fkc = fopen("kinee.txt","r");


	if(fkc ==NULL)
	{
		printf("erreur d'ouverture ");
		return;
	}		
	else
	{
		while(fscanf(fkc,"%s %s %s %s %s %s %s %s  %s %s \n",kinecin,kinenom,kineprenom,kineage,kineadresse,kinemail,kinenum,kinelogin,kinemot,kinesp) !=EOF)
		{
			gtk_list_store_append (store, &iter);
			gtk_list_store_set (store, &iter, CIN_CKINE, kinecin, NOM_CKINE, kinenom, PRENOM_CKINE,kineprenom, AGE_CKINE, kineage, ADRESSE_CKINE, kineadresse, MAIL_CKINE, kinemail, NUM_CKINE, kinenum, LOGIN_CKINE, kinelogin, MOT_CKINE, kinemot ,SP_CKINE,kinesp, -1);
					
		}
		
		fclose(fkc);
		
	}
		
	gtk_tree_view_set_model (GTK_TREE_VIEW (treeview), GTK_TREE_MODEL (store));
	
	g_object_unref (store);
}





/**************************************************************/





enum   
{       
        CIN_CDIET,
        NOM_CDIET,
	PRENOM_CDIET,
	AGE_CDIET,
	ADRESSE_CDIET,
	MAIL_CDIET,
	NUM_CDIET,
       	LOGIN_CDIET,
	MOT_CDIET,
	SP_CDIET,
        COLUMNS_DIET
};

void afficherlistecomptediet(GtkWidget *treeview)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;

	char Dcin[50];
	char Dnom[50];
	char Dprenom[50];
	char Dage[50];
	char Dadresse[50];
	char Dmail[50];
	char Dnum[50];
	char Dlogin[50];
	char Dmot[50];
	char Dsp[50];
	
FILE *fd;

	store=NULL;
	
		
	if (store==NULL)
	{

	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Cin", renderer, "text", CIN_CDIET, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);


	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Nom", renderer, "text", NOM_CDIET, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);


	 
	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Prénom", renderer, "text", PRENOM_CDIET, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);
	
	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Age", renderer, "text", AGE_CDIET, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);





	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Adresse", renderer, "text", ADRESSE_CDIET, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);




	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Mail", renderer, "text", MAIL_CDIET, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);



	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Numéro de telephone ", renderer, "text", NUM_CDIET, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);

	
	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Login ", renderer, "text", LOGIN_CDIET, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);





	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Mot de passe  ", renderer, "text", MOT_CDIET, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);


	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Spécialité  ", renderer, "text", SP_CDIET, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);
	
}
		store=gtk_list_store_new (COLUMNS_CKINE, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING);

	fd = fopen("dietee.txt","r");


	if(fd ==NULL)
	{
		printf("erreur d'ouverture ");
		return;
	}		
	else
	{
		while(fscanf(fd,"%s %s %s %s %s %s %s %s  %s %s \n",Dcin,Dnom,Dprenom,Dage,Dadresse,Dmail,Dnum,Dlogin,Dmot,Dsp) !=EOF)
		{
			gtk_list_store_append (store, &iter);
			gtk_list_store_set (store, &iter, CIN_CDIET, Dcin, NOM_CDIET, Dnom, PRENOM_CDIET,Dprenom, AGE_CDIET, Dage, ADRESSE_CDIET, Dadresse, MAIL_CDIET, Dmail, NUM_CDIET, Dnum, LOGIN_CDIET, Dlogin, MOT_CDIET, Dmot ,SP_CDIET,Dsp, -1);
					
		}
		
		fclose(fd);
		
	}
		
	gtk_tree_view_set_model (GTK_TREE_VIEW (treeview), GTK_TREE_MODEL (store));
	
	g_object_unref (store);
}

/**************************************************************/





enum   
{       
        CIN_NUT,
        NOM_NUT,
	PRENOM_NUT,
	AGE_NUT,
	ADRESSE_NUT,
	MAIL_NUT,
	NUM_NUT,
       	LOGIN_NUT,
	MOT_NUT,
	SP_NUT,
        COLUMNS_NUT
};

void afficherlistecomptenut(GtkWidget *treeview)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;

	char NUTcin[50];
	char NUTnom[50];
	char NUTprenom[50];
	char NUTage[50];
	char NUTadresse[50];
	char NUTmail[50];
	char NUTnum[50];
	char NUTlogin[50];
	char NUTmot[50];
	char NUTsp[50];
	
FILE *fn;

	store=NULL;
	
		
	if (store==NULL)
	{

	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Cin", renderer, "text", CIN_NUT, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);


	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Nom", renderer, "text", NOM_NUT, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);


	 
	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Prénom", renderer, "text", PRENOM_NUT, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);
	
	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Age", renderer, "text", AGE_NUT, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);





	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Adresse", renderer, "text", ADRESSE_NUT, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);




	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Mail", renderer, "text", MAIL_NUT, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);



	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Numéro de telephone ", renderer, "text", NUM_NUT, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);

	
	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Login ", renderer, "text", LOGIN_NUT, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);





	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Mot de passe  ", renderer, "text", MOT_NUT, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);


	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Spécialité  ", renderer, "text", SP_NUT, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);
	
}
		store=gtk_list_store_new (COLUMNS_CKINE, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING);

	fn = fopen("nutrii.txt","r");


	if(fn ==NULL)
	{
		printf("erreur d'ouverture ");
		return;
	}		
	else
	{
		while(fscanf(fn,"%s %s %s %s %s %s %s %s  %s %s \n",NUTcin,NUTnom,NUTprenom,NUTage,NUTadresse,NUTmail,NUTnum,NUTlogin,NUTmot,NUTsp) !=EOF)
		{
			gtk_list_store_append (store, &iter);
			gtk_list_store_set (store, &iter, CIN_NUT, NUTcin, NOM_CDIET, NUTnom, PRENOM_NUT,NUTprenom, AGE_NUT, NUTage, ADRESSE_NUT, NUTadresse, MAIL_NUT, NUTmail, NUM_NUT, NUTnum, LOGIN_NUT, NUTlogin, MOT_NUT, NUTmot ,SP_NUT,NUTsp, -1);
					
		}
		
		fclose(fn);
		
	}
		
	gtk_tree_view_set_model (GTK_TREE_VIEW (treeview), GTK_TREE_MODEL (store));
	
	g_object_unref (store);
}











