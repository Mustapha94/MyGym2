#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif




#include <stdio.h>
#include <string.h>
#include "nut.h"
#include <gtk/gtk.h>

void ajouternut(nut u)
{

FILE *fn; 
fn=fopen("nutrii.txt","a+");
fprintf(fn,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",u.cin,u.nom,u.prenom,u.jour,u.mois,u.annee,u.adresse,u.mail,u.num,u.login,u.mot,u.sp);
fclose(fn);
}
/***************************/

int verif_nut(char x[])
{
nut y;

FILE *fn ;

fn=fopen("nutrii.txt","r");
if (fn!=NULL)
  {
	while (fscanf(fn,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",y.cin,y.nom,y.prenom,&y.jour,&y.mois,&y.annee,y.adresse,y.mail,y.num,y.login,y.mot,y.sp) !=EOF)
 {       if (strcmp(y.cin,x)==0)
	{ 	
		return 1;
	}

  }
return 0 ;
fclose(fn);
 }

}



/***********************/


nut chercher_nut(char x[])
{
nut y;
FILE *fn ;

fn=fopen("nutrii.txt","r");
if (fn!=NULL)
  {
	while (fscanf(fn,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",y.cin,y.nom,y.prenom,&y.jour,&y.mois,&y.annee,y.adresse,y.mail,y.num,y.login,y.mot,y.sp) !=EOF)
 {       if (strcmp(y.cin,x)==0)
	{ 
	 return y;
	}

  }
fclose(fn);
   
  }

}


/**********************************/
void supprimer_nut(char id[])
{
nut y;
FILE *fn; 
FILE *fsupn; 


fn=fopen("nutrii.txt","r");
fsupn=fopen("nutriisup.txt","a+");
if (fn!=NULL)
{
while (fscanf(fn,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",y.cin,y.nom,y.prenom,&y.jour,&y.mois,&y.annee,y.adresse,y.mail,y.num,y.login,y.mot,y.sp) !=EOF)
{
	if (strcmp(id,y.cin) !=0)
     { fprintf(fsupn,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",y.cin,y.nom,y.prenom,y.jour,y.mois,y.annee,y.adresse,y.mail,y.num,y.login,y.mot,y.sp);
     }
}

fclose(fn);
fclose(fsupn);
}
remove("nutrii.txt");
rename("nutriisup.txt","nutrii.txt");
}
/******************************************/




