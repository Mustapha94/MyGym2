#include <gtk/gtk.h>


void
on_button_info_coord_admin_clicked     (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button_event_admin_clicked          (GtkWidget       *button,
                                        gpointer         user_data);
void
on_button_afficher_deal_choisi_admin_clicked                    (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button_gestion_cp_utilisateur_clicked
                                        (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button_page_accueil_clicked         (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_statistiques_admin_clicked   (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button_planning_h_travail_clicked   (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button_gestion_abonnements_factures_clicked
                                        (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button_reclamation_admin_clicked    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_deco_admin_clicked           (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button_planning_semaine_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);


void
on_button_deals_admin_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_retour_menu_admin_accueil_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_ajouter_nv_deal_clicked      (GtkWidget      *button,
                                        gpointer         user_data);


void
on_button_retour_page_accueil_liste_deals_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_retour_affichage_liste_deals_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_modifier_deal_admin_clicked  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_supprimer_deal_admin_clicked (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_valider_nv_deal_clicked      (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button_retour_ajouter_deal_liste_deals_clicked
                                        (GtkWidget      *button,
                                        gpointer         user_data);
void
on_button_info_coord_admin_clicked                    (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button_event_admin_clicked                    (GtkWidget      *button,
                                        gpointer         user_data);






void
on_button_supprimer_event_admin_clicked
                                        (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button_modifier_event_admin_clicked (GtkWidget     *button,
                                        gpointer         user_data);



void
on_button_retour_page_accueil_liste_event_clicked
                                        (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button_ajouter_nv_event_clicked     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_valider_nv_event_clicked     (GtkWidget       *button,
                                        gpointer         user_data);



void
on_button_retour_affichage_liste_event_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);


 

void
on_button_retour_page_d_accueil_info_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_modifier_info_coord_admin_clicked
                                        (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button_valider_modification_info_acoord_dmin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_retour_info_coord_modifier_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_afficher_event_choisi_admin_clicked
                                        (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button_retour_ajouter_event_liste_event_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_retour_abonnement_facture_menu_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_modifier_abonnement_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);


void
on_button_retour_verification_gestion_abonnement_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);


void
on_button_retour_facture_coach_menu_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_retour_facture_medecin_menu_admin_clicked
                                        (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button_modifier_facture_kine_admin_clicked
                                        (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button_retour_facture_kine_menu_admin_clicked
                                        (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button_modifier_facture_agent_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_retour_facture_agent_menu_admin_clicked
                                        (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button_retour_verification_coach_gestion_facture_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);


void
on_button_retour_verification_medecin_gestion_facture_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);



void
on_button_retour_verification_kine_gestion_facture_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);



void
on_button_retour_verification_agent_gestion_facture_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);


void
on_button_modifier_facture_coach_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);


void
on_button_verification_payement_agent_admin1_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_verification_payement_coach_admin1_clicked
                                        (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button_verification_payement_medecin_admin1_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_verification_payement_admin1_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_modifier_facture_coach_admin1_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_valider_choix_cin_coach_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_valider_choix_cin_kine_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_valider_choix_cin_agent_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_valider_modification_abonnement_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_valider_modification_facture_medecin_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_valider_modification_facture_kine_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_valider_modification_facture_agent_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_valider_choix_cin_adh_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_valider_choix_cin_medecin_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_verification_payement_kine_admin1_clicked
                                        (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button_valider_modification_facture_coach_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_afficher_taux_presence_adh_seance_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_retour_taux_presence_menu_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour_avis_salle_menu_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour_avis_coach_menu_admin1_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour_avis_kine_menu_admin_clicked (GtkWidget      *button,
                                        gpointer         user_data);

void
on_retour_avis_medecin_menu_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_valider_taux_admin_clicked   (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button_retour_choix_taux_stats_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);


void
on_button_se_connecter_page_accueil1_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_home_menu_admin_clicked      (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_quitter_app_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_retour_page_accueil_menu_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_se_deco_accueil_admin_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Cdiet_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Cadherent_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Ccoch_clicked                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Cnuti_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Ckine_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_reretourmenu_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Retourcompte_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_cherchercoach_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Ajadh_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourlista_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_plandiete_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_plancoche_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_planenutr_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_plankine_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_planeage_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retouraumenuaparirdesreclamcoach_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_supprimyinfo_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_modifylesinfo_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourGestioncompteaparirdelalistedescoach_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_ajoutcoach_clicked                  (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_affichecoachchercher_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_affichelalistedescoach_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_ajoutercoach_clicked                (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_retourlistedescoach_clicked         (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourlisteGestion_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Supprimerlecoachexistant__clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Modifierlecoachexistant_clicked     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourduplaningauplane_clicked      (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourdeplaningkineauplane_clicked  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourduplaningkineauplane_clicked  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourplaningagentauplane_clicked   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourplaningdietauplane_clicked    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajouterunnvkine_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourdelalistekineaucompte__clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Affichekinechercher_clicked         (GtkWidget       *button,
                                        gpointer         user_data);

void
on_afficherinfotreeview_clicked        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajouterkine_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_supprimerlesinfocomptekine_clicked  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_modifiercomptekineaman_clicked      (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajouterunnvdiet_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourdudietauplan_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_afficherdiet_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_afficherlediet_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajouterlediet_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_supprimerdiet_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_modifierdiet_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourdietliste_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajouterunnvnut_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_cherchernutee_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_afficher_nut__clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajouternut_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retournut_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_supprimernut_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_modifiernut_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Retourplans_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_login_admin1_clicked         (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_retour_auth_page_accueil_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour_nut__clicked                 (GtkWidget         *button,
                                        gpointer         user_data);
