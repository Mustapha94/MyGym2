#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif




#include <stdio.h>
#include <string.h>
#include "kine.h"
#include <gtk/gtk.h>

void ajouterkine(kine k)
{

FILE *fkc; 
fkc=fopen("kinee.txt","a+");
fprintf(fkc,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",k.cin,k.nom,k.prenom,k.jour,k.mois,k.annee,k.adresse,k.mail,k.num,k.login,k.mot,k.sp);
fclose(fkc);
}

/**********************************/
void supprimer_kine(char id[])
{
kine t;
FILE *fkc; 
FILE *fsupkc; 


fkc=fopen("kinee.txt","r");
fsupkc=fopen("kinesup.txt","a+");
if (fkc!=NULL)
{
while (fscanf(fkc,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",t.cin,t.nom,t.prenom,&t.jour,&t.mois,&t.annee,t.adresse,t.mail,t.num,t.login,t.mot,t.sp) !=EOF)
{
	if (strcmp(id,t.cin) !=0)
     { fprintf(fsupkc,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",t.cin,t.nom,t.prenom,t.jour,t.mois,t.annee,t.adresse,t.mail,t.num,t.login,t.mot,t.sp);
     }
}

fclose(fkc);
fclose(fsupkc);
}
remove("kinee.txt");
rename("kinesup.txt","kinee.txt");
}



/**************************/

int verif_kine(char x[])
{
kine t;

FILE *fkc ;

fkc=fopen("kinee.txt","r");
if (fkc!=NULL)
  {
	while (fscanf(fkc,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",t.cin,t.nom,t.prenom,&t.jour,&t.mois,&t.annee,t.adresse,t.mail,t.num,t.login,t.mot,t.sp) !=EOF)
 {       if (strcmp(t.cin,x)==0)
	{ 	
		return 1;
	}

  }
return 0 ;
fclose(fkc);
 }

}
 
/**********************/



kine chercher_kine(char x[])
{
kine t;
FILE *fkc ;

fkc=fopen("kinee.txt","r");
if (fkc!=NULL)
  {
	while (fscanf(fkc,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",t.cin,t.nom,t.prenom,&t.jour,&t.mois,&t.annee,t.adresse,t.mail,t.num,t.login,t.mot,t.sp) !=EOF)
 {       if (strcmp(t.cin,x)==0)
	{ 
	 return t;
	}

  }
fclose(fkc);
   
  }

}












