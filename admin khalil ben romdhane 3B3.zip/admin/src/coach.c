#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif




#include <stdio.h>
#include <string.h>
#include "coach.h"
#include <gtk/gtk.h>

void ajoutercoach(coach c)
{

FILE *f; 
f=fopen("coachee.txt","a+");
fprintf(f,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",c.cin,c.nom,c.prenom,c.jour,c.mois,c.annee,c.adresse,c.mail,c.num,c.login,c.mot,c.sp);
fclose(f);
}

	 

/***************************/

int verif_coach(char x[])
{
coach e ;

FILE *f ;

f=fopen("coachee.txt","r");
if (f!=NULL)
  {
	while (fscanf(f,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",e.cin,e.nom,e.prenom,&e.jour,&e.mois,&e.annee,e.adresse,e.mail,e.num,e.login,e.mot,e.sp) !=EOF)
 {       if (strcmp(e.cin,x)==0)
	{ 	
		return 1;
	}

  }
return 0 ;
fclose(f);
 }

}




/***********************/


coach chercher_coach(char x[])
{
coach e;
FILE *f ;

f=fopen("coachee.txt","r");
if (f!=NULL)
  {
	while (fscanf(f,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",e.cin,e.nom,e.prenom,&e.jour,&e.mois,&e.annee,e.adresse,e.mail,e.num,e.login,e.mot,e.sp) !=EOF)
 {       if (strcmp(e.cin,x)==0)
	{ 
	 return e;
	}

  }
fclose(f);
   
  }

}

/**********************************/
void supprimer_coach(char id[])
{
coach e;
FILE *f; 
FILE *fsup; 


f=fopen("coachee.txt","r");
fsup=fopen("coachesup.txt","a+");
if (f!=NULL)
{
while (fscanf(f,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",e.cin,e.nom,e.prenom,&e.jour,&e.mois,&e.annee,e.adresse,e.mail,e.num,e.login,e.mot,e.sp) !=EOF)
{
	if (strcmp(id,e.cin) !=0)
     { fprintf(fsup,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",e.cin,e.nom,e.prenom,e.jour,e.mois,e.annee,e.adresse,e.mail,e.num,e.login,e.mot,e.sp);
     }
}

fclose(f);
fclose(fsup);
}
remove("coachee.txt");
rename("coachesup.txt","coachee.txt");
}
/******************************************/


void modifier_coach(coach n)
{

coach e;
FILE *f; 
FILE *fsup; 


f=fopen("coachee.txt","r");
fsup=fopen("coachesup.txt","w");
if(f!=NULL)
{

while (fscanf(f,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",e.cin,e.nom,e.prenom,&e.jour,&e.mois,&e.annee,e.adresse,e.mail,e.num,e.login,e.mot,e.sp) !=EOF)
{
	if (strcmp(n.cin,e.cin) !=0)
     { fprintf(fsup,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",e.cin,e.nom,e.prenom,e.jour,e.mois,e.annee,e.adresse,e.mail,e.num,e.login,e.mot,e.sp);
     }
	else {
 fprintf(fsup,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",e.cin,n.nom,n.prenom,e.jour,e.mois,e.annee,n.adresse,n.mail,n.num,e.login,e.mot,n.sp);
}
}
fclose(f);
fclose(fsup);

remove("coachee.txt");
rename("coachesup.txt","coachee.txt");
}
}














