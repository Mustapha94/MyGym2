#include <gtk/gtk.h>

struct Nut
{
char cin[30];
char nom[30];
char prenom[30];
char login[100];
char mot[30];
char adresse[30];
char mail[30];
char num[30];
char sp[30];
int jour;
int mois;
int annee;
};
typedef struct Nut nut;
void ajouternut(nut u);
int verif_nut(char x[]);
nut chercher_nut(char x[]);
void supprimer_nut(char id[]);
