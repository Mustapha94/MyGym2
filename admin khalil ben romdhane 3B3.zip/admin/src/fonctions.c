#include <stdio.h>
#include <string.h>
#include "fonctions.h"
#include <gtk/gtk.h>
#include<stdlib.h>

int authentif(char login[],char password[])
{ FILE *f;
char login1[20],password1[20] ;
int role ;
f=fopen("personne_auth.txt","r");
while(fscanf(f,"%s %s %d ",login1,password1,&role)!=EOF)
{
if( strcmp(login,login1)==0 && strcmp ( password1, password)==0)
{
fclose(f);
return role ;}
}
fclose(f);
return -1;
}




enum
{
	NOM,
	DATE_DEBUT,
	DATE_FIN,
	PRIX,
	DESCRIPTION,
	COLUMNS
};

void ajouter_deal(Deal d)
{
	FILE *f;
	f=fopen("liste_desdeals.txt","a+");
	if(f!=NULL)
	{
	fprintf(f,"%s %s %s %s %s 	\n",d.nom,d.date_debut,d.date_fin,d.prix,d.description);
	fclose(f);
	}
}


void afficher_deal(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	char nom1[30];
	char date_debut1[11];
	char date_fin1[11];
	char prix1[10];
	char description1[350];
	store=NULL;
	FILE *f;
	
	//store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
	if(store==NULL)
	{
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes(" Nom",renderer,"text",NOM,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes(" Date  Début",renderer,"text",DATE_DEBUT,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes(" Date  Fin",renderer,"text",DATE_FIN,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Prix",renderer,"text",PRIX,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("    Description",renderer,"text",DESCRIPTION,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
}


	store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	f=fopen("liste_desdeals.txt","r");
	if(f==NULL)
	{return;}
	else
	{ f=fopen("liste_desdeals.txt","a+");
		while(fscanf(f,"%s %s %s %s %s \n",nom1,date_debut1,date_fin1,prix1,description1)!=EOF)
	   {
		gtk_list_store_append(store, &iter);
		gtk_list_store_set(store,&iter, NOM, nom1, DATE_DEBUT, date_debut1, DATE_FIN, date_fin1, PRIX, prix1, DESCRIPTION, description1, -1);
	   }
	   fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	}

}

void supprimer_deal(char s[])
{
	FILE *f;
	FILE *f1;
	Deal d;
	f=fopen("liste_desdeals.txt","r");
	f1=fopen("liste_desdeals1.txt","a+");
	if(f!=NULL)
	{
	while (fscanf(f,"%s %s %s %s %s 	\n",d.nom,d.date_debut,d.date_fin,d.prix,d.description)!=EOF)
	{if (strcmp(s,d.nom)!=0)
		{fprintf(f1,"%s %s %s %s %s 	\n",d.nom,d.date_debut,d.date_fin,d.prix,d.description);}
	}
	fclose(f);
	fclose(f1);
	}
remove("liste_desdeals.txt");
rename("liste_desdeals1.txt","liste_desdeals.txt");
}


void modifier_deal(char s[], Deal d)
{
	FILE *f;
	FILE *f1;
	char nom1[20];
	char dated1[11];
	char datef1[11];
	char prix1[10];
	char description1[350];
	f=fopen("liste_desdeals.txt","r");
	f1=fopen("liste_desdeals1.txt","a+");
	if(f!=NULL)
	{
	while (fscanf(f,"%s %s %s %s %s 	\n",nom1,dated1,datef1,prix1,description1)!=EOF)
	{if (strcmp(s,nom1)!=0)
		{fprintf(f1,"%s %s %s %s %s 	\n",nom1,dated1,datef1,prix1,description1);}
	else { fprintf(f1,"%s %s %s %s %s 	\n",d.nom,d.date_debut,d.date_fin,d.prix,d.description);}}
	fclose(f);
	fclose(f1);
	}
remove("liste_desdeals.txt");
rename("liste_desdeals1.txt","liste_desdeals.txt");
}



//EVENT

enum
{
	NOM_E,
	DATE_E,
	DESCRIPTION_E,
	COLUMNS_E
};



void ajouter_event(Evenement e)
{
	FILE *f1;
	f1=fopen("liste_desevenements.txt","a+");
	if(f1!=NULL)
	{
	fprintf(f1,"%s %s %s \n",e.nom,e.date,e.description);
	fclose(f1);
	}
}


void afficher_event(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	char nom1[30];
	char date1[11];
	char description1[350];
	store=NULL;
	FILE *f1;
	
	//store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
	if(store==NULL)
	{
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Nom de l'événement  ",renderer,"text",NOM_E,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Date  ",renderer,"text",DATE_E,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Description  ",renderer,"text",DESCRIPTION_E,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
}


	store=gtk_list_store_new(COLUMNS_E, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	f1=fopen("liste_desevenements.txt","r");
	if(f1==NULL)
	{return;}
	else
	{ f1=fopen("liste_desevenements.txt","a+");
		while(fscanf(f1,"%s %s %s \n",nom1,date1,description1)!=EOF)
	   {
		gtk_list_store_append(store, &iter);
		gtk_list_store_set(store,&iter, NOM_E, nom1, DATE_E, date1, DESCRIPTION_E, description1, -1);
	   }
	   fclose(f1);
	gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	}

}


void supprimer_event(char s[])
{
	FILE *f;
	FILE *f1;
	Evenement e;
	f=fopen("liste_desevenements.txt","r");
	f1=fopen("liste_desevenements1.txt","a+");
	if(f!=NULL)
	{
	while (fscanf(f,"%s %s %s \n",e.nom,e.date,e.description)!=EOF)
	{if (strcmp(s,e.nom)!=0)
		{fprintf(f1,"%s %s %s \n",e.nom,e.date,e.description);}
	}
	fclose(f);
	fclose(f1);
	}
remove("liste_desevenements.txt");
rename("liste_desevenements1.txt","liste_desevenements.txt");
}


void modifier_event(char s[], Evenement e)
{
	FILE *f;
	FILE *f1;
	char nom1[20];
	char date1[11];
	char description1[350];
	f=fopen("liste_desevenements.txt","r");
	f1=fopen("liste_desevenements1.txt","a+");
	if(f!=NULL)
	{
	while (fscanf(f,"%s %s %s \n",nom1,date1,description1)!=EOF)
	{if (strcmp(s,nom1)!=0)
		{fprintf(f1,"%s %s %s \n",nom1,date1,description1);}
	else { fprintf(f1,"%s %s %s	\n",e.nom,e.date,e.description);}}
	fclose(f);
	fclose(f1);
	}
remove("liste_desevenements.txt");
rename("liste_desevenements1.txt","liste_desevenements.txt");
}


//ADHERENT

enum
{
	NOM_A,
	PRENOM_A,
	CIN_A,
	JANVIER_A,
	FEVRIER_A,
	MARS_A,
	AVRIL_A,
	MAI_A,
	JUIN_A,
	JUILLET_A,
	AOUT_A,
	SEPTEMBRE_A,
	OCTOBRE_A,
	NOVEMBRE_A,
	DECEMBRE_A,
	COLUMNS_A
};

void afficher_abonnement_adherent(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	char nom1[20], prenom1[20], cin1[8], janvier1[5], fevrier1[5], mars1[5], avril3[5], mai1[5], juin1[5], juillet1[5], aout1[5], septembre1[5], octobre1[5], novembre1[5], decembre1[5];
	
	store=NULL;
	FILE *f1;
	
	
	if(store==NULL)
	{


		column=gtk_tree_view_column_new_with_attributes("  Nom de l'adhérent  ",renderer,"text",NOM_A,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Prénom de l'adhérent  ",renderer,"text",PRENOM_A,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Cin de l'adhérent   ",renderer,"text",CIN_A,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Janvier   ",renderer,"text",JANVIER_A,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Février   ",renderer,"text",FEVRIER_A,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Mars   ",renderer,"text",MARS_A,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Avril   ",renderer,"text",AVRIL_A,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Mai   ",renderer,"text",MAI_A,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Juin   ",renderer,"text",JUIN_A,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Juillet   ",renderer,"text",JUILLET_A,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Aout   ",renderer,"text",AOUT_A,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Septembre   ",renderer,"text",SEPTEMBRE_A,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Octobre   ",renderer,"text",OCTOBRE_A,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Novembre   ",renderer,"text",NOVEMBRE_A,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Décembre   ",renderer,"text",DECEMBRE_A,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
}


	store=gtk_list_store_new(COLUMNS_A, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	f1=fopen("liste_desadherents_abonnement.txt","r");
	if(f1==NULL)
	{return;}
	else
	{ f1=fopen("liste_desadherents_abonnement.txt","r+");
		while(fscanf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",nom1,prenom1,cin1,janvier1,fevrier1,mars1,avril3,mai1,juin1,juillet1,aout1,septembre1,octobre1,novembre1,decembre1)!=EOF)
	   {
		gtk_list_store_append(store, &iter);
		gtk_list_store_set(store,&iter, NOM_A, nom1, PRENOM_A, prenom1, CIN_A, cin1, JANVIER_A, janvier1, FEVRIER_A, fevrier1, MARS_A, mars1, AVRIL_A, avril3, MAI_A, mai1, JUIN_A, juin1, JUILLET_A, juillet1, AOUT_A, aout1, SEPTEMBRE_A, septembre1, OCTOBRE_A, octobre1, NOVEMBRE_A, novembre1, DECEMBRE_A, decembre1, -1);
	   }
	   fclose(f1);
	gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	}

}

//COACH

enum
{
	NOM_C,
	PRENOM_C,
	CIN_C,
	JANVIER_C,
	FEVRIER_C,
	MARS_C,
	AVRIL_C,
	MAI_C,
	JUIN_C,
	JUILLET_C,
	AOUT_C,
	SEPTEMBRE_C,
	OCTOBRE_C,
	NOVEMBRE_C,
	DECEMBRE_C,
	COLUMNS_C
};

void afficher_facture_coach(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	char nom1[20], prenom1[20], cin1[8], janvier1[5], fevrier1[5], mars1[5], avril3[5], mai1[5], juin1[5], juillet1[5], aout1[5], septembre1[5], octobre1[5], novembre1[5], decembre1[5];
	
	store=NULL;
	FILE *f1;
	
	//store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
	if(store==NULL)
	{

		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Nom du coach  ",renderer,"text",NOM_C,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Prénom du coach  ",renderer,"text",PRENOM_C,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Cin du coach   ",renderer,"text",CIN_C,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Janvier   ",renderer,"text",JANVIER_C,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Février   ",renderer,"text",FEVRIER_C,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Mars   ",renderer,"text",MARS_C,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Avril   ",renderer,"text",AVRIL_C,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Mai   ",renderer,"text",MAI_C,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Juin   ",renderer,"text",JUIN_C,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Juillet   ",renderer,"text",JUILLET_C,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Aout   ",renderer,"text",AOUT_C,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Septembre   ",renderer,"text",SEPTEMBRE_C,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Octobre   ",renderer,"text",OCTOBRE_C,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Novembre   ",renderer,"text",NOVEMBRE_C,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Décembre   ",renderer,"text",DECEMBRE_C,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
}


	store=gtk_list_store_new(COLUMNS_A, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	f1=fopen("liste_descoachsfacture.txt","r");
	if(f1==NULL)
	{return;}
	else
	{ f1=fopen("liste_descoachsfacture.txt","r+");
		while(fscanf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",nom1,prenom1,cin1,janvier1,fevrier1,mars1,avril3,mai1,juin1,juillet1,aout1,septembre1,octobre1,novembre1,decembre1)!=EOF)
	   {
		gtk_list_store_append(store, &iter);
		gtk_list_store_set(store,&iter, NOM_C, nom1, PRENOM_C, prenom1, CIN_C, cin1, JANVIER_C, janvier1, FEVRIER_C, fevrier1, MARS_C, mars1, AVRIL_C, avril3, MAI_C, mai1, JUIN_C, juin1, JUILLET_C, juillet1, AOUT_C, aout1, SEPTEMBRE_C, septembre1, OCTOBRE_C, octobre1, NOVEMBRE_C, novembre1, DECEMBRE_C, decembre1, -1);
	   }
	   fclose(f1);
	gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	}

}


//MEDECIN

enum
{
	NOM_M,
	PRENOM_M,
	CIN_M,
	JANVIER_M,
	FEVRIER_M,
	MARS_M,
	AVRIL_M,
	MAI_M,
	JUIN_M,
	JUILLET_M,
	AOUT_M,
	SEPTEMBRE_M,
	OCTOBRE_M,
	NOVEMBRE_M,
	DECEMBRE_M,
	COLUMNS_M
};

void afficher_facture_medecin(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	char nom1[20], prenom1[20], cin1[8], janvier1[5], fevrier1[5], mars1[5], avril3[5], mai1[5], juin1[5], juillet1[5], aout1[5], septembre1[5], octobre1[5], novembre1[5], decembre1[5];
	
	store=NULL;
	FILE *f1;
	
	//store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
	if(store==NULL)
	{

		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Nom du médecin nutritionniste  ",renderer,"text",NOM_M,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Prénom   ",renderer,"text",PRENOM_M,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Cin    ",renderer,"text",CIN_M,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Janvier   ",renderer,"text",JANVIER_M,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Février   ",renderer,"text",FEVRIER_M,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Mars   ",renderer,"text",MARS_M,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Avril   ",renderer,"text",AVRIL_M,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Mai   ",renderer,"text",MAI_M,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Juin   ",renderer,"text",JUIN_M,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Juillet   ",renderer,"text",JUILLET_M,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Aout   ",renderer,"text",AOUT_M,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Septembre   ",renderer,"text",SEPTEMBRE_M,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Octobre   ",renderer,"text",OCTOBRE_M,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Novembre   ",renderer,"text",NOVEMBRE_M,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Décembre   ",renderer,"text",DECEMBRE_M,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
}


	store=gtk_list_store_new(COLUMNS_A, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	f1=fopen("liste_desmedecinsfacture.txt","r");
	if(f1==NULL)
	{return;}
	else
	{ f1=fopen("liste_desmedecinsfacture.txt","r+");
		while(fscanf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",nom1,prenom1,cin1,janvier1,fevrier1,mars1,avril3,mai1,juin1,juillet1,aout1,septembre1,octobre1,novembre1,decembre1)!=EOF)
	   {
		gtk_list_store_append(store, &iter);
		gtk_list_store_set(store,&iter, NOM_M, nom1, PRENOM_M, prenom1, CIN_M, cin1, JANVIER_M, janvier1, FEVRIER_M, fevrier1, MARS_M, mars1, AVRIL_M, avril3, MAI_M, mai1, JUIN_M, juin1, JUILLET_M, juillet1, AOUT_M, aout1, SEPTEMBRE_M, septembre1, OCTOBRE_M, octobre1, NOVEMBRE_M, novembre1, DECEMBRE_M, decembre1, -1);
	   }
	   fclose(f1);
	gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	}

}




//KINE

enum
{
	NOM_K,
	PRENOM_K,
	CIN_K,
	JANVIER_K,
	FEVRIER_K,
	MARS_K,
	AVRIL_K,
	MAI_K,
	JUIN_K,
	JUILLET_K,
	AOUT_K,
	SEPTEMBRE_K,
	OCTOBRE_K,
	NOVEMBRE_K,
	DECEMBRE_K,
	COLUMNS_K
};

void afficher_facture_kine(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	char nom1[20], prenom1[20], cin1[8], janvier1[5], fevrier1[5], mars1[5], avril3[5], mai1[5], juin1[5], juillet1[5], aout1[5], septembre1[5], octobre1[5], novembre1[5], decembre1[5];
	
	store=NULL;
	FILE *f1;
	
	//store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
	if(store==NULL)
	{

		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Nom du kinéthérapeute ",renderer,"text",NOM_K,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Prénom   ",renderer,"text",PRENOM_K,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Cin    ",renderer,"text",CIN_K,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Janvier   ",renderer,"text",JANVIER_K,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Février   ",renderer,"text",FEVRIER_K,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Mars   ",renderer,"text",MARS_K,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Avril   ",renderer,"text",AVRIL_K,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Mai   ",renderer,"text",MAI_K,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Juin   ",renderer,"text",JUIN_K,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Juillet   ",renderer,"text",JUILLET_K,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Aout   ",renderer,"text",AOUT_K,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Septembre   ",renderer,"text",SEPTEMBRE_K,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Octobre   ",renderer,"text",OCTOBRE_K,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Novembre   ",renderer,"text",NOVEMBRE_K,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Décembre   ",renderer,"text",DECEMBRE_K,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
}


	store=gtk_list_store_new(COLUMNS_A, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	f1=fopen("liste_deskinesfacture.txt","r");
	if(f1==NULL)
	{return;}
	else
	{ f1=fopen("liste_deskinesfacture.txt","r+");
		while(fscanf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",nom1,prenom1,cin1,janvier1,fevrier1,mars1,avril3,mai1,juin1,juillet1,aout1,septembre1,octobre1,novembre1,decembre1)!=EOF)
	   {
		gtk_list_store_append(store, &iter);
		gtk_list_store_set(store,&iter, NOM_K, nom1, PRENOM_K, prenom1, CIN_K, cin1, JANVIER_K, janvier1, FEVRIER_K, fevrier1, MARS_K, mars1, AVRIL_K, avril3, MAI_K, mai1, JUIN_K, juin1, JUILLET_K, juillet1, AOUT_K, aout1, SEPTEMBRE_K, septembre1, OCTOBRE_K, octobre1, NOVEMBRE_K, novembre1, DECEMBRE_K, decembre1, -1);
	   }
	   fclose(f1);
	gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	}

}


//AGENT

enum
{
	NOM_AG,
	PRENOM_AG,
	CIN_AG,
	JANVIER_AG,
	FEVRIER_AG,
	MARS_AG,
	AVRIL_AG,
	MAI_AG,
	JUIN_AG,
	JUILLET_AG,
	AOUT_AG,
	SEPTEMBRE_AG,
	OCTOBRE_AG,
	NOVEMBRE_AG,
	DECEMBRE_AG,
	COLUMNS_AG
};

void afficher_facture_agent(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	char nom1[20], prenom1[20], cin1[8], janvier1[5], fevrier1[5], mars1[5], avril3[5], mai1[5], juin1[5], juillet1[5], aout1[5], septembre1[5], octobre1[5], novembre1[5], decembre1[5];
	
	store=NULL;
	FILE *f1;
	
	//store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
	if(store==NULL)
	{

		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Nom de l'agent de nettoyage  ",renderer,"text",NOM_AG,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Prénom   ",renderer,"text",PRENOM_AG,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Cin    ",renderer,"text",CIN_AG,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Janvier   ",renderer,"text",JANVIER_AG,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Février   ",renderer,"text",FEVRIER_AG,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Mars   ",renderer,"text",MARS_AG,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Avril   ",renderer,"text",AVRIL_AG,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Mai   ",renderer,"text",MAI_AG,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Juin   ",renderer,"text",JUIN_AG,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Juillet   ",renderer,"text",JUILLET_AG,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Aout   ",renderer,"text",AOUT_AG,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Septembre   ",renderer,"text",SEPTEMBRE_AG,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Octobre   ",renderer,"text",OCTOBRE_AG,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Novembre   ",renderer,"text",NOVEMBRE_AG,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Décembre   ",renderer,"text",DECEMBRE_AG,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
}


	store=gtk_list_store_new(COLUMNS_A, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	f1=fopen("liste_desagentsfacture.txt","r");
	if(f1==NULL)
	{return;}
	else
	{ f1=fopen("liste_desagentsfacture.txt","r+");
		while(fscanf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",nom1,prenom1,cin1,janvier1,fevrier1,mars1,avril3,mai1,juin1,juillet1,aout1,septembre1,octobre1,novembre1,decembre1)!=EOF)
	   {
		gtk_list_store_append(store, &iter);
		gtk_list_store_set(store,&iter, NOM_AG, nom1, PRENOM_AG, prenom1, CIN_AG, cin1, JANVIER_AG, janvier1, FEVRIER_AG, fevrier1, MARS_AG, mars1, AVRIL_AG, avril3, MAI_AG, mai1, JUIN_AG, juin1, JUILLET_AG, juillet1, AOUT_AG, aout1, SEPTEMBRE_AG, septembre1, OCTOBRE_AG, octobre1, NOVEMBRE_AG, novembre1, DECEMBRE_AG, decembre1, -1);
	   }
	   fclose(f1);
	gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	}

}
	
//code a ajouter dans ajouter adherent
/*char nom1[10];
	char prenom1[11];
	char cin1[8];
	char date_naissance1[11];
	char tel1[8];
	char email1[20];
	char adresse1[30];
	char role1[3];
	store=NULL;
	FILE *f;
	FILE *f1;
	f=fopen("liste_desadherents.txt","r");
	f1=fopen("liste_desadherents_abonnement.txt","a+");
	if(f==NULL)
	{return;}
	else
	{ f=fopen("liste_desadherents.txt","r+");
		while(fscanf(f,"%s %s %s %s %s %s %s %s \n",nom1,prenom1,cin1,date_naissance1,tel1,email1,adresse1,role1)!=EOF)
	   	{fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s \n",nom1,cin1,"non","non","non","non","non","non","non","non","non","non","non","non");}
*/




//statistiques et avis:


// AVIS SALLE

enum
{
	NUM_AVS,
	COLUMNS_AVS
};




void afficher_avissalle(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	

	char num[5];
	store=NULL;
	FILE *f1;
	
	//store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
	if(store==NULL)
	{
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Avis sur la salle   ",renderer,"text",NUM_AVS,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

}


	store=gtk_list_store_new(COLUMNS_AVS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	f1=fopen("avis.txt","r");
	if(f1==NULL)
	{return;}
	else
	{ f1=fopen("avis.txt","a+");
		while(fscanf(f1,"%s \n",num)!=EOF)
	   {
		gtk_list_store_append(store, &iter);
		gtk_list_store_set(store,&iter, NUM_AVS, num, -1);
	   }
	   fclose(f1);
	gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	}

}

//Avis coach

enum
{	
	NOM_AVC,
	NUM_AVC,
	COLUMNS_AVC
};




void afficher_aviscoach(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	

	char num[5];
	char nom[20];
	store=NULL;
	FILE *f1;
	
	//store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
	if(store==NULL)
	{
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Nom Coach   ",renderer,"text",NOM_AVC,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Avis Coach   ",renderer,"text",NUM_AVC,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

}


	store=gtk_list_store_new(COLUMNS_AVC, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	f1=fopen("aviscoach.txt","r");
	if(f1==NULL)
	{return;}
	else
	{ f1=fopen("aviscoach.txt","a+");
		while(fscanf(f1,"%s %s \n",nom,num)!=EOF)
	   {
		gtk_list_store_append(store, &iter);
		gtk_list_store_set(store,&iter, NOM_AVC, nom, NUM_AVC, num, -1);
	   }
	   fclose(f1);
	gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	}

}

//Avis medecin

enum
{	
	NOM_AVM,
	NUM_AVM,
	COLUMNS_AVM
};




void afficher_avismedecin(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	

	char num[5];
	char nom[20];
	store=NULL;
	FILE *f1;
	
	//store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
	if(store==NULL)
	{
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Nom Médecin nutritionniste   ",renderer,"text",NOM_AVM,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Avis Médecin nutritionniste   ",renderer,"text",NUM_AVM,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

}


	store=gtk_list_store_new(COLUMNS_AVM, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	f1=fopen("avismedecin.txt","r");
	if(f1==NULL)
	{return;}
	else
	{ f1=fopen("avismedecin.txt","a+");
		while(fscanf(f1,"%s %s \n",nom,num)!=EOF)
	   {
		gtk_list_store_append(store, &iter);
		gtk_list_store_set(store,&iter, NOM_AVM, nom, NUM_AVM, num, -1);
	   }
	   fclose(f1);
	gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	}

}

//Avis Kine

enum
{	
	NOM_AVK,
	NUM_AVK,
	COLUMNS_AVK
};




void afficher_aviskine(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	

	char num[5];
	char nom[20];
	store=NULL;
	FILE *f1;
	
	//store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
	if(store==NULL)
	{
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Nom Kinésithérapeute   ",renderer,"text",NOM_AVK,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Avis Kinésithérapeute   ",renderer,"text",NUM_AVK,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

}


	store=gtk_list_store_new(COLUMNS_AVK, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	f1=fopen("aviskine.txt","r");
	if(f1==NULL)
	{return;}
	else
	{ f1=fopen("aviskine.txt","a+");
		while(fscanf(f1,"%s %s \n",nom,num)!=EOF)
	   {
		gtk_list_store_append(store, &iter);
		gtk_list_store_set(store,&iter, NOM_AVK, nom, NUM_AVK, num, -1);
	   }
	   fclose(f1);
	gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	}

}
