#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif




#include <stdio.h>
#include <string.h>
#include "personne.h"
#include <gtk/gtk.h>

enum   
{       
        NOMPRENOM,
        DATENAISS,
	CIN,
	POIDS,
        MALADIE,
        FUMEUR,
        ANCIEN,
	TAILLE,
	ALCOOLIC,
	URG,
	GROUP,
	COLUMNS
};



void ajouter_personne(Personne p)
{

 FILE *f;
  f=fopen("utilisateur.txt","a+");
  if(f!=NULL) 
  {
  fprintf(f,"%s %s %s %s %s %s %s %s %s %s %s \n",p.NomPrenom,p.datenaiss,p.cin,p.poids,p.Maladie,p.Fumeur,p.Ancien,p.Taille,p.alcoolic,p.urg,p.group);
  fclose(f);

}
}

void afficher_personne(GtkWidget *liste)
{
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;

	char NomPrenom[30];
	char datenaiss[10];
	char cin[30];
	char poids[10];
	char Maladie[300];
	char Fumeur[10];
	char Ancien[30];
	char Taille[30];
	char alcoolic[30];
	char urg[30];
	char group[30];
        store=NULL;

        FILE *f;
	
	store=gtk_tree_view_get_model(liste);	
	if (store==NULL)
	{

                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  NomPrenom", renderer, "text",NOMPRENOM, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" datenaiss", renderer, "text",DATENAISS, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" cin", renderer, "text",CIN, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);		
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  poids", renderer, "text",POIDS, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  Maladie", renderer, "text",MALADIE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  Fumeur", renderer, "text",FUMEUR, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  Ancien", renderer, "text",ANCIEN, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" Taille", renderer, "text",TAILLE, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);	
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  alcoolic", renderer, "text",ALCOOLIC, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  urg", renderer, "text",URG, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  group", renderer, "text",GROUP, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		

               
	
	}

	
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,  G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	f = fopen("utilisateur.txt", "r");
	
	if(f==NULL)
	{

		return;
	}		
	else 

	{ f = fopen("utilisateur.txt", "a+");
              while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s \n",NomPrenom,datenaiss,cin,poids,Maladie,Fumeur,Ancien,Taille,alcoolic,urg,group)!=EOF)
		{
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter, NOMPRENOM, NomPrenom, DATENAISS, datenaiss, CIN, cin, POIDS, 			poids,MALADIE,Maladie,FUMEUR,Fumeur,ANCIEN,Ancien,TAILLE,Taille,ALCOOLIC,alcoolic,URG,urg,GROUP,group , -1); 
		}
		fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),  GTK_TREE_MODEL (store));
    g_object_unref (store);
	}
}
void sup_speci(char cin[30]) 
{
	char NomPrenom1[30];
	char datenaiss1[10];
	char cin1[30];
	char poids1[10];
	char Maladie1[300];
	char Fumeur1[10];
	char Ancien1[30];
	char Taille1[30];
	char alcoolic1[30];
	char urg1[30];
	char group1[30];

	FILE *l;
	FILE *t;
	l=fopen("utilisateur.txt","r");
	t=fopen("utilisateur.tmp","a+");
	while (fscanf(l,"%s %s %s %s %s %s %s %s %s %s %s \n",NomPrenom1,datenaiss1,cin1,poids1,Maladie1,Fumeur1,Ancien1,Taille1,alcoolic1,urg1,group1)!=EOF)
	{
		if (strcmp(cin,cin1)!=0)
		{
			fprintf(t,"%s %s %s %s %s %s %s %s %s %s %s \n",NomPrenom1,datenaiss1,cin1,poids1,Maladie1,Fumeur1,Ancien1,Taille1,alcoolic1,urg1,group1);
		}
	}
	fclose(l);
	fclose(t);
	remove("utilisateur.txt");
	rename("utilisateur.tmp","utilisateur.txt");
}
void modifier(char NomPrenom[30],char datenaiss[10],char cin[30],char poids[10],char Maladie[300],char Fumeur[10],char Ancien[30],char Taille[30],char alcoolic[30],char urg[30],char group[30])
{
FILE*f;
FILE*f1;
	char NomPrenom1[30];
	char datenaiss1[10];
	char cin1[30];
	char poids1[10];
	char Maladie1[300];
	char Fumeur1[10];
	char Ancien1[30];
	char Taille1[30];
	char alcoolic1[30];
	char urg1[30];
	char group1[30];
f=fopen("utilisateur.txt","r");
f1=fopen("utilisateur.tmp","w");
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s \n",NomPrenom1,datenaiss1,cin1,poids1,Maladie1,Fumeur1,Ancien1,Taille1,alcoolic1,urg1,group1)!=EOF)
{
if(strcmp(cin,cin1)==0)
{
fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s \n",NomPrenom,datenaiss,cin,poids,Maladie,Fumeur,Ancien,Taille,alcoolic,urg,group);
}
else
{
fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s \n",NomPrenom1,datenaiss1,cin1,poids1,Maladie1,Fumeur1,Ancien1,Taille1,alcoolic1,urg1,group1);
}
}
  fclose(f);
  fclose(f1);
  remove("utilisateur.txt");
  rename("utilisateur.tmp","utilisateur.txt");
}

