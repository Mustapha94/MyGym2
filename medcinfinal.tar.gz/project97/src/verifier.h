int verifier(float i);
