#include "suprimer_disp.h"


void sup_dispo(char a[20])// a dekhla en parametre 
{
	char a1[20];
	char b1[20];
	char c1[20];

	FILE *l;
	FILE *t;
	l=fopen("Disponibilite.txt","r");
	t=fopen("Disponibilite.tmp","a+");
	while (fscanf(l,"%s %s %s ",a1,b1,c1)!=EOF)//na9raw mil fichier temporaire
	{
		if (strcmp(a,a1)!=0)//ken la valeur ili na9raw fiha differente mil parametre ya3ni ncopiw i ligne fel fichier e jdid
		{
			fprintf(t,"%s %s %s\n",a1,b1,c1);//copie de la ligne fel fichier jdid
		}
	}
	fclose(l);
	fclose(t);
	remove("Disponibilite.txt");//nfas5ou il fichier li9dim
	rename("Disponibilite.tmp","Disponibilite.txt");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blastou
}
