#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif




#include <stdio.h>
#include <string.h>
#include "personne.h"
#include <gtk/gtk.h>

enum   
{       
        NOMPRENOM,
        DATENAISS,
	CIN,
	POIDS,
        MALADIE,
        FUMEUR,
        ANCIEN,
	TAILLE,
	ALCOOLIC,
	URG,
	GROUP,
	POINTURE,
};



void ajouter_personne(Personne p)
{

 FILE *f;
  f=fopen("utilisateur.txt","a+");
  if(f!=NULL) 
  {
  fprintf(f,"%s %s %s %s %s %s %s %s %s %s %s %s \n",p.NomPrenom,p.datenaiss,p.CIN,p.poids,p.Maladie,p.Fumeur,p.Ancien,p.Taille,p.alcoolic,p.urg,p.group,p.pointure);
  fclose(f);

}


