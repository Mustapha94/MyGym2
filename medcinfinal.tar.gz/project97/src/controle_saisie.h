#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>




int controle_saisie_annee(char x[6]);
int controle_saisie_numero(char x[15]);
int digital(char x[15]);
int controle_saisie_p(char x[15]);
