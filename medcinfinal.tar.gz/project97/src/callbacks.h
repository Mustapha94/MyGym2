#include <gtk/gtk.h>


void
on_button7_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);


void
on_button8_clicked                     (GtkWidget      *widget,
                                        gpointer         user_data);


void
on_button5_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);


void
on_buttoninfomed_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonhorrairemed_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonfichemed_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonrecmed_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonmodifinfmed_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonretourespmed_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonajoutfiche_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonretourespmed2_clicked         (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonmodiffiche_clicked            (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_clicked                      (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonretourfiche1_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonvaliderajout_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonretourfiche2_activate         (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonvalidinf_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonannulinfmed_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonenvoyerrecmed_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonretourespmed3_clicked         (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttondecmed_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonvaliderrdvmed_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonretourespmed5_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonsupprimerfiche_clicked        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonchercherfichesup_clicked      (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonimcmed_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonmodifierfichemed_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonretourfiche2_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonrefrechfichemed_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonafficherdismed_clicked        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_b9_clicked                          (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_b11_clicked                         (GtkWidget       *button,
                                        gpointer         user_data);

void
on_b29_clicked                         (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_b27_clicked                         (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonlogin_clicked                 (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_b31_clicked                         (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_b32_clicked                         (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_button99_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);
