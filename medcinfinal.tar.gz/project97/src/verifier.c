#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "verifier.h"





int verifier(float i)

{

	float imc;
	FILE *f;
	
	f=fopen("IMC.txt","r");

	while(fscanf(f,"%f",&imc)!=EOF)
	{

	if (i<18.5)
	{ imc=1;
	 return imc;
	}
	else if ((i>18.5)&&(i<25))
	{
	imc=2;
	return imc;
	}
	else if (i>25)
	{
	imc=3;
	return imc;
	}}



	f=fclose(f);
	
	

	return -1;

}
