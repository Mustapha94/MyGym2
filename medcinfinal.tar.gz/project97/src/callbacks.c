#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "personne.h"
#include "dispo.h"
#include "verifier.h"
#include "controle_saisie.h"
#include "Disponibilite.h"
#include "login.h"
#include "suprimer_disp.h"


GtkWidget *menu;
GtkWidget *horraire_de_travail;
GtkWidget *information;
GtkWidget *Fiche_medicale;
GtkWidget *reclamation;
GtkWidget *Affichage_du_fiche;
GtkWidget *Ajouter_fiche;
GtkWidget *Valider;
GtkWidget *Supprimer;
GtkWidget *Modifier;
GtkWidget *Afficher;
GtkWidget *Modifier_information;
GtkWidget *treeview1;
GtkWidget *window1;
GtkWidget *IMC_Regime_Conseil;
GtkWidget *Modifier_fiche;
GtkWidget *treeview2;
GtkWidget *horraire_de_travail;
GtkWidget *disponibilite_med;
GtkWidget *ajouter_disponible;
GtkWidget *treeview5;
GtkWidget *suprimer_disponible;










void
on_button5_clicked                     (GtkWidget      *button,
                                        gpointer         user_data)
{

}






void
on_button8_clicked                     (GtkWidget       *widget,
                                        gpointer         user_data)
{
	Affichage_du_fiche=lookup_widget(widget,"Affichage_du_fiche");
	gtk_widget_destroy(Affichage_du_fiche);
	Fiche_medicale=create_Fiche_medicale();
	gtk_widget_show(Fiche_medicale);
}






void
on_buttoninfomed_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{
information=create_information();
gtk_widget_show(information);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"menu")));
GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;
GtkWidget *output6;
GtkWidget *output7;


char Nom[30];
char Prenom[10];
char sexe[10];
char Date[300];
char tel[10];
char adresse[30];
char mot[30];
FILE *f;
f=fopen("informationmed.txt","a+");
if (f!=NULL)
	{
	    while(fscanf(f,"%s %s %s %s %s %s %s \n",Nom,Prenom,sexe,Date,tel,adresse,mot)!=EOF)
		{ output1=lookup_widget(information,"labelmed73");
		  gtk_label_set_text(GTK_LABEL(output1),Nom);
		  output2=lookup_widget(information,"labelmed74");
		  gtk_label_set_text(GTK_LABEL(output2),Prenom);
		  output3=lookup_widget(information,"labelmed75");
		  gtk_label_set_text(GTK_LABEL(output3),sexe);
		  output4=lookup_widget(information,"labelmed76");
		  gtk_label_set_text(GTK_LABEL(output4),Date);
		  output5=lookup_widget(information,"labelmed77");
		  gtk_label_set_text(GTK_LABEL(output5),tel);
		  output6=lookup_widget(information,"labelmed78");
		  gtk_label_set_text(GTK_LABEL(output6),adresse);
		  output7=lookup_widget(information,"labelmed79");
		  gtk_label_set_text(GTK_LABEL(output7),mot);}
		fclose(f);}

}


void
on_buttonhorrairemed_clicked           (GtkWidget       *button,
                                        gpointer         user_data)
{
	disponibilite_med=create_disponibilite_med();
	gtk_widget_show(disponibilite_med);
	gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"menu")));
	
	
	treeview5=lookup_widget(disponibilite_med,"treeview5");
	afficher_disponibilite(treeview5);

}


void
on_buttonfichemed_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
Fiche_medicale=create_Fiche_medicale();
gtk_widget_show(Fiche_medicale);
gtk_widget_hide(GTK_WIDGET(lookup_widget(objet_graphique,"menu")));
treeview1=lookup_widget(Fiche_medicale,"treeview1");
afficher_personne(treeview1);











}


void
on_buttonrecmed_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
reclamation=create_reclamation();
gtk_widget_show(reclamation);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"menu")));

}


void
on_buttonmodifinfmed_clicked           (GtkWidget       *button,
                                        gpointer         user_data)
{
Modifier_information=create_Modifier_information();
gtk_widget_show(Modifier_information);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"information")));

}


void
on_buttonretourespmed_clicked          (GtkWidget       *button,
                                        gpointer         user_data)
{
menu=create_menu();
gtk_widget_show(menu);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"information")));
}


void
on_buttonajoutfiche_clicked            (GtkWidget       *button,
                                        gpointer         user_data)
{
Ajouter_fiche=create_Ajouter_fiche();
gtk_widget_show(Ajouter_fiche);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Fiche_medicale")));
}


void
on_buttonretourespmed2_clicked         (GtkWidget       *button,
                                        gpointer         user_data)
{
menu=create_menu();
gtk_widget_show(menu);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Fiche_medicale")));
}


void
on_buttonmodiffiche_clicked            (GtkWidget       *button,
                                        gpointer         user_data)
{
Modifier_information=create_Modifier_information();
gtk_widget_show(Modifier_information);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"information")));
}


void
on_button_clicked                      (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_buttonretourfiche1_clicked          (GtkWidget       *button,
                                        gpointer         user_data)
{
Fiche_medicale=create_Fiche_medicale();
gtk_widget_show(Fiche_medicale);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Affichage_du_fiche")));
}


void
on_buttonvaliderajout_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
Personne p;



GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget *input6;
GtkWidget *input7;
GtkWidget *input8;
GtkWidget *input9;
GtkWidget *input10;
GtkWidget *input11;
GtkWidget *output;






input1=lookup_widget(objet,"entrymed7");
strcpy(p.NomPrenom,gtk_entry_get_text(GTK_ENTRY(input1)));


input2=lookup_widget(objet,"entrymed46");
strcpy(p.datenaiss,gtk_entry_get_text(GTK_ENTRY(input2)));
input3=lookup_widget(objet,"entrymed50");
strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(input3)));
input4=lookup_widget(objet,"entrymed4");
strcpy(p.poids,gtk_entry_get_text(GTK_ENTRY(input4)));
input5=lookup_widget(objet,"entrymed3");
strcpy(p.Maladie,gtk_entry_get_text(GTK_ENTRY(input5)));
input6=lookup_widget(objet,"entrymed5");
strcpy(p.Fumeur,gtk_entry_get_text(GTK_ENTRY(input6)));
input7=lookup_widget(objet,"entrymed1");
strcpy(p.Ancien,gtk_entry_get_text(GTK_ENTRY(input7)));
input8=lookup_widget(objet,"entrymed2");
strcpy(p.Taille,gtk_entry_get_text(GTK_ENTRY(input8)));
input9=lookup_widget(objet,"entrymed23");
strcpy(p.alcoolic,gtk_entry_get_text(GTK_ENTRY(input9)));
input10=lookup_widget(objet,"entrymed21");
strcpy(p.urg,gtk_entry_get_text(GTK_ENTRY(input10)));
input11=lookup_widget(objet,"entrymed22");
strcpy(p.group,gtk_entry_get_text(GTK_ENTRY(input11)));
/////*/**/
output= lookup_widget(objet, "labeloutputmed");
 if ((controle_saisie_numero(p.cin)==0)||(controle_saisie_p(p.Taille)==0)||(controle_saisie_p(p.poids)==0)||(controle_saisie_numero(p.urg)==0))
{
gtk_label_set_text(GTK_LABEL(output), "veuillez verifier votre saisie !");
}
else {
ajouter_personne(p);
Fiche_medicale=create_Fiche_medicale();
gtk_widget_show(Fiche_medicale);
gtk_widget_hide(GTK_WIDGET(lookup_widget(objet,"Ajouter_fiche")));
treeview1=lookup_widget(Fiche_medicale,"treeview1");
afficher_personne(treeview1);
}

}



void
on_buttonretourfiche2_activate         (GtkWidget       *button,
                                        gpointer         user_data)
{
Fiche_medicale=create_Fiche_medicale();
gtk_widget_show(Fiche_medicale);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Ajouter_fiche")));
}


void
on_buttonvalidinf_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
information=create_information();
gtk_widget_show(information);
gtk_widget_hide(GTK_WIDGET(lookup_widget(objet,"Modifier_information")));
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget *input6;
GtkWidget *input7;


char Nom[30];
char Prenom[10];
char sexe[10];
char Date[300];
char tel[10];
char adresse[30];
char mot[30];


input1=lookup_widget(objet,"entrymed14");
strcpy(Nom,gtk_entry_get_text(GTK_ENTRY(input1)));
input2=lookup_widget(objet,"entrymed15");
strcpy(Prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
input3=lookup_widget(objet,"entrymed16");
strcpy(sexe,gtk_entry_get_text(GTK_ENTRY(input3)));
input4=lookup_widget(objet,"entrymed17");
strcpy(Date,gtk_entry_get_text(GTK_ENTRY(input4)));
input5=lookup_widget(objet,"entrymed18");
strcpy(tel,gtk_entry_get_text(GTK_ENTRY(input5)));
input6=lookup_widget(objet,"entrymed19");
strcpy(adresse,gtk_entry_get_text(GTK_ENTRY(input6)));
input7=lookup_widget(objet,"entrymed20");
strcpy(mot,gtk_entry_get_text(GTK_ENTRY(input7)));


FILE *f;
f=fopen("informationmed.txt","w");
fprintf(f,"%s %s %s %s %s %s %s \n",Nom,Prenom,sexe,Date,tel,adresse,mot);
fclose(f); 


}


void
on_buttonannulinfmed_clicked           (GtkWidget       *button,
                                        gpointer         user_data)
{
information=create_information();
gtk_widget_show(information);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Modifier_information")));
}


void
on_buttonenvoyerrecmed_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
menu=create_menu();
gtk_widget_show(menu);
gtk_widget_hide(GTK_WIDGET(lookup_widget(objet_graphique,"reclamation")));
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;


char Nom[30];
char Date[10];
char Rec[300];



input1=lookup_widget(objet_graphique,"entrymed48");
strcpy(Nom,gtk_entry_get_text(GTK_ENTRY(input1)));
input2=lookup_widget(objet_graphique,"entrymed47");
strcpy(Date,gtk_entry_get_text(GTK_ENTRY(input2)));
input3=lookup_widget(objet_graphique,"entrymed49");
strcpy(Rec,gtk_entry_get_text(GTK_ENTRY(input3)));



FILE *f;
f=fopen("reclamation.txt","a+");
fprintf(f,"%s %s %s \n",Nom,Date,Rec);
fclose(f); 
reclamation=create_reclamation();
gtk_widget_show(reclamation);
gtk_widget_hide(GTK_WIDGET(lookup_widget(objet_graphique,"Menu")));
}


void
on_buttonretourespmed3_clicked         (GtkWidget       *button,
                                        gpointer         user_data)
{
menu=create_menu();
gtk_widget_show(menu);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamation")));
}


void
on_buttondecmed_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"menu")));
}


void
on_buttonvaliderrdvmed_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{



}


void
on_buttonretourespmed5_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonsupprimerfiche_clicked        (GtkWidget       *button,
                                        gpointer         user_data)
{
window1=create_window1();
gtk_widget_show(window1);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Fiche_medicale")));
}


void
on_buttonchercherfichesup_clicked      (GtkWidget       *widget,
                                        gpointer         user_data)
{
	char cin[30];
	GtkWidget *input1;
	window1=lookup_widget(widget,"window1");
	input1=lookup_widget(widget,"entrymed51");
	strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input1)));
	sup_speci(cin);
}


void
on_buttonimcmed_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
float imc;
IMC_Regime_Conseil=create_IMC_Regime_Conseil();
gtk_widget_show(IMC_Regime_Conseil);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"menu")));
GtkWidget *output;
output=lookup_widget(button,"labelmed150");
int x=verifier(imc);
	if (x==-1)
	{
		gtk_label_set_text(GTK_LABEL(output),"erreur d'authentification");
 

	
	}
	else
	{	
		switch(x)
		{
			case 1:{gtk_label_set_text(GTK_LABEL(output),"vous êtes maigre, au sens médical du terme. Aussi peut-il apparaître nécessaire pour vous de grossir");
				break;}
			case 2:{gtk_label_set_text(GTK_LABEL(output),"vous êtes de corpulence normale, c’est-à-dire que vous n’êtes ni en surpoids, ni maigre. Continuez à manger équilibré, à faire de l’exercice régulièrement : ce mode de vie sain est garant d’une bonne santé, sans oublier la notion de plaisir bien sûr");
				break;}
			case 3:{gtk_label_set_text(GTK_LABEL(output),"vous êtes de corpulence normale, c’est-à-dire que vous n’êtes ni en surpoids, ni maigre. Continuez à manger équilibré, à faire de l’exercice régulièrement : ce mode de vie sain est garant d’une bonne santé, sans oublier la notion de plaisir bien sûr");
				break;}
		}
	}
}




void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)

{
	
gchar *NOMPRENOM; 
gchar *DATENAISS;
gchar *CIN;
gchar *POIDS;
gchar *MALADIE;
gchar *FUMEUR;
gchar *ANCIEN;
gchar *TAILLE;
gchar *ALCOOLIC;
gchar *URG;
gchar *GROUP;

GtkWidget *Modifier_fiche;
GtkWidget *current;
GtkTreeIter iter;
GtkWidget *L17;
GtkWidget *L18;
GtkWidget *L19;
GtkWidget *E6;
GtkWidget *E7;
GtkWidget *E8;
GtkWidget *E9;
GtkWidget *E10;
GtkWidget *E11;
GtkWidget *E12;
GtkWidget *E13;
GtkWidget *E14;
GtkWidget *E15;
GtkWidget *E16;

GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(model,&iter,path))
{gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&NOMPRENOM,1,&DATENAISS,2,&CIN,3,&POIDS,4,&MALADIE,5,&FUMEUR,6,&ANCIEN,7,&TAILLE,8,&ALCOOLIC,9,&URG,10,&GROUP,-1);}
Modifier_fiche = create_Modifier_fiche();


E14=lookup_widget(Modifier_fiche,"entrymed60");
E15=lookup_widget(Modifier_fiche,"entrymed61");
E16=lookup_widget(Modifier_fiche,"entrymed62");
E6=lookup_widget(Modifier_fiche,"entrymed52");
E7=lookup_widget(Modifier_fiche,"entrymed53");
E8=lookup_widget(Modifier_fiche,"entrymed54");
E9=lookup_widget(Modifier_fiche,"entrymed55");
E10=lookup_widget(Modifier_fiche,"entrymed56");
E11=lookup_widget(Modifier_fiche,"entrymed57");
E12=lookup_widget(Modifier_fiche,"entrymed58");
E13=lookup_widget(Modifier_fiche,"entrymed59");

gtk_entry_set_text(GTK_ENTRY(E14),NOMPRENOM);
gtk_entry_set_text(GTK_ENTRY(E15),DATENAISS);
gtk_entry_set_text(GTK_ENTRY(E16),CIN);
gtk_entry_set_text(GTK_ENTRY(E6),POIDS);
gtk_entry_set_text(GTK_ENTRY(E7),MALADIE);
gtk_entry_set_text(GTK_ENTRY(E8),FUMEUR);
gtk_entry_set_text(GTK_ENTRY(E9),ANCIEN);
gtk_entry_set_text(GTK_ENTRY(E10),TAILLE);
gtk_entry_set_text(GTK_ENTRY(E11),ALCOOLIC);
gtk_entry_set_text(GTK_ENTRY(E12),URG);
gtk_entry_set_text(GTK_ENTRY(E13),GROUP);



gtk_widget_show (Modifier_fiche);
}



void
on_buttonmodifierfichemed_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	char NomPrenom[30];
	char datenaiss[10];
	char cin[30];
	char poids[10];
	char Maladie[300];
	char Fumeur[10];
	char Ancien[30];
	char Taille[30];
	char alcoolic[30];
	char urg[30];
	char group[30];


GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget *input6;
GtkWidget *input7;
GtkWidget *input8;
GtkWidget *input9;
GtkWidget *input10;
GtkWidget *input11;
Fiche_medicale=create_Fiche_medicale();
gtk_widget_show(Fiche_medicale);
gtk_widget_hide(GTK_WIDGET(lookup_widget(objet_graphique,"menu")));
treeview1=lookup_widget(Fiche_medicale,"treeview1");

input1=lookup_widget(objet_graphique,"entrymed60");
strcpy(NomPrenom,gtk_entry_get_text(GTK_ENTRY(input1)));
input2=lookup_widget(objet_graphique,"entrymed61");
strcpy(datenaiss,gtk_entry_get_text(GTK_ENTRY(input2)));
input3=lookup_widget(objet_graphique,"entrymed62");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input3)));
input4=lookup_widget(objet_graphique,"entrymed52");
strcpy(poids,gtk_entry_get_text(GTK_ENTRY(input4)));
input5=lookup_widget(objet_graphique,"entrymed53");
strcpy(Maladie,gtk_entry_get_text(GTK_ENTRY(input5)));
input6=lookup_widget(objet_graphique,"entrymed54");
strcpy(Fumeur,gtk_entry_get_text(GTK_ENTRY(input6)));
input7=lookup_widget(objet_graphique,"entrymed55");
strcpy(Ancien,gtk_entry_get_text(GTK_ENTRY(input7)));
input8=lookup_widget(objet_graphique,"entrymed56");
strcpy(Taille,gtk_entry_get_text(GTK_ENTRY(input8)));
input9=lookup_widget(objet_graphique,"entrymed57");
strcpy(alcoolic,gtk_entry_get_text(GTK_ENTRY(input9)));
input10=lookup_widget(objet_graphique,"entrymed58");
strcpy(urg,gtk_entry_get_text(GTK_ENTRY(input10)));
input11=lookup_widget(objet_graphique,"entrymed59");
strcpy(group,gtk_entry_get_text(GTK_ENTRY(input11)));
modifier(NomPrenom,datenaiss,cin,poids,Maladie,Fumeur,Ancien,Taille,alcoolic,urg,group);

}


void
on_buttonretourfiche2_clicked          (GtkWidget       *button,
                                        gpointer         user_data)
{
Fiche_medicale=create_Fiche_medicale();
gtk_widget_show(Fiche_medicale);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Ajouter_fiche")));
treeview1=lookup_widget(Fiche_medicale,"treeview1");
afficher_personne(treeview1);
}


void
on_buttonrefrechfichemed_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
treeview1=lookup_widget(Fiche_medicale,"treeview1");
afficher_personne(treeview1);
}


void
on_buttonafficherdismed_clicked        (GtkWidget       *button,
                                        gpointer         user_data)
{

treeview2=lookup_widget(Fiche_medicale,"treeview2");
afficher(treeview2);
}


void
on_b9_clicked                          (GtkWidget       *widget,
                                        gpointer         user_data)
{
	GtkWidget *disponible;
	GtkWidget *ajouter_disponible;
	disponibilite_med=lookup_widget(widget,"disponibilite_med");
	gtk_widget_destroy(disponibilite_med);
	ajouter_disponible=create_ajouter_disponible();
	gtk_widget_show(ajouter_disponible);
}


void
on_b11_clicked                         (GtkWidget       *button,
                                        gpointer         user_data)
{

	suprimer_disponible=create_suprimer_disponible();
	gtk_widget_show(suprimer_disponible);
	gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"disponibilite_med")));	
}


void
on_b29_clicked                         (GtkWidget       *widget,
                                        gpointer         user_data)
{
	GtkWidget *combo2;
	GtkWidget *combo3;
	GtkWidget *combo4;
	dispo s;

	combo2=lookup_widget(widget, "combo2");
	combo3=lookup_widget(widget, "combo3");
	combo4=lookup_widget(widget, "combo4");

	strcpy(s.jour,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo2)));
	strcpy(s.debut,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo3)));
	strcpy(s.fin,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo4)));

	ajou_disponibilite(s);
}


void
on_b27_clicked                         (GtkWidget       *button,
                                        gpointer         user_data)
{
	disponibilite_med=create_disponibilite_med();
	gtk_widget_show(disponibilite_med);
	gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"ajouter_disponible")));
	
	
	treeview5=lookup_widget(disponibilite_med,"treeview5");
	afficher_disponibilite(treeview5);

}


void
on_buttonlogin_clicked                 (GtkWidget       *widget,
                                        gpointer         user_data)
{
	
	GtkWidget *authentification;
	GtkWidget *user, *pwd;
	GtkWidget *output;
	authentification=create_authentification();
	
	int x;
	char login3[20];
	char Password3[20];

	user=lookup_widget(widget,"user");
	pwd=lookup_widget(widget,"pwd");
	output=lookup_widget(widget,"incorrect");
	//role=lookup_widget(widget,"role");
	strcpy(login3,gtk_entry_get_text(GTK_ENTRY(user)));
	strcpy(Password3,gtk_entry_get_text(GTK_ENTRY(pwd)));
	x = verif(login3,Password3);
	if (x==-1)
	{
		gtk_label_set_text(GTK_LABEL(output),"mdp incorrect");
	}	
	else
	{	
		authentification=lookup_widget(widget,"authentification");
		gtk_widget_destroy(authentification);
		menu=create_menu();
		gtk_widget_show(menu);	
	}
}


void
on_b31_clicked                         (GtkWidget       *widget,
                                        gpointer         user_data)
{
	suprimer_disponible=lookup_widget(widget,"suprimer_disponible");
	gtk_widget_destroy(suprimer_disponible);
	disponibilite_med=create_disponibilite_med();
	gtk_widget_show(disponibilite_med);	
	treeview5=lookup_widget(disponibilite_med,"treeview5");
	afficher_disponibilite(treeview5);
}


void
on_b32_clicked                         (GtkWidget       *widget,
                                        gpointer         user_data)
{
char a[20];

	GtkWidget *input1;
	GtkWidget *suprimer_disponible;

	suprimer_disponible=lookup_widget(widget,"suprimer_disponible");

	input1=lookup_widget(widget,"entry1");

	strcpy(a,gtk_entry_get_text(GTK_ENTRY(input1)));
	
	sup_dispo(a);
}


void
on_button99_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
menu=create_menu();
gtk_widget_show(menu);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"disponibilite_med")));
}

