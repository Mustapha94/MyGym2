#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif




#include <stdio.h>
#include <string.h>
#include "diet.h"
#include <gtk/gtk.h>


void ajouterdiet(diet w)
{
FILE *fd; 
fd=fopen("dietee.txt","a+");
fprintf(fd,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",w.cin,w.nom,w.prenom,w.jour,w.mois,w.annee,w.adresse,w.mail,w.num,w.login,w.mot,w.sp);
fclose(fd);
}
/***************************/

int verif_diet(char x[])
{
diet z;

FILE *fd ;

fd=fopen("dietee.txt","r");
if (fd!=NULL)
  {
	while (fscanf(fd,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",z.cin,z.nom,z.prenom,&z.jour,&z.mois,&z.annee,z.adresse,z.mail,z.num,z.login,z.mot,z.sp) !=EOF)
 {       if (strcmp(z.cin,x)==0)
	{ 	
		return 1;
	}

  }
return 0 ;
fclose(fd);
 }

}

/***********************/


diet chercher_diet(char x[])
{
diet z;
FILE *fd ;

fd=fopen("dietee.txt","r");
if (fd!=NULL)
  {
	while (fscanf(fd,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",z.cin,z.nom,z.prenom,&z.jour,&z.mois,&z.annee,z.adresse,z.mail,z.num,z.login,z.mot,z.sp) !=EOF)
 {       if (strcmp(z.cin,x)==0)
	{ 
	 return z;
	}

  }
fclose(fd);
   
  }

}



/**********************************/
void supprimer_diet(char id[])
{
diet z;
FILE *fd; 
FILE *fsupd; 


fd=fopen("dietee.txt","r");
fsupd=fopen("dietesup.txt","a+");
if (fd!=NULL)
{
while (fscanf(fd,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",z.cin,z.nom,z.prenom,&z.jour,&z.mois,&z.annee,z.adresse,z.mail,z.num,z.login,z.mot,z.sp) !=EOF)
{
	if (strcmp(id,z.cin) !=0)
     { fprintf(fsupd,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",z.cin,z.nom,z.prenom,z.jour,z.mois,z.annee,z.adresse,z.mail,z.num,z.login,z.mot,z.sp);
     }
}

fclose(fd);
fclose(fsupd);
}
remove("dietee.txt");
rename("dietesup.txt.txt","dietee.txt");
}
/******************************************/










