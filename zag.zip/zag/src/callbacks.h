#include <gtk/gtk.h>


void
on_Gcompte_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_reclamation_clicked                 (GtkWidget      *button,
                                        gpointer         user_data);

void
on_Planhoraire_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Cadherent_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_Ckine_clicked                       (GtkWidget      *button,
                                        gpointer         user_data);

void
on_Cnuti_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Ccoch_clicked                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Cdiet_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Cnet_clicked                        (GtkWidget      *button,
                                        gpointer         user_data);

void
on_Retourcompte_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Ajadh_clicked                       (GtkWidget      *button,
                                        gpointer         user_data);

void
on_reretourmenu_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourlista_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_ajouinfo_clicked                    (GtkWidget        *objet_graphique,
                                        gpointer         user_data);



void
on_Ediet_clicked                       (GtkWidget        *button,
                                        gpointer         user_data);

void
on_Eagent_clicked                      (GtkWidget        *button,
                                        gpointer         user_data);

void
on_Enut_clicked                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Ekine_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Ecoch_clicked                       (GtkWidget      *button,
                                        gpointer         user_data);

void
on_ajoutplan_clicked                   (GtkWidget        *button,
                                        gpointer         user_data);

void
on_enregistrerplan_clicked             (GtkWidget        *objet_graphique,
                                        gpointer         user_data);

void
on_retourplan_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_affichelundi_clicked                (GtkWidget        *button,
                                        gpointer         user_data);

void
on_affichemardi_clicked                (GtkWidget        *button,
                                        gpointer         user_data);

void
on_affichemercredi_clicked             (GtkWidget        *button,
                                        gpointer         user_data);

void
on_affichejeudi_clicked                (GtkWidget        *button,
                                        gpointer         user_data);

void
on_affichevendredi_clicked             (GtkWidget        *button,
                                        gpointer         user_data);

void
on_affichesamedi_clicked               (GtkWidget        *button,
                                        gpointer         user_data);

void
on_ajoutcal_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Retourplaningtravail_clicked        (GtkWidget       *button,
                                        gpointer         user_data);


void
on_plancoche_clicked                   (GtkWidget        *button,
                                        gpointer         user_data);

void
on_plandiete_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_plankine_clicked                    (GtkWidget        *button,
                                        gpointer         user_data);

void
on_planenutr_clicked                   (GtkWidget        *button,
                                        gpointer         user_data);

void
on_planeage_clicked                    (GtkWidget        *button,
                                        gpointer         user_data);

void
on_retourlesplane_clicked              (GtkWidget        *button,
                                        gpointer         user_data);





void
on_enregitrementduplaning_clicked      (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retouuuuuuuuuuuuuuurr_clicked       (GtkWidget      *button,
                                        gpointer         user_data);

void
on_afficheduplaningdetravail_clicked   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourlesplane_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_plancoche_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_plandiete_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_plankine_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_planeage_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_planenutr_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_enregitrementduplaning_clicked      (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retouuuuuuuuuuuuuuurr_clicked       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_afficheduplaningdetravail_clicked   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);



void
on_connexion_clicked                   (GtkWidget      *button,
                                        gpointer         user_data);

void
on_deconnexion_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_supp_clicked                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_modifier_clicked                    (GtkWidget      *button,
                                        gpointer         user_data);

void
on_cherchercoach_clicked               (GtkWidget       *button,
                                        gpointer         user_data);



void
on_ajoutcoach_clicked                  (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_retourGestioncompteaparirdelalistedescoach_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_ajoutercoach_clicked                (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_affichelalistedescoach_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_retourlistedescoach_clicked         (GtkWidget      *button,
                                        gpointer         user_data);

void
on_Modifierlecoachexistant_clicked     (GtkWidget     *button,
                                        gpointer         user_data);

void
on_Supprimerlecoachexistant__clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_affichecoachchercher_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_retourlisteGestion_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Retourplans_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourduplaningauplane_clicked      (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retouraumenuaparirdesreclamcoach_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourdeplaningkineauplane_clicked  (GtkWidget      *button,
                                        gpointer         user_data);

void
on_retourduplaningkineauplane_clicked  (GtkWidget      *button,
                                        gpointer         user_data);

//void
//on_retourduplaningagentauplane_clicked (GtkWidget        *button,
                                       // gpointer         user_data);

void
on_retourplaningagentauplane_clicked   (GtkWidget        *button,
                                        gpointer         user_data);

void
on_retourplaningdietauplane_clicked    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourdelalistekineaucompte__clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajouterunnvkine_clicked             (GtkWidget        *button,
                                        gpointer         user_data);

void
on_Affichekinechercher_clicked         (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajouterkine_clicked                 (GtkWidget      *button,
                                        gpointer         user_data);

void
on_afficherinfotreeview_clicked        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_supprimerlesinfocomptekine_clicked  (GtkWidget        *button,
                                        gpointer         user_data);

void
on_modifiercomptekineaman_clicked      (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajouterunnvdiet_clicked             (GtkWidget        *button,
                                        gpointer         user_data);

void
on_retourdudietauplan_clicked          (GtkWidget      *button,
                                        gpointer         user_data);

void
on_afficherdiet_clicked                (GtkWidget        *button,
                                        gpointer         user_data);

void
on_ajouterlediet_clicked               (GtkWidget      *button,
                                        gpointer         user_data);

void
on_afficherlediet_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_supprimerdiet_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_modifierdiet_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourdietliste_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajouterunnvnut_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajouternut_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_afficher_nut__clicked               (GtkWidget      *button,
                                        gpointer         user_data);

//void
//on_cherchernut_clicked                 (GtkWidget      *button,
                                       // gpointer         user_data);

void
on_retournut_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_supprimernut_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_modifiernut_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_cherchernutee_clicked               (GtkWidget      *button,
                                        gpointer         user_data);

void
on_retouradherentautree_clicked        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_modifieradheren_clicked             (GtkWidget        *button,
                                        gpointer         user_data);

void
on_Supprimeradher_clicked              (GtkWidget        *button,
                                        gpointer         user_data);

void
on_affichermtnarkafretour_clicked      (GtkWidget        *button,
                                        gpointer         user_data);
