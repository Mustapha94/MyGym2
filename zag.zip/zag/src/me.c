#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif




#include <stdio.h>
#include <string.h>
#include "me.h"
#include <gtk/gtk.h>

enum   
{       
       
        NOM,
	PRENOM,
	JOUR,
	MOIS,
	ANNEE,
	CIN,
       	LOGIN,
	MOT,
        COLUMNS
};

void ajouterpersonne(Personne p)
{
FILE *fad; 
fad=fopen("utilisateur.txt","a+");
fprintf(fad,"%s %s %s %s %s %d %d %d \n",p.nom,p.prenom,p.login,p.mot,p.cin,p.jour,p.annee,p.mois);
fclose(fad);

}





/***************************/

int verif_adherent(char x[])
{
Personne m;

FILE *fad ;

fad=fopen("utilisateur.txt","r");
if (fad!=NULL)
  {
	while (fscanf(fad,"%s %s %s %s %s %d %d %d \n",m.nom,m.prenom,m.login,m.mot,m.cin,&m.jour,&m.annee,&m.mois) !=EOF)
 {       if (strcmp(m.cin,x)==0)
	{ 	
		return 1;
	}

  }
return 0 ;
fclose(fad);
 }

}




/***********************/


Personne chercher_adherent(char x[])
{
Personne m;
FILE *fad ;

fad=fopen("utilisateur.txt","r");
if (fad!=NULL)
  {
	while (fscanf(fad,"%s %s %s %s %s %d %d %d \n",m.nom,m.prenom,m.login,m.mot,m.cin,&m.jour,&m.annee,&m.mois) !=EOF)
 {       if (strcmp(m.cin,x)==0)
	{ 
	 return m;
	}

  }
fclose(fad);
   
  }

}

/**********************************/
void supprimer_adherent(char id[])
{
Personne p;
FILE *fad; 
FILE *fsupad; 


fad=fopen("utilisateur.txt","r");
fsupad=fopen("utilisateurs.txt","a+");
if (fad!=NULL)
{
while (fscanf(fad,"%s %s %s %s %s %d %d %d \n",p.nom,p.prenom,p.login,p.mot,p.cin,&p.jour,&p.annee,&p.mois) !=EOF)
{
	if (strcmp(id,p.cin) !=0)
     { 
fprintf(fsupad,p.nom,p.prenom,p.login,p.mot,p.cin,p.jour,p.annee,p.mois);
     }
}

fclose(fad);
fclose(fsupad);
}
remove("utilisateur.txt");
rename("utilisateurs.txt","utilisateur.txt");
}
/******************************************/









































void afficherpersonne(GtkWidget *liste)
{ 
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;
	
	
	char nom[30];
	char prenom[30];
	char cin[30];
	char login[100];
	char mot[30];
	char jour[30];
	char mois[30];
	char annee[30];

        store=NULL;

       FILE *fad;
	
	//store=gtk_tree_view_get_model(liste);	
	if (store==NULL)
	{

               

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("nom", renderer,"text",NOM, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);	
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("prenom", renderer,"text",PRENOM, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("jour", renderer,"text",JOUR, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("mois", renderer,"text",MOIS, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("nom", renderer,"text",ANNEE, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);	


	 	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("cin", renderer,"text",CIN, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
		

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("login", renderer,"text",LOGIN, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

               
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("mot", renderer,"text",MOT, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING);
	

		
	
	}

	
	

	fad = fopen("utilisateur.txt", "r");
	
	if(fad==NULL)
	{

		return;
	}		
	else 

	{ fad =fopen("utilisateur.txt", "a+");
              while(fscanf(fad,"%s %s %s %s %s  %s %s %s \n",nom,prenom,cin,login,mot,jour,mois,annee) !=EOF)
		{
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter, NOM, nom, PRENOM, prenom, JOUR, jour, MOIS, mois, ANNEE, annee, CIN, cin, LOGIN, login, MOT, mot, -1); 
		}
		fclose(fad);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),  GTK_TREE_MODEL (store));
    g_object_unref (store);
	}
}































