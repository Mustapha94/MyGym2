#include <gtk/gtk.h>

typedef struct
{
char cin[30];
char nom[30];
char prenom[30];
char login[100];
char mot[30];

int jour;
int mois;
int annee;
}Personne;

void ajouterpersonne(Personne p);
void afficherpersonne(GtkWidget *liste);

int verif_adherent(char x[]);
Personne chercher_adherent(char x[]);
void supprimer_adherent(char id[]);


