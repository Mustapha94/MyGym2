#include <gtk/gtk.h>

struct Kine
{
char cin[30];
char nom[30];
char prenom[30];
char login[100];
char mot[30];
char adresse[30];
char mail[30];
char num[30];
char sp[30];
int jour;
int mois;
int annee;
};
typedef struct Kine kine;

void ajouterkine(kine k);
void supprimer_kine(char id[]);
kine chercher_kine(char x[]);
int verif_kine(char x[]);
