#include <gtk/gtk.h>






void afficherlistecoach(GtkWidget *treeview);
void afficherlistePcoach(GtkWidget *treeview);


void afficherlistekine(GtkWidget *treeview);

void afficherlistenut(GtkWidget *treeview);
void afficherlisteagent(GtkWidget *treeview);
void afficherlistediet(GtkWidget *treeview);




void afficherlistecomptekine(GtkWidget *treeview);


void afficherlistecomptediet(GtkWidget *treeview);
void afficherlistecomptenut(GtkWidget *treeview);
