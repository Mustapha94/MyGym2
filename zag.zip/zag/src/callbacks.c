#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "me.h"
#include "diet.h"
#include "nut.h"
#include "coach.h"
#include "rec.h"
#include "kine.h"
#include "treeviewm.h"
GtkWidget *adherentaman;
GtkWidget *nutaman;
GtkWidget *ajoutnut;
GtkWidget *infonut;
GtkWidget *treeviewnut;
GtkWidget *dietchercher;
GtkWidget *infodiet;
GtkWidget *comptediet;
GtkWidget *treeviewcdiet;
GtkWidget *comptekineaman;
GtkWidget *comptekine;
GtkWidget *kineinfo;
GtkWidget *treeviewcomptekine;
GtkWidget *reclammation;
GtkWidget *treeviewrecl;
GtkWidget *authentification;
GtkWidget *espacemed;
GtkWidget *menu;
GtkWidget *compte;
GtkWidget *trei;
GtkWidget *info;
GtkWidget *treeview1;
GtkWidget  *lesplane;
GtkWidget  *Gestioncomptecoach;
GtkWidget  *editeprofildescoach;
GtkWidget  *coachrechercher;
GtkWidget *treeviewcomptecoach;
GtkWidget *listedesplanningdescoach;
GtkWidget *treeviewcoachp;
GtkWidget *treeviewpkine;
GtkWidget *listeplaningkine;
GtkWidget *listeplaningnut;
GtkWidget *treeviewpnut;
GtkWidget *treeviewpagent;
GtkWidget *listeplaningagent;
GtkWidget *treeviewplaningdiet;
GtkWidget *listeplaningdiet;
void
on_Gcompte_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
compte=create_compte();
gtk_widget_show(compte);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"menu")));
}

//reclammation coach //
void
on_reclamation_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{
menu=lookup_widget(button,"menu");
gtk_widget_destroy(menu);
reclammation=lookup_widget(button,"reclammation");
reclammation=create_reclammation();

gtk_widget_show(reclammation);
      

treeviewrecl=lookup_widget(reclammation,"treeviewrecl");

afficherreclamcoach(treeviewrecl); 
}
void
on_retouraumenuaparirdesreclamcoach_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{
menu=create_menu();
gtk_widget_show(menu);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclammation")));

}




void
on_Planhoraire_clicked                 (GtkWidget      *button,
                                        gpointer         user_data)
{
lesplane=create_lesplane();
gtk_widget_show(lesplane);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"menu")));

}

//compte adherent 
void
on_Cadherent_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
compte=lookup_widget(objet_graphique,"compte");
gtk_widget_destroy(compte);
trei=lookup_widget(objet_graphique,"trei");
trei=create_trei();

gtk_widget_show(trei);
      

treeview1=lookup_widget(trei,"treeview1");

afficherpersonne(treeview1); 
}
//chercheradherentesm faux
void
on_cherchercoach_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{
Personne m;

int test;

adherentaman=create_adherentaman();
gtk_widget_show(adherentaman);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"trei")));
char s[30];
GtkWidget *inputrecherche;
GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;

GtkWidget *output;

inputrecherche=lookup_widget(trei,"entryrecherchecoach");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(inputrecherche)));

output1=lookup_widget(adherentaman,"nomadh");
output2=lookup_widget(adherentaman,"prenomadh");
output3=lookup_widget(adherentaman,"cinadh");

output4=lookup_widget(adherentaman,"loginadh");
output5=lookup_widget(adherentaman,"passeadh");


output=lookup_widget(adherentaman,"Inexistantadh");

test=verif_adherent(s);

  if (test==1)
{
m=chercher_adherent(s);
gtk_label_set_text(GTK_LABEL(output),"");

gtk_entry_set_text(GTK_ENTRY(output1),m.nom);

gtk_entry_set_text(GTK_ENTRY(output2),m.prenom);
gtk_entry_set_text(GTK_ENTRY(output3),m.cin);
gtk_entry_set_text(GTK_ENTRY(output4),m.login);
gtk_entry_set_text(GTK_ENTRY(output5),m.mot);
}



	else
	{
		gtk_label_set_text(GTK_LABEL(output),"identifiant inexistant ");
	}		
	
}
void
on_retouradherentautree_clicked        (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_modifieradheren_clicked             (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_Supprimeradher_clicked              (GtkWidget       *button,
                                        gpointer         user_data)
{

}




void
on_affichermtnarkafretour_clicked      (GtkWidget       *button,
                                        gpointer         user_data)
{

}























//comptekine//
 
void
on_Ckine_clicked                       (GtkWidget     *button,
                                        gpointer         user_data)
{
compte=lookup_widget(button,"compte");
gtk_widget_destroy(compte);
comptekine=lookup_widget(button,"comptekine");
comptekine=create_comptekine();

gtk_widget_show(comptekine);
      

treeviewcomptekine=lookup_widget(comptekine,"treeviewcomptekine");

afficherlistecomptekine(treeviewcomptekine);
 
}
		//ajouter kine
void
on_ajouterunnvkine_clicked             (GtkWidget        *button,
                                        gpointer         user_data)
{
kineinfo=create_kineinfo();
gtk_widget_show(kineinfo);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"comptekine")));
}

void
on_ajouterkine_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{
kine n;
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget *input6;
GtkWidget *input7;
GtkWidget *input8;
GtkWidget *input9;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;

input1=lookup_widget(button,"cinkine");
strcpy(n.cin,gtk_entry_get_text(GTK_ENTRY(input1)));
input2=lookup_widget(button,"nomkine");
strcpy(n.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
input3=lookup_widget(button,"prenomkine");
strcpy(n.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
input4=lookup_widget(button,"adressekine");
strcpy(n.adresse,gtk_entry_get_text(GTK_ENTRY(input4)));
input5=lookup_widget(button,"mailkine");
strcpy(n.mail,gtk_entry_get_text(GTK_ENTRY(input5)));
input6=lookup_widget(button,"numkine");
strcpy(n.num,gtk_entry_get_text(GTK_ENTRY(input6)));
input7=lookup_widget(button,"loginkine");
strcpy(n.login,gtk_entry_get_text(GTK_ENTRY(input7)));
input8=lookup_widget(button,"passekine");
strcpy(n.mot,gtk_entry_get_text(GTK_ENTRY(input8)));
input9=lookup_widget(button,"spkine");
strcpy(n.sp,gtk_entry_get_text(GTK_ENTRY(input9)));

jour=lookup_widget(button,"spinbuttonjkine");
mois=lookup_widget(button,"spinbuttonmkine");
annee=lookup_widget(button,"spinbuttonankine");
n.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
n.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
n.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

ajouterkine(n);
}






































//afficher kine
void
on_afficherinfotreeview_clicked        (GtkWidget       *button,
                                        gpointer         user_data)
{
kineinfo=lookup_widget(button,"kineinfo");
gtk_widget_destroy(kineinfo);
comptekine=lookup_widget(button,"comptekine");
comptekine=create_comptekine();

gtk_widget_show(comptekine);
      

treeviewcomptekine=lookup_widget(comptekine,"treeviewcomptekine");

afficherlistecomptekine(treeviewcomptekine); 
}
//afiichhe kine rechercher 
void
on_Affichekinechercher_clicked         (GtkWidget       *button,
                                        gpointer         user_data)
{
kine t;
int test;

comptekineaman=create_comptekineaman();
gtk_widget_show(comptekineaman);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"comptekine")));
char m[30];
GtkWidget *input;
GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;
GtkWidget *output6;
GtkWidget *output7;
GtkWidget *output8;
GtkWidget *output9;
GtkWidget *output;

input=lookup_widget(button,"chercherkine");
strcpy(m,gtk_entry_get_text(GTK_ENTRY(input)));

output1=lookup_widget(comptekineaman,"cinkinee");
output2=lookup_widget(comptekineaman,"nomkinee");
output3=lookup_widget(comptekineaman,"prenomkinee");
output4=lookup_widget(comptekineaman,"adressekinee");
output5=lookup_widget(comptekineaman,"mailkinee");
output6=lookup_widget(comptekineaman,"numkinee");
output7=lookup_widget(comptekineaman,"loginkinee");
output8=lookup_widget(comptekineaman,"passekinee");
output9=lookup_widget(comptekineaman,"spkinee");

output=lookup_widget(comptekineaman,"Inexistantkine");

test=verif_kine(m);
if(test==1)
{
  t=chercher_kine(m);
gtk_label_set_text(GTK_LABEL(output),"");
gtk_entry_set_text(GTK_ENTRY(output1),t.cin);
gtk_entry_set_text(GTK_ENTRY(output2),t.nom);
gtk_entry_set_text(GTK_ENTRY(output3),t.prenom);
gtk_entry_set_text(GTK_ENTRY(output4),t.adresse);
gtk_entry_set_text(GTK_ENTRY(output5),t.mail);
gtk_entry_set_text(GTK_ENTRY(output6),t.num);
gtk_entry_set_text(GTK_ENTRY(output7),t.login);
gtk_entry_set_text(GTK_ENTRY(output8),t.mot);
gtk_entry_set_text(GTK_ENTRY(output9),t.sp);
}

if (test!=1)
	{
		gtk_label_set_text(GTK_LABEL(output),"identifiant inexistant ");
		
	}
}



//supprimer kine /
void
on_supprimerlesinfocomptekine_clicked  (GtkWidget       *button,
                                        gpointer         user_data)
{//8alta
kine t;

char m[30];
GtkWidget *input;


input=lookup_widget(comptekine,"chercherkine");
strcpy(m,gtk_entry_get_text(GTK_ENTRY(input)));
supprimer_kine(m);




comptekine=create_comptekine();
gtk_widget_show(comptekine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"comptekineaman")));      


treeviewcomptekine=lookup_widget(comptekine,"treeviewcomptekine");

afficherlistecomptekine(treeviewcomptekine); 

}



//modifier kinee ****************************************/


void
on_modifiercomptekineaman_clicked      (GtkWidget       *button,
                                        gpointer         user_data)
{
kine t;
char m[20];

GtkWidget *input;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;
GtkWidget *output6;
GtkWidget *output9;

input=lookup_widget(comptekine,"chercherkine");
strcpy(m,gtk_entry_get_text(GTK_ENTRY(input)));

output2=lookup_widget(comptekineaman,"nomkinee");
strcpy(t.nom,gtk_entry_get_text(GTK_ENTRY(output2)));
output3=lookup_widget(comptekineaman,"prenomkinee");
strcpy(t.prenom,gtk_entry_get_text(GTK_ENTRY(output3)));
output4=lookup_widget(comptekineaman,"adressekinee");
strcpy(t.adresse,gtk_entry_get_text(GTK_ENTRY(output4)));
output5=lookup_widget(comptekineaman,"mailkinee");
strcpy(t.mail,gtk_entry_get_text(GTK_ENTRY(output5)));
output6=lookup_widget(comptekineaman,"numkinee");
strcpy(t.num,gtk_entry_get_text(GTK_ENTRY(output6)));
output9=lookup_widget(comptekineaman,"spkinee");
strcpy(t.sp,gtk_entry_get_text(GTK_ENTRY(output9)));
{
FILE*fkc;
FILE*fsupkc;
char cin[20],nom[20],prenom[20],adresse[20],mail[20],num[20],login[20],mot[20],sp[20];
int jour,mois,annee;
fsupkc=fopen("kinesup.txt","a+");
fkc=fopen("kinee.txt","r");
while (fscanf(fkc,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",cin,nom,prenom,&jour,&mois,&annee,adresse,mail,num,login,mot,sp) !=EOF)
  {
if(strcmp(m,cin)!=0)
	{
 fprintf(fsupkc,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s\n",cin,nom,prenom,jour,mois,annee,adresse,mail,num,login,mot,sp); 
	}     
else 
	{
fprintf(fsupkc,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s\n",cin,t.nom,t.prenom,jour,mois,annee,t.adresse,t.mail,t.num,login,mot,t.sp);
	}
   }
fclose(fkc);
fclose(fsupkc);
remove("kinee.txt");
rename("kinesup.txt","kinee.txt");
}
comptekine=create_comptekine();
gtk_widget_show(comptekine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"comptekineaman")));
treeviewcomptekine=lookup_widget(comptekine,"treeviewcomptekine");

afficherlistecomptekine(treeviewcomptekine); 
}





//compte nut 

void
on_Cnuti_clicked                       (GtkWidget       *button,
                                        gpointer         user_data)
{
infonut=create_infonut();
gtk_widget_show(infonut);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"compte")));
treeviewnut=lookup_widget(infonut,"treeviewnut");

afficherlistecomptenut(treeviewnut);
}


//ajout nut
void
on_ajouterunnvnut_clicked              (GtkWidget       *button,
                                        gpointer         user_data)
{
ajoutnut=create_ajoutnut();
gtk_widget_show(ajoutnut);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"infonut")));
}


void
on_ajouternut_clicked                  (GtkWidget      *button,
                                        gpointer         user_data)
{
nut u;
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget *input6;
GtkWidget *input7;
GtkWidget *input8;
GtkWidget *input9;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;

input1=lookup_widget(button,"nutcin");
strcpy(u.cin,gtk_entry_get_text(GTK_ENTRY(input1)));
input2=lookup_widget(button,"nutnom");
strcpy(u.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
input3=lookup_widget(button,"nutprenom");
strcpy(u.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
input4=lookup_widget(button,"nutadresse");
strcpy(u.adresse,gtk_entry_get_text(GTK_ENTRY(input4)));
input5=lookup_widget(button,"nutmail");
strcpy(u.mail,gtk_entry_get_text(GTK_ENTRY(input5)));
input6=lookup_widget(button,"nutnum");
strcpy(u.num,gtk_entry_get_text(GTK_ENTRY(input6)));
input7=lookup_widget(button,"nutlogin");
strcpy(u.login,gtk_entry_get_text(GTK_ENTRY(input7)));
input8=lookup_widget(button,"nutpasse");
strcpy(u.mot,gtk_entry_get_text(GTK_ENTRY(input8)));
input9=lookup_widget(button,"nutsp");
strcpy(u.sp,gtk_entry_get_text(GTK_ENTRY(input9)));

jour=lookup_widget(button,"spinbuttonjnut");
mois=lookup_widget(button,"spinbuttonmnut");
annee=lookup_widget(button,"spinbuttonannut");
u.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
u.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
u.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

ajouternut(u);
}


void
on_afficher_nut__clicked               (GtkWidget      *button,
                                        gpointer         user_data)
{
ajoutnut=lookup_widget(button,"ajoutnut");
gtk_widget_destroy(ajoutnut);
infonut=lookup_widget(button,"infonut");
infonut=create_infonut();

gtk_widget_show(infonut);
      

treeviewnut=lookup_widget(infonut,"treeviewnut");

afficherlistecomptenut(treeviewnut);
}
void
on_cherchernutee_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{
nut y;
int test;

nutaman=create_nutaman();
gtk_widget_show(nutaman);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"infonut")));
char m[30];
GtkWidget *input;
GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;
GtkWidget *output6;
GtkWidget *output7;
GtkWidget *output8;
GtkWidget *output9;
GtkWidget *output;

input=lookup_widget(button,"cherchernut");
strcpy(m,gtk_entry_get_text(GTK_ENTRY(input)));

output1=lookup_widget(nutaman,"cinnut");
output2=lookup_widget(nutaman,"nomnut");
output3=lookup_widget(nutaman,"prenomnut");
output4=lookup_widget(nutaman,"adressenut");
output5=lookup_widget(nutaman,"mailnut");
output6=lookup_widget(nutaman,"numnut");
output7=lookup_widget(nutaman,"loginnut");
output8=lookup_widget(nutaman,"passenut");
output9=lookup_widget(nutaman,"spnut");

output=lookup_widget(nutaman,"Inexistnatnut");

test=verif_nut(m);
if(test==1)
{
  y=chercher_nut(m);
gtk_label_set_text(GTK_LABEL(output),"");
gtk_entry_set_text(GTK_ENTRY(output1),y.cin);
gtk_entry_set_text(GTK_ENTRY(output2),y.nom);
gtk_entry_set_text(GTK_ENTRY(output3),y.prenom);
gtk_entry_set_text(GTK_ENTRY(output4),y.adresse);
gtk_entry_set_text(GTK_ENTRY(output5),y.mail);
gtk_entry_set_text(GTK_ENTRY(output6),y.num);
gtk_entry_set_text(GTK_ENTRY(output7),y.login);
gtk_entry_set_text(GTK_ENTRY(output8),y.mot);
gtk_entry_set_text(GTK_ENTRY(output9),y.sp);
}

if (test!=1)
	{
		gtk_label_set_text(GTK_LABEL(output),"identifiant inexistant ");
		
	}
}




//void
//on_cherchernut_clicked                 (GtkWidget       *button,
                                        //gpointer         user_data)
//{

//}


void
on_retournut_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
nutaman=lookup_widget(button,"nutaman");
gtk_widget_destroy(nutaman);
infonut=lookup_widget(button,"infonut");
infonut=create_infonut();

gtk_widget_show(infonut);
      

treeviewnut=lookup_widget(infonut,"treeviewnut");

afficherlistecomptenut(treeviewnut);
}


void
on_supprimernut_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
nut y;

char m[30];
GtkWidget *input;


input=lookup_widget(infonut,"cherchernut");
strcpy(m,gtk_entry_get_text(GTK_ENTRY(input)));
supprimer_nut(m);


nutaman=lookup_widget(button,"nutaman");
gtk_widget_destroy(nutaman);
infonut=lookup_widget(button,"infonut");
infonut=create_infonut();

gtk_widget_show(infonut);
      

treeviewnut=lookup_widget(infonut,"treeviewnut");

afficherlistecomptenut(treeviewnut);
}


void
on_modifiernut_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{
nut y;
char s[20];

GtkWidget *input;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;
GtkWidget *output6;
GtkWidget *output9;

input=lookup_widget(infonut,"cherchernut");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(input)));

output2=lookup_widget(nutaman,"nomnut");
strcpy(y.nom,gtk_entry_get_text(GTK_ENTRY(output2)));

output3=lookup_widget(nutaman,"prenomnut");
strcpy(y.prenom,gtk_entry_get_text(GTK_ENTRY(output3)));

output4=lookup_widget(nutaman,"adressenut");
strcpy(y.adresse,gtk_entry_get_text(GTK_ENTRY(output4)));

output5=lookup_widget(nutaman,"mailnut");
strcpy(y.mail,gtk_entry_get_text(GTK_ENTRY(output5)));

output6=lookup_widget(nutaman,"numnut");
strcpy(y.num,gtk_entry_get_text(GTK_ENTRY(output6)));

output9=lookup_widget(nutaman,"spnut");
strcpy(y.sp,gtk_entry_get_text(GTK_ENTRY(output9)));
{
FILE*fn;
FILE*fsupn;
char cin[20],nom[20],prenom[20],adresse[20],mail[20],num[20],login[20],mot[20],sp[20];
int jour,mois,annee;
fsupn=fopen("nutriisup.txt","a+");
fn=fopen("nutrii.txt","r");

while (fscanf(fn,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",cin,nom,prenom,&jour,&mois,&annee,adresse,mail,num,login,mot,sp) !=EOF)
  {
if(strcmp(s,cin)!=0)
	{
 fprintf(fsupn,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s\n",cin,nom,prenom,jour,mois,annee,adresse,mail,num,login,mot,sp); 
	}     
else 
	{
fprintf(fsupn,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s\n",cin,y.nom,y.prenom,jour,mois,annee,y.adresse,y.mail,y.num,login,mot,y.sp);
	}
   }
fclose(fn);
fclose(fsupn);
remove("nutrii.txt");
rename("nutriisup.txt","nutrii.txt");
}
infonut=create_infonut();
gtk_widget_show(infonut);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"nutaman"))); 
treeviewnut=lookup_widget(infonut,"treeviewnut");
afficherlistecomptenut(treeviewnut);
}





























//compte coach//
void
on_Ccoch_clicked                       (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{

Gestioncomptecoach=create_Gestioncomptecoach();
gtk_widget_show(Gestioncomptecoach);
gtk_widget_hide(GTK_WIDGET(lookup_widget(objet_graphique,"compte")));
      

treeviewcomptecoach=lookup_widget(Gestioncomptecoach,"treeviewcomptecoach");

afficherlistecoach(treeviewcomptecoach);
}

//ajouter coach //

void
on_ajoutercoach_clicked                (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
coach c;

GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget *input6;
GtkWidget *input7;
GtkWidget *input8;
GtkWidget *input9;
GtkWidget *input11;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;

input1=lookup_widget(objet_graphique,"cincoach");

input2=lookup_widget(objet_graphique,"nomcoach");

input3=lookup_widget(objet_graphique,"prenomcoach");

input4=lookup_widget(objet_graphique,"adressecoach");

input5=lookup_widget(objet_graphique,"emailcoach");

input6=lookup_widget(objet_graphique,"ntelcoach");

input7=lookup_widget(objet_graphique,"logincoach");

input8=lookup_widget(objet_graphique,"passecoach");

input9=lookup_widget(objet_graphique,"spcoach");


jour=lookup_widget(objet_graphique,"spinbuttonjcoach");
mois=lookup_widget(objet_graphique,"spinbuttonmcoach");
annee=lookup_widget(objet_graphique,"spinbuttonancoach");


input11=lookup_widget(objet_graphique,"labelverife");
strcpy(c.cin,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(c.adresse,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(c.mail,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(c.num,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(c.login,gtk_entry_get_text(GTK_ENTRY(input7)));
strcpy(c.mot,gtk_entry_get_text(GTK_ENTRY(input8)));
strcpy(c.sp,gtk_entry_get_text(GTK_ENTRY(input9)));
c.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
c.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
c.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));



  ajoutercoach(c);  




}


void
on_affichelalistedescoach_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

editeprofildescoach=lookup_widget(objet_graphique,"editeprofildescoach");
gtk_widget_destroy(editeprofildescoach);
Gestioncomptecoach=lookup_widget(objet_graphique,"Gestioncomptecoach");
Gestioncomptecoach=create_Gestioncomptecoach();

gtk_widget_show(Gestioncomptecoach);
      

treeviewcomptecoach=lookup_widget(Gestioncomptecoach,"treeviewcomptecoach");

afficherlistecoach(treeviewcomptecoach); 
}


void
on_retourlistedescoach_clicked         (GtkWidget       *button,
                                        gpointer         user_data)
{
editeprofildescoach=lookup_widget(button,"editeprofildescoach");
gtk_widget_destroy(editeprofildescoach);
Gestioncomptecoach=lookup_widget(button,"Gestioncomptecoach");
Gestioncomptecoach=create_Gestioncomptecoach();

gtk_widget_show(Gestioncomptecoach);
      

treeviewcomptecoach=lookup_widget(Gestioncomptecoach,"treeviewcomptecoach");

afficherlistecoach(treeviewcomptecoach); 
}
//modifier coach //

void
on_Modifierlecoachexistant_clicked     (GtkWidget       *button,
                                        gpointer         user_data)
{
coach e;
char s[20];

GtkWidget *input;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;
GtkWidget *output6;
GtkWidget *output9;
input=lookup_widget(Gestioncomptecoach,"entryrecherchecoach");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(input)));


output2=lookup_widget(coachrechercher,"cherchernomcoach");
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(output2)));

output3=lookup_widget(coachrechercher,"chercherprenomcoach");
strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(output3)));

output4=lookup_widget(coachrechercher,"chercheradressecoach");
strcpy(e.adresse,gtk_entry_get_text(GTK_ENTRY(output4)));

output5=lookup_widget(coachrechercher,"cherchermailcoach");
strcpy(e.mail,gtk_entry_get_text(GTK_ENTRY(output5)));

output6=lookup_widget(coachrechercher,"cherchernum");
strcpy(e.num,gtk_entry_get_text(GTK_ENTRY(output6)));

output9=lookup_widget(coachrechercher,"cherchersp");
strcpy(e.sp,gtk_entry_get_text(GTK_ENTRY(output9)));
{
FILE*f;
FILE*fsup;
char cin[20],nom[20],prenom[20],adresse[20],mail[20],num[20],login[20],mot[20],sp[20];
int jour,mois,annee;
fsup=fopen("coachesup.txt","a+");
f=fopen("coachee.txt","r");
while (fscanf(f,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",cin,nom,prenom,&jour,&mois,&annee,adresse,mail,num,login,mot,sp) !=EOF)
{
if(strcmp(s,cin)!=0)
{
 fprintf(fsup,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s\n",cin,nom,prenom,jour,mois,annee,adresse,mail,num,login,mot,sp); 
}     
else 
{
fprintf(fsup,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s\n",cin,e.nom,e.prenom,jour,mois,annee,e.adresse,e.mail,e.num,login,mot,e.sp);
}
}
fclose(f);
fclose(fsup);
remove("coachee.txt");
rename("coachesup.txt","coachee.txt");
}
Gestioncomptecoach=create_Gestioncomptecoach();
gtk_widget_show(Gestioncomptecoach);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"coachrechercher")));
treeviewcomptecoach=lookup_widget(Gestioncomptecoach,"treeviewcomptecoach");
afficherlistecoach(treeviewcomptecoach); 

}

//supprimer coach //
void
on_Supprimerlecoachexistant__clicked   (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
coach e;


char s[30];
GtkWidget *input;


input=lookup_widget(Gestioncomptecoach,"entryrecherchecoach");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(input)));
supprimer_coach(s);



//Gestioncomptecoach=lookup_widget(objet_graphique,"Gestioncomptecoach");
//gtk_widget_destroy(Gestioncomptecoach);
//coachrechercher=lookup_widget(objet_graphique,"coachrechercher");
//coachrechercher=create_coachrechercher();

//gtk_widget_show(coachrechercher);
Gestioncomptecoach=create_Gestioncomptecoach();
gtk_widget_show(Gestioncomptecoach);
gtk_widget_hide(GTK_WIDGET(lookup_widget(objet_graphique,"coachrechercher")));      

treeviewcomptecoach=lookup_widget(Gestioncomptecoach,"treeviewcomptecoach");

afficherlistecoach(treeviewcomptecoach);

}
//afficher coach//
void
on_affichecoachchercher_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

coach e ;
int test;
char msg[50] ;
coachrechercher=create_coachrechercher();
gtk_widget_show(coachrechercher);
gtk_widget_hide(GTK_WIDGET(lookup_widget(objet_graphique,"Gestioncomptecoach")));
char s[30];
GtkWidget *inputrecherche;
GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;
GtkWidget *output6;
GtkWidget *output7;
GtkWidget *output8;
GtkWidget *output9;
GtkWidget *output;

inputrecherche=lookup_widget(objet_graphique,"entryrecherchecoach");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(inputrecherche)));

output1=lookup_widget(coachrechercher,"cherchercincoach");
output2=lookup_widget(coachrechercher,"cherchernomcoach");
output3=lookup_widget(coachrechercher,"chercherprenomcoach");
output4=lookup_widget(coachrechercher,"chercheradressecoach");
output5=lookup_widget(coachrechercher,"cherchermailcoach");
output6=lookup_widget(coachrechercher,"cherchernum");
output7=lookup_widget(coachrechercher,"chercherlogin");
output8=lookup_widget(coachrechercher,"chercherpasse");
output9=lookup_widget(coachrechercher,"cherchersp");

output=lookup_widget(coachrechercher,"Inexistant");

test=verif_coach(s);
if(test==1)
{
  e=chercher_coach(s);
gtk_label_set_text(GTK_LABEL(output),"");
gtk_entry_set_text(GTK_ENTRY(output1),e.cin);
gtk_entry_set_text(GTK_ENTRY(output2),e.nom);
gtk_entry_set_text(GTK_ENTRY(output3),e.prenom);
gtk_entry_set_text(GTK_ENTRY(output4),e.adresse);
gtk_entry_set_text(GTK_ENTRY(output5),e.mail);
gtk_entry_set_text(GTK_ENTRY(output6),e.num);
gtk_entry_set_text(GTK_ENTRY(output7),e.login);
gtk_entry_set_text(GTK_ENTRY(output8),e.mot);
gtk_entry_set_text(GTK_ENTRY(output9),e.sp);
}

if (test!=1)
	{
		gtk_label_set_text(GTK_LABEL(output),"identifiant inexistant ");
		
	}
}


void
on_retourlisteGestion_clicked          (GtkWidget       *button,
                                        gpointer         user_data)
{
coachrechercher=lookup_widget(button,"coachrechercher");
gtk_widget_destroy(coachrechercher);
Gestioncomptecoach=lookup_widget(button,"Gestioncomptecoach");
Gestioncomptecoach=create_Gestioncomptecoach();

gtk_widget_show(Gestioncomptecoach);
      

treeviewcomptecoach=lookup_widget(Gestioncomptecoach,"treeviewcomptecoach");

afficherlistecoach(treeviewcomptecoach); 

}



//compte dieteticien 

void
on_Cdiet_clicked                       (GtkWidget     *button,
                                        gpointer         user_data)
{
comptediet=create_comptediet();
gtk_widget_show(comptediet);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"compte")));
      

treeviewcdiet=lookup_widget(comptediet,"treeviewcdiet");

afficherlistecomptediet(treeviewcdiet);

}
        //afficher les info tree
void
on_afficherdiet_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
diet z;
int test;

dietchercher=create_dietchercher();
gtk_widget_show(dietchercher);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"comptediet")));
char s[30];
GtkWidget *input;
GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;
GtkWidget *output6;
GtkWidget *output7;
GtkWidget *output8;
GtkWidget *output9;
GtkWidget *output;

input=lookup_widget(button,"rechercherdiet");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(input)));

output1=lookup_widget(dietchercher,"dcin");
output2=lookup_widget(dietchercher,"ndnom");
output3=lookup_widget(dietchercher,"dprenom");
output4=lookup_widget(dietchercher,"dadresse");
output5=lookup_widget(dietchercher,"dmail");
output6=lookup_widget(dietchercher,"dnum");
output7=lookup_widget(dietchercher,"dlogin");
output8=lookup_widget(dietchercher,"dpasse");
output9=lookup_widget(dietchercher,"dsp");

output=lookup_widget(comptediet,"Inexistantdiet");

test=verif_diet(s);
if(test==1)
{
  z=chercher_diet(s);
gtk_label_set_text(GTK_LABEL(output),"");
gtk_entry_set_text(GTK_ENTRY(output1),z.cin);
gtk_entry_set_text(GTK_ENTRY(output2),z.nom);
gtk_entry_set_text(GTK_ENTRY(output3),z.prenom);
gtk_entry_set_text(GTK_ENTRY(output4),z.adresse);
gtk_entry_set_text(GTK_ENTRY(output5),z.mail);
gtk_entry_set_text(GTK_ENTRY(output6),z.num);
gtk_entry_set_text(GTK_ENTRY(output7),z.login);
gtk_entry_set_text(GTK_ENTRY(output8),z.mot);
gtk_entry_set_text(GTK_ENTRY(output9),z.sp);
}

if (test!=1)
        {
                gtk_label_set_text(GTK_LABEL(output),"identifiant inexistant ");

        }
}





///ajouter un diet 
void
on_ajouterunnvdiet_clicked             (GtkWidget       *button,
                                        gpointer         user_data)
{
infodiet=create_infodiet();
gtk_widget_show(infodiet);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"comptediet")));
}

//enregistrer un diet
void
on_ajouterlediet_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{
diet i;
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget *input6;
GtkWidget *input7;
GtkWidget *input8;
GtkWidget *input9;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;

input1=lookup_widget(infodiet,"cindiet");
strcpy(i.cin,gtk_entry_get_text(GTK_ENTRY(input1)));
input2=lookup_widget(infodiet,"nomdiet");
strcpy(i.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
input3=lookup_widget(infodiet,"prenomdiet");
strcpy(i.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
input4=lookup_widget(infodiet,"adressediet");
strcpy(i.adresse,gtk_entry_get_text(GTK_ENTRY(input4)));
input5=lookup_widget(infodiet,"maildiet");
strcpy(i.mail,gtk_entry_get_text(GTK_ENTRY(input5)));
input6=lookup_widget(infodiet,"numdiet");
strcpy(i.num,gtk_entry_get_text(GTK_ENTRY(input6)));
input7=lookup_widget(infodiet,"logindiet");
strcpy(i.login,gtk_entry_get_text(GTK_ENTRY(input7)));
input8=lookup_widget(infodiet,"pasdiet");
strcpy(i.mot,gtk_entry_get_text(GTK_ENTRY(input8)));
input9=lookup_widget(infodiet,"spdiet");
strcpy(i.sp,gtk_entry_get_text(GTK_ENTRY(input9)));

jour=lookup_widget(infodiet,"spinbuttonjdiet");
mois=lookup_widget(infodiet,"spinbuttonmdiet");
annee=lookup_widget(infodiet,"spinbuttonandiet");
i.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
i.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
i.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

ajouterdiet(i);
}

//afficher diet 
void
on_afficherlediet_clicked              (GtkWidget      *button,
                                        gpointer         user_data)
{

infodiet=lookup_widget(button,"infodiet");
gtk_widget_destroy(infodiet);
comptekine=lookup_widget(button,"comptediet");
comptediet=create_comptediet();

gtk_widget_show(comptediet);


treeviewcdiet=lookup_widget(comptediet,"treeviewcdiet");

afficherlistecomptediet(treeviewcdiet); 


}

//modifier diet 
void
on_modifierdiet_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
diet z;
char s[20];

GtkWidget *input;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;
GtkWidget *output6;
GtkWidget *output9;
input=lookup_widget(comptediet,"rechercherdiet");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(input)));


output2=lookup_widget(dietchercher,"dnom");
strcpy(z.nom,gtk_entry_get_text(GTK_ENTRY(output2)));

output3=lookup_widget(dietchercher,"dprenom");
strcpy(z.prenom,gtk_entry_get_text(GTK_ENTRY(output3)));

output4=lookup_widget(dietchercher,"dadresse");
strcpy(z.adresse,gtk_entry_get_text(GTK_ENTRY(output4)));

output5=lookup_widget(dietchercher,"dmail");
strcpy(z.mail,gtk_entry_get_text(GTK_ENTRY(output5)));

output6=lookup_widget(dietchercher,"dnum");
strcpy(z.num,gtk_entry_get_text(GTK_ENTRY(output6)));

output9=lookup_widget(dietchercher,"dsp");
strcpy(z.sp,gtk_entry_get_text(GTK_ENTRY(output9)));
 {
FILE*fd;
FILE*fsupd;
char cin[20],nom[20],prenom[20],adresse[20],mail[20],num[20],login[20],mot[20],sp[20];
int jour,mois,annee;
fsupd=fopen("dietesup.txt","a+");
fd=fopen("dietee.txt","r");
while (fscanf(fd,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",cin,nom,prenom,&jour,&mois,&annee,adresse,mail,num,login,mot,sp) !=EOF)
	{
if(strcmp(s,cin)!=0)
   {
 fprintf(fsupd,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s\n",cin,nom,prenom,jour,mois,annee,adresse,mail,num,login,mot,sp); 
   }     
else 
  	{
fprintf(fsupd,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s\n",cin,z.nom,z.prenom,jour,mois,annee,z.adresse,z.mail,z.num,login,mot,z.sp);
        }
}
fclose(fd);
fclose(fsupd);
remove("dietesup.txt");
rename("dietesup.txt","dietee.txt");
}
comptediet=create_comptediet();
gtk_widget_show(comptediet);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"dietchercher")));   

treeviewcdiet=lookup_widget(comptediet,"treeviewcdiet");

afficherlistecomptediet(treeviewcdiet); 
}

//supprimer diet 


void
on_supprimerdiet_clicked               (GtkWidget        *button,
                                        gpointer         user_data)
{
diet z;


char s[30];
GtkWidget *input;
input=lookup_widget(comptediet,"rechercherdiet");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(input)));


supprimer_diet(s);




comptediet=create_comptediet();
gtk_widget_show(comptediet);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"dietchercher")));   

treeviewcdiet=lookup_widget(comptediet,"treeviewcdiet");

afficherlistecomptediet(treeviewcdiet); 


}

//retour diet 
void
on_retourdietliste_clicked             (GtkWidget      *button,
                                        gpointer         user_data)
{
comptediet=create_comptediet();
gtk_widget_show(comptediet);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"dietchercher")));
treeviewcdiet=lookup_widget(comptediet,"treeviewcdiet");

afficherlistecomptediet(treeviewcdiet); 
}

void
on_retourdudietauplan_clicked          (GtkWidget      *button,
                                        gpointer         user_data)
{
compte=create_compte();
gtk_widget_show(compte);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"comptediet")));
}

void
on_Cnet_clicked                        (GtkWidget      *button,
                                        gpointer         user_data)
{

}


void
on_Retourcompte_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
compte=create_compte();
gtk_widget_show(compte);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"trei")));
}


void
on_Ajadh_clicked                       (GtkWidget       *button,
                                        gpointer         user_data)
{
info=create_info();
gtk_widget_show(info);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"trei")));
}

void
on_reretourmenu_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
menu=create_menu();
gtk_widget_show(menu);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"compte")));
}


void
on_retourlista_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
info=lookup_widget(objet_graphique,"info");
gtk_widget_destroy(info);
trei=lookup_widget(objet_graphique,"trei");
trei=create_trei();

gtk_widget_show(trei);
      

treeview1=lookup_widget(trei,"treeview1");

afficherpersonne(treeview1); 
}


void
on_ajouinfo_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
Personne p;

GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;


input1=lookup_widget(objet_graphique,"entry1110");
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
input2=lookup_widget(objet_graphique,"entry1120");
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
input3=lookup_widget(objet_graphique,"entry1130");
strcpy(p.login,gtk_entry_get_text(GTK_ENTRY(input3)));
input4=lookup_widget(objet_graphique,"entry1140");
strcpy(p.mot,gtk_entry_get_text(GTK_ENTRY(input4)));
input5=lookup_widget(objet_graphique,"entry1150");
strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(input4)));

jour=lookup_widget(objet_graphique,"spinbutton1110");
mois=lookup_widget(objet_graphique,"spinbutton1120");
annee=lookup_widget(objet_graphique,"spinbutton1130");
p.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
p.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
p.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));

ajouterpersonne(p);
}





void
on_Ediet_clicked                       (GtkWidget      *button,
                                        gpointer         user_data)
{

}


void
on_Eagent_clicked                      (GtkWidget        *button,
                                        gpointer         user_data)
{

}


void
on_Enut_clicked                        (GtkWidget        *button,
                                        gpointer         user_data)
{

}


void
on_Ekine_clicked                       (GtkWidget        *button,
                                        gpointer         user_data)
{

}


void
on_Ecoch_clicked                       (GtkWidget        *button,
                                        gpointer         user_data)
{

}


void
on_ajoutplan_clicked                   (GtkWidget        *button,
                                        gpointer         user_data)
{

}


void
on_enregistrerplan_clicked             (GtkWidget        *objet_graphique,
                                        gpointer         user_data)
{

}


void
on_retourplan_clicked                  (GtkWidget        *button,
                                        gpointer         user_data)
{

}


void
on_affichelundi_clicked                (GtkWidget        *button,
                                        gpointer         user_data)
{

}


void
on_affichemardi_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_affichemercredi_clicked             (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_affichejeudi_clicked                (GtkWidget        *button,
                                        gpointer         user_data)
{

}


void
on_affichevendredi_clicked             (GtkWidget        *button,
                                        gpointer         user_data)
{

}


void
on_affichesamedi_clicked               (GtkWidget        *button,
                                        gpointer         user_data)
{

}


void
on_ajoutcal_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_Retourplaningtravail_clicked        (GtkWidget        *button,
                                        gpointer         user_data)
{

}


//liste des coachs //

void
on_plancoche_clicked                   (GtkWidget        *button,
                                        gpointer         user_data)
{
lesplane=lookup_widget(button,"lesplane");
gtk_widget_destroy(lesplane);
listedesplanningdescoach=lookup_widget(button,"listedesplanningdescoach");
listedesplanningdescoach=create_listedesplanningdescoach();

gtk_widget_show(listedesplanningdescoach);
      

treeviewcoachp=lookup_widget(listedesplanningdescoach,"treeviewcoachp");

afficherlistePcoach(treeviewcoachp);
}

void
on_retourduplaningauplane_clicked      (GtkWidget       *button,
                                        gpointer         user_data)
{
lesplane=create_lesplane();
gtk_widget_show(lesplane);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"listedesplanningdescoach")));
}
//retour plane //
void
on_Retourplans_clicked                 (GtkWidget        *button,
                                        gpointer         user_data)
{
menu=create_menu();
gtk_widget_show(menu);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"lesplane")));
}



//planing diet//
void
on_plandiete_clicked                   (GtkWidget        *button,
                                        gpointer         user_data)
{
lesplane=lookup_widget(button,"lesplane");
gtk_widget_destroy(lesplane);
listeplaningdiet=lookup_widget(button,"listeplaningdiet");
listeplaningdiet=create_listeplaningdiet();

gtk_widget_show(listeplaningdiet);
      

treeviewplaningdiet=lookup_widget(listeplaningdiet,"treeviewplaningdiet");

afficherlistediet(treeviewplaningdiet);
}

void
on_retourplaningdietauplane_clicked    (GtkWidget       *button,
                                        gpointer         user_data)
{
lesplane=create_lesplane();
gtk_widget_show(lesplane);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"listeplaningdiet")));
}


//planing kine // 
void
on_plankine_clicked                    (GtkWidget        *button,
                                        gpointer         user_data)
{

lesplane=lookup_widget(button,"lesplane");
gtk_widget_destroy(lesplane);
listeplaningkine=lookup_widget(button,"listeplaningkine");
listeplaningkine=create_listeplaningkine();

gtk_widget_show(listeplaningkine);
      

treeviewpkine=lookup_widget(listeplaningkine,"treeviewpkine");

afficherlistekine(treeviewpkine);
}
void
on_retourdeplaningkineauplane_clicked  (GtkWidget        *button,
                                        gpointer         user_data)
{
lesplane=create_lesplane();
gtk_widget_show(lesplane);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"listeplaningkine")));
}

//planing nutri//
void
on_planenutr_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
lesplane=lookup_widget(button,"lesplane");
gtk_widget_destroy(lesplane);
listeplaningnut=lookup_widget(button,"listeplaningnut");
listeplaningnut=create_listeplaningnut();

gtk_widget_show(listeplaningnut);
      

treeviewpnut=lookup_widget(listeplaningnut,"treeviewpnut");

afficherlistenut(treeviewpnut);

}

void
on_retourduplaningkineauplane_clicked  (GtkWidget       *button,
                                        gpointer         user_data)
{
lesplane=create_lesplane();
gtk_widget_show(lesplane);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"listeplaningnut")));
}
//planing agent/
void
on_planeage_clicked                    (GtkWidget      *button,
                                        gpointer         user_data)
{
lesplane=lookup_widget(button,"lesplane");
gtk_widget_destroy(lesplane);
listeplaningagent=lookup_widget(button,"listeplaningagent");
listeplaningagent=create_listeplaningagent();

gtk_widget_show(listeplaningagent);
      

treeviewpagent=lookup_widget(listeplaningagent,"treeviewpagent");

afficherlisteagent(treeviewpagent);
}
void
on_retourplaningagentauplane_clicked   (GtkWidget       *button,
                                        gpointer         user_data)
{
lesplane=create_lesplane();
gtk_widget_show(lesplane);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"listeplaningagent")));
}



void
on_retourlesplane_clicked              (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_retourout_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_afficheout_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_enregitrementduplaning_clicked      (GtkWidget       *button,      gpointer         user_data)
{

}


void
on_retouuuuuuuuuuuuuuurr_clicked       (GtkWidget       *button,
                                        gpointer         user_data)
{
}


void
on_afficheduplaningdetravail_clicked   (GtkWidget      *button,
                                        gpointer         user_data)
{
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}








void
on_connexion_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
int test=-1;
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *output1;

GtkWidget *espacemed;
GtkWidget *espaceadh;
GtkWidget *espaceagent;
GtkWidget *espacecoach;
GtkWidget *espacekine;
GtkWidget *espacediet;
GtkWidget *espaceadmin;

espaceadmin=create_espaceadmin() ;
espacemed=create_espacemed() ;
espaceadh=create_espaceadh() ;
espaceagent=create_espaceagent() ;

espacecoach=create_espacecoach() ;
espacekine=create_espacekine() ;
espacediet=create_espacediet() ;


char username[30] ; char password[30]   ;
int occurence=0 ;
char msgerror[100]=" wrong username or password";
input1=lookup_widget(button,"loginaut");
input2=lookup_widget(button,"passeauth");
output1=lookup_widget(button,"oups");
strcpy(username,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(password,gtk_entry_get_text(GTK_ENTRY(input2)));

test=verification(username,password);

if (test==0)
{
gtk_widget_show(espaceadmin);
} 
if (test==1)
{
gtk_widget_show(espacemed);
} 
if (test==2)
{
 gtk_widget_show(espaceadh);
}
if (test==3) 
{
 gtk_widget_show(espaceagent);
}

if (test==4) 
{
 gtk_widget_show(espacecoach);
}

if (test==5) 
{
 gtk_widget_show(espacekine);
}

if (test==6) 
{
 gtk_widget_show(espacediet);
}
else if (test==-1) { 

gtk_label_set_text(GTK_LABEL(output1),msgerror); }

}



void
on_deconnexion_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_supp_clicked                        (GtkWidget       *button,
                                        gpointer         user_data)
{ 

}


void
on_modifier_clicked                    (GtkWidget    *button,
                                        gpointer         user_data)
{

}





void
on_ajoutcoach_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
editeprofildescoach=create_editeprofildescoach();
gtk_widget_show(editeprofildescoach);
gtk_widget_hide(GTK_WIDGET(lookup_widget(objet_graphique,"Gestioncomptecoach")));
}


void
on_retourGestioncompteaparirdelalistedescoach_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget  *Gestioncomptecoach;
GtkWidget  *compte;
compte=create_compte();
gtk_widget_show(compte);
gtk_widget_hide(GTK_WIDGET(lookup_widget(objet_graphique,"Gestioncomptecoach")));
}









void
on_retourdelalistekineaucompte__clicked
                                        (GtkWidget        *button,
                                        gpointer         user_data)
{
menu=create_menu();
gtk_widget_show(menu);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"comptekine")));
}
















































