#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif




#include <stdio.h>
#include <string.h>
#include "coach.h"
#include "diet.h"
#include "kine.h"
#include "nut.h"
#include "me.h"
#include <gtk/gtk.h>

void ajoutercoach(coach c)
{

FILE *f; 
f=fopen("coachee.txt","a+");
fprintf(f,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",c.cin,c.nom,c.prenom,c.jour,c.mois,c.annee,c.adresse,c.mail,c.num,c.login,c.mot,c.sp);
fclose(f);
}

	 

/***************************/

int verif_coach(char x[])
{
coach e ;

FILE *f ;

f=fopen("coachee.txt","r");
if (f!=NULL)
  {
	while (fscanf(f,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",e.cin,e.nom,e.prenom,&e.jour,&e.mois,&e.annee,e.adresse,e.mail,e.num,e.login,e.mot,e.sp) !=EOF)
 {       if (strcmp(e.cin,x)==0)
	{ 	
		return 1;
	}

  }
return 0 ;
fclose(f);
 }

}




/***********************/


coach chercher_coach(char x[])
{
coach e;
FILE *f ;

f=fopen("coachee.txt","r");
if (f!=NULL)
  {
	while (fscanf(f,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",e.cin,e.nom,e.prenom,&e.jour,&e.mois,&e.annee,e.adresse,e.mail,e.num,e.login,e.mot,e.sp) !=EOF)
 {       if (strcmp(e.cin,x)==0)
	{ 
	 return e;
	}

  }
fclose(f);
   
  }

}

/**********************************/
void supprimer_coach(char id[])
{
coach e;
FILE *f; 
FILE *fsup; 


f=fopen("coachee.txt","r");
fsup=fopen("coachesup.txt","a+");
if (f!=NULL)
{
while (fscanf(f,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",e.cin,e.nom,e.prenom,&e.jour,&e.mois,&e.annee,e.adresse,e.mail,e.num,e.login,e.mot,e.sp) !=EOF)
{
	if (strcmp(id,e.cin) !=0)
     { fprintf(fsup,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",e.cin,e.nom,e.prenom,e.jour,e.mois,e.annee,e.adresse,e.mail,e.num,e.login,e.mot,e.sp);
     }
}

fclose(f);
fclose(fsup);
}
remove("coachee.txt");
rename("coachesup.txt","coachee.txt");
}
/******************************************/



int verification( char username[], char password[])
{ 
 char username1[30] ; char password1[30];

 int o=0 ;

Personne p;
FILE*f1;
f1=fopen("utilisateur.txt","r");
while (fscanf(f1,"%s %s %s %s %s %d %d %d \n",p.nom,p.prenom,p.login,p.mot,p.cin,&p.jour,&p.annee,&p.mois)!=EOF)
{
 if ((strcmp(p.cin,username)==0)&&(strcmp(p.mot,password)==0))

	{ 	
		return 2;
	}

}

fclose(f1);


coach e;
FILE *f; 
f1=fopen("coachee.txt","r");

while (fscanf(f,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",e.cin,e.nom,e.prenom,&e.jour,&e.mois,&e.annee,e.adresse,e.mail,e.num,e.login,e.mot,e.sp) !=EOF)
 {       if ((strcmp(e.cin,username)==0)&&(strcmp(e.mot,password)==0))
	{ 	
		return 4;
	}

}
fclose(f);


kine t;

FILE *fkc ;

fkc=fopen("kinee.txt","r");

  
	while (fscanf(fkc,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s \n",t.cin,t.nom,t.prenom,&t.jour,&t.mois,&t.annee,t.adresse,t.mail,t.num,t.login,t.mot,t.sp) !=EOF)
 {       if ((strcmp(t.cin,username)==0)&&(strcmp(t.mot,password)==0))
	{ 	
		return 5;
	}

  }

fclose(fkc);




diet z;
FILE *fd ;

fd=fopen("dietee.txt","r");

  	while (fscanf(fd,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s\n",z.cin,z.nom,z.prenom,&z.jour,&z.mois,&z.annee,z.adresse,z.mail,z.num,z.login,z.mot,z.sp) !=EOF)
 {       if ((strcmp(z.cin,username)==0)&&(strcmp(z.mot,password)==0))
	{ 
	 return 6;
	}

  
}
fclose(fd);

nut y;
FILE *fn ;

fn=fopen("nutrii.txt","r");

  
	while (fscanf(fn,"%s %s %s %d/%d/%d  %s %s %s %s %s  %s\n",y.cin,y.nom,y.prenom,&y.jour,&y.mois,&y.annee,y.adresse,y.mail,y.num,y.login,y.mot,y.sp) !=EOF)
 {       if ((strcmp(y.cin,username)==0)&&(strcmp(y.mot,password)==0))
	{ 
	 return 1;
	}

 }
fclose(fn);


	if((strcmp("khalil",username)==0)&&(strcmp("0000",password)==0))
 {return 0; }
         if((strcmp("mariem",username)==0)&&(strcmp("0000",password)==0))
{return 0; }

}


int controlesaisie_coach(char x[15])
{
int b=0 ; int a=0;
//a=digital(x);
if (a==0)
{return 0;}
else { b=atoi(x);}
if ((b>99999999)&&(b<99999999))
{return 1;}
else {return 0;}

}

















