#include <gtk/gtk.h>


void afficherreclamcoach(GtkWidget *liste);
