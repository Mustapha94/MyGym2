#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <glib.h>
#include "fichemed.h"
#include "kine.h"
GtkWidget *espkine;
GtkWidget *modifprfilkine;
GtkWidget *fichemede;
GtkWidget *reclamationkine;
GtkWidget *reclamationrecu;
GtkWidget *reclamationenvoi;
GtkWidget *gestseancecure;
GtkWidget *gestrdvkine;
GtkWidget *prfilkine;
GtkWidget *affichefichemed;

void
on_fichemed_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{

GtkWidget *treeview1;


fichemede=lookup_widget(button,"fichemede");
fichemede=create_fichemede();
gtk_widget_show(fichemede);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"espkine")));
treeview1=lookup_widget(fichemede,"treeviewfichemed");
afficher_fichemed(treeview1);

}


void
on_gestcure_clicked                    (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1;

gestseancecure=lookup_widget(button,"gestseancecure");
gestseancecure=create_gestseancecure();
gtk_widget_show(gestseancecure);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"espkine")));
treeview1=lookup_widget(gestseancecure,"treeviewadherent");
afficher_adherents(treeview1);

}

void
on_savekine_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
id A;

char chemin[]="listekine.txt";
GtkWidget *espkine;
espkine=create_espkine();
gtk_widget_show(espkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"modifprfilkine")));
GtkWidget *labelnom;
GtkWidget *labelprenom;
GtkWidget *labelCIN;
GtkWidget *labeljour;
GtkWidget *labelmois;
GtkWidget *labelannee;
GtkWidget *labeladress;
GtkWidget *labelnum;
GtkWidget *labelpass;
GtkWidget *labelrole;
int i=1;

labelnom=lookup_widget(button,"nomkine");
labelprenom=lookup_widget(button,"prenomkine");
labeljour=lookup_widget(button,"jourkine");
labelmois=lookup_widget(button,"moiskine");
labelannee=lookup_widget(button,"anneekine");
labeladress=lookup_widget(button,"adresskine");
labelnum=lookup_widget(button,"numkine");
labelCIN=lookup_widget(button,"CINkine");
labelpass=lookup_widget(button,"passkine");

strcpy(A.nom,gtk_label_get_text(GTK_LABEL(labelnom)));
strcpy(A.prenom,gtk_label_get_text(GTK_LABEL(labelprenom)));
strcpy(A.cin,gtk_label_get_text(GTK_LABEL(labelCIN)));
strcpy(A.jour,gtk_label_get_text(GTK_LABEL(labeljour)));
strcpy(A.mois,gtk_label_get_text(GTK_LABEL(labelmois)));
strcpy(A.annee,gtk_label_get_text(GTK_LABEL(labelannee)));
strcpy(A.adress,gtk_entry_get_text(GTK_ENTRY(labeladress)));
strcpy(A.num,gtk_entry_get_text(GTK_ENTRY(labelnum)));
strcpy(A.pass,gtk_entry_get_text(GTK_ENTRY(labelpass)));
FILE*f;
f=fopen(chemin,"a+");
fprintf(f,"%s %s %s %s %s %s %s %s %s 4 \n",A.cin,A.nom,A.prenom,A.jour,A.mois,A.annee,A.adress,A.num,A.pass);
fclose(f);
}


void
on_retrnespkine2_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *espkine;
espkine=create_espkine();
gtk_widget_show(espkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"fichemede")));
}


void
on_retrnkine3_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *espkine;
espkine=create_espkine();
gtk_widget_show(espkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationkine")));
}


void
on_reclmtionrecu_clicked               (GtkWidget     *button,
                                        gpointer         user_data)
{
GtkWidget *reclamationrecu;
reclamationrecu=create_reclamationrecu();
gtk_widget_show(reclamationrecu);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationkine")));
int i=1;
char chemin[]="reckine.txt";
GtkWidget *labelrecu;
char cont[300];
FILE*f;
f=fopen(chemin,"a+");
while(fscanf(f,"%s \n",cont)!=EOF)
{
i++;
}
labelrecu=lookup_widget(reclamationrecu,"labelcontenureclrecu");
gtk_label_set_text(GTK_LABEL(labelrecu),cont);
fclose(f);

}


void
on_reclmtionenvoi_clicked              (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *reclamationenvoi;
reclamationenvoi=create_reclamationenvoi();
gtk_widget_show(reclamationenvoi);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationkine")));
}


void
on_retrnrecl_clicked                   (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *reclamationkine;
reclamationkine=create_reclamationkine();
gtk_widget_show(reclamationkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationrecu")));
}


void
on_envoirecl_clicked                   (GtkWidget    *button,
                                        gpointer         user_data)
{
GtkWidget *inputreclama;
GtkWidget *inputdest;
char dest[40],cont[100];
inputreclama=lookup_widget(button,"comboboxentryrecl");
strcpy(dest,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputreclama)));
inputdest=lookup_widget(button,"entryreclenvoi");
strcpy(cont,gtk_entry_get_text(GTK_ENTRY(inputdest)));
if (strcmp(dest,"Agent de Nétoyage")==0)
{
FILE *f1;
f1=fopen("recagentnet.txt","a+");
fprintf(f1,"%s \n",cont);
fclose(f1);
}
else if (strcmp(dest,"Coach")==0)
{
FILE *f2;
f2=fopen("reccoach.txt","a+");
fprintf(f2,"%s \n",cont);
fclose(f2);
}
else if (strcmp(dest,"Kinésithérapeute")==0)
{
FILE *f3;
f3=fopen("reckine.txt","a+");
fprintf(f3,"%s \n",cont);
fclose(f3);
}
else if (strcmp(dest,"Diététicien")==0)
{
FILE *f4;
f4=fopen("recdiet.txt","a+");
fprintf(f4,"%s \n",cont);
fclose(f4);
}
else if (strcmp(dest,"Médecin Nutritioniste")==0)
{
FILE *f5;
f5=fopen("recdiet.txt","a+");
fprintf(f5,"%s \n",cont);
fclose(f5);
}
if (cont != " " && dest != " ")
{
GtkWidget *succreclenvoi;
succreclenvoi=create_succreclenvoi();
gtk_widget_show(succreclenvoi);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationenvoi")));
}
else
{
GtkWidget *failenvoirec;
failenvoirec=create_failenvoirec();
gtk_widget_show(failenvoirec);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationenvoi")));
}

}


void
on_retrnkine4_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *espkine;
espkine=create_espkine();
gtk_widget_show(espkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"gestseancecure")));
}


void
on_retrngestcure_clicked               (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
GtkWidget *gestseancecure;
gestseancecure=create_gestseancecure();
gtk_widget_show(gestseancecure);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"gestrdvkine")));
treeview1=lookup_widget(gestseancecure,"treeviewadherent");
afficher_adherents(treeview1);
}


void
on_retrnespkine5_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *espkine;
espkine=create_espkine();
gtk_widget_show(espkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"prfilkine")));
}


void
on_modifprfil_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
id A;
char chemin[]="listekine.txt";

GtkWidget *modifprfilkine;
modifprfilkine=create_modifprfilkine();
gtk_widget_show(modifprfilkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"prfilkine")));
int i=1;

FILE*f;
f=fopen(chemin,"a+");

while(fscanf(f,"%s %s %s %s %s %s %s %s %s %d\n",A.cin,A.nom,A.prenom,A.jour,A.mois,A.annee,A.adress,A.num,A.pass,&A.role)!=EOF)
{i++;
}
GtkWidget *labelnom;
GtkWidget *labelprenom;
GtkWidget *labelCIN;
GtkWidget *labeljour;
GtkWidget *labelmois;
GtkWidget *labelannee;
GtkWidget *labeladress;
GtkWidget *labelnum;
GtkWidget *labelpass;
GtkWidget *labelrole;

labelnom=lookup_widget(modifprfilkine,"nomkine");
labelprenom=lookup_widget(modifprfilkine,"prenomkine");
labeljour=lookup_widget(modifprfilkine,"jourkine");
labelmois=lookup_widget(modifprfilkine,"moiskine");
labelannee=lookup_widget(modifprfilkine,"anneekine");
labeladress=lookup_widget(modifprfilkine,"adresskine");
labelnum=lookup_widget(modifprfilkine,"numkine");
labelCIN=lookup_widget(modifprfilkine,"CINkine");
labelpass=lookup_widget(modifprfilkine,"passkine");

gtk_label_set_text(GTK_LABEL(labelnom),A.nom);
gtk_label_set_text(GTK_LABEL(labelprenom),A.prenom);
gtk_label_set_text(GTK_LABEL(labelCIN),A.cin);
gtk_label_set_text(GTK_LABEL(labeljour),A.jour);
gtk_label_set_text(GTK_LABEL(labelmois),A.mois);
gtk_label_set_text(GTK_LABEL(labelannee),A.annee);
gtk_entry_set_text(GTK_ENTRY(labeladress),A.adress);
gtk_entry_set_text(GTK_ENTRY(labelnum),A.num);
gtk_entry_set_text(GTK_ENTRY(labelpass),A.pass);

fclose(f);


}


void
on_horairetravailkine_clicked          (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *horairetravail;
horairetravail=create_horairetravail();
gtk_widget_show(horairetravail);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"espkine")));
}


void
on_prfilkine_clicked                   (GtkWidget      *button,
                                        gpointer         user_data)
{
id A;

char chemin[]="listekine.txt";
GtkWidget *prfilkine;
prfilkine=create_prfilkine();
gtk_widget_show(prfilkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"espkine")));
GtkWidget *labelnom;
GtkWidget *labelprenom;
GtkWidget *labelCIN;
GtkWidget *labeljour;
GtkWidget *labelmois;
GtkWidget *labelannee;
GtkWidget *labeladress;
GtkWidget *labelnum;
GtkWidget *labelpass;
GtkWidget *labelrole;
int i=1;
FILE*f;
f=fopen(chemin,"a+");
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %d\n",A.cin,A.nom,A.prenom,A.jour,A.mois,A.annee,A.adress,A.num,A.pass,&A.role)!=EOF)
{

}
labelnom=lookup_widget(prfilkine,"nomkine");
labelprenom=lookup_widget(prfilkine,"prenomkine");
labeljour=lookup_widget(prfilkine,"jourkine");
labelmois=lookup_widget(prfilkine,"moiskine");
labelannee=lookup_widget(prfilkine,"anneekine");
labeladress=lookup_widget(prfilkine,"adresskine");
labelnum=lookup_widget(prfilkine,"phonekine");
labelCIN=lookup_widget(prfilkine,"CINkine");
labelpass=lookup_widget(prfilkine,"passkine");

gtk_label_set_text(GTK_LABEL(labelnom),A.nom);
gtk_label_set_text(GTK_LABEL(labelprenom),A.prenom);
gtk_label_set_text(GTK_LABEL(labelCIN),A.cin);
gtk_label_set_text(GTK_LABEL(labeljour),A.jour);
gtk_label_set_text(GTK_LABEL(labelmois),A.mois);
gtk_label_set_text(GTK_LABEL(labelannee),A.annee);
gtk_label_set_text(GTK_LABEL(labeladress),A.adress);
gtk_label_set_text(GTK_LABEL(labelnum),A.num);
gtk_label_set_text(GTK_LABEL(labelpass),A.pass);
fclose(f);

}


void
on_reclamationkine_clicked             (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *reclamationkine;
reclamationkine=create_reclamationkine();
gtk_widget_show(reclamationkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"espkine")));
}


void
on_decnxkine_clicked                   (GtkWidget      *button,
                                        gpointer         user_data)
{
gtk_main_quit();
}
void
on_retrnrecl2_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *reclamationkine;
reclamationkine=create_reclamationkine();
gtk_widget_show(reclamationkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationenvoi")));

}



void
on_afficherdvkine_clicked              (GtkWidget       *button,
                                        gpointer         user_data)
{


GtkWidget *input;
char s[30];
char cin1[20],nom1[20],jour1[20],quand1[20],comment1[20];

char chemin[]="rendez_vous_adherent.txt";
input=lookup_widget(gestseancecure,"entryadherentrecherche");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(input)));
GtkWidget *gestrdvkine;
gestrdvkine=create_gestrdvkine();
gtk_widget_show(gestrdvkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"gestseancecure")));

GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;

FILE*f;
f=fopen(chemin,"a+");
if(f!=NULL)
{
while (fscanf(f,"%s %s %s %s %s\n",cin1,nom1,jour1,quand1,comment1)!=EOF)
{

if(strcmp(cin1,s)==0)
{



input1=lookup_widget(gestrdvkine,"cinadherent");
input2=lookup_widget(gestrdvkine,"nomadherent");
input3=lookup_widget(gestrdvkine,"jouradherent");
input4=lookup_widget(gestrdvkine,"quandkine");
input5=lookup_widget(gestrdvkine,"commentkine");



gtk_label_set_text(GTK_LABEL(input1),cin1);

gtk_label_set_text(GTK_LABEL(input2),nom1);

gtk_label_set_text(GTK_LABEL(input3),jour1);

gtk_label_set_text(GTK_LABEL(input4),quand1);

gtk_label_set_text(GTK_LABEL(input5),comment1);




}}



fclose(f);}
}



void
on_retrnprfilkine_clicked              (GtkWidget       *button,
                                        gpointer         user_data)
{
id A;

char chemin[]="listekine.txt";
GtkWidget *prfilkine;
prfilkine=create_prfilkine();
gtk_widget_show(prfilkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"modifprfilkine")));
GtkWidget *labelnom;
GtkWidget *labelprenom;
GtkWidget *labelCIN;
GtkWidget *labeljour;
GtkWidget *labelmois;
GtkWidget *labelannee;
GtkWidget *labeladress;
GtkWidget *labelnum;
GtkWidget *labelpass;
GtkWidget *labelrole;
int i=1;
FILE*f;
f=fopen(chemin,"a+");
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %d\n",A.cin,A.nom,A.prenom,A.jour,A.mois,A.annee,A.adress,A.num,A.pass,&A.role)!=EOF)
{

}
labelnom=lookup_widget(prfilkine,"nomkine");
labelprenom=lookup_widget(prfilkine,"prenomkine");
labeljour=lookup_widget(prfilkine,"jourkine");
labelmois=lookup_widget(prfilkine,"moiskine");
labelannee=lookup_widget(prfilkine,"anneekine");
labeladress=lookup_widget(prfilkine,"adresskine");
labelnum=lookup_widget(prfilkine,"phonekine");
labelCIN=lookup_widget(prfilkine,"CINkine");
labelpass=lookup_widget(prfilkine,"passkine");

gtk_label_set_text(GTK_LABEL(labelnom),A.nom);
gtk_label_set_text(GTK_LABEL(labelprenom),A.prenom);
gtk_label_set_text(GTK_LABEL(labelCIN),A.cin);
gtk_label_set_text(GTK_LABEL(labeljour),A.jour);
gtk_label_set_text(GTK_LABEL(labelmois),A.mois);
gtk_label_set_text(GTK_LABEL(labelannee),A.annee);
gtk_label_set_text(GTK_LABEL(labeladress),A.adress);
gtk_label_set_text(GTK_LABEL(labelnum),A.num);
gtk_label_set_text(GTK_LABEL(labelpass),A.pass);
fclose(f);
}



void
on_retrnespkinerec_clicked             (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *reclamationkine;
reclamationkine=create_reclamationkine();
gtk_widget_show(reclamationkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"succreclenvoi")));
}


void
on_retrnenvoirecl_clicked              (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *reclamationenvoi;
reclamationenvoi=create_reclamationenvoi();
gtk_widget_show(reclamationenvoi);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"failenvoirec")));
}


void
on_cancelbutton_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *espkine;
espkine=create_espkine();
gtk_widget_show(espkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"horairetravail")));
}


void
on_okbuttonsave_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
char jour[20],de[20],a[20];
GtkWidget *inputjour;
GtkWidget *inputde;
GtkWidget *inputa;
char chemin[]="horairetravailkine.txt";
inputjour=lookup_widget(button,"comboboxentryjour");
strcpy(jour,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputjour)));
inputde=lookup_widget(button,"comboboxentrycommence");
strcpy(de,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputde)));
inputa=lookup_widget(button,"comboboxentryfini");
strcpy(a,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputa)));
FILE*f;
f=fopen(chemin,"a+");
fprintf(f,"%s %s %s\n",jour,de,a);
fclose(f);
}


void
on_affichefichemedi_clicked            (GtkWidget      *button,
                                        gpointer         user_data)
{
fiche A;
char s[30];
affichefichemed=create_affichefichemed();
gtk_widget_show(affichefichemed);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"fichemede")));
GtkWidget *input;
input=lookup_widget(fichemede,"entryficherecherche");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(input)));

{
FILE*f;
f=fopen("fichemed.txt","a+");
if(f!=NULL)
{
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s\n",A.cin,A.nom,A.prenom,A.age,A.poids,A.taille,A.fumeur,A.alcoolic,A.maladie,A.sang,A.blessure)!=EOF)
{


if(strcmp(s,A.cin)==0)

{

GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget *input6;
GtkWidget *input7;
GtkWidget *input8;
GtkWidget *input9;
GtkWidget *input10;
GtkWidget *input11;
input1=lookup_widget(affichefichemed,"cinkine");
input2=lookup_widget(affichefichemed,"nomkine");
input3=lookup_widget(affichefichemed,"prenomkine");
input4=lookup_widget(affichefichemed,"datekine");
input5=lookup_widget(affichefichemed,"pointurekine");
input6=lookup_widget(affichefichemed,"contactkine");
input7=lookup_widget(affichefichemed,"fumekine");
input8=lookup_widget(affichefichemed,"alcoolkine");
input9=lookup_widget(affichefichemed,"maladiekine");
input10=lookup_widget(affichefichemed,"sangkine");
input11=lookup_widget(affichefichemed,"blessurekine");

gtk_label_set_text(GTK_LABEL(input1),A.cin);

gtk_label_set_text(GTK_LABEL(input2),A.nom);

gtk_label_set_text(GTK_LABEL(input3),A.prenom);

gtk_label_set_text(GTK_LABEL(input4),A.age);

gtk_label_set_text(GTK_LABEL(input5),A.poids);

gtk_label_set_text(GTK_LABEL(input6),A.taille);

gtk_label_set_text(GTK_LABEL(input7),A.fumeur);

gtk_label_set_text(GTK_LABEL(input8),A.alcoolic);

gtk_label_set_text(GTK_LABEL(input9),A.maladie);

gtk_label_set_text(GTK_LABEL(input10),A.sang);

gtk_label_set_text(GTK_LABEL(input11),A.blessure);


}
}
fclose(f);
}

}

}


void
on_retrnfichemed_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1;


fichemede=lookup_widget(button,"fichemede");
fichemede=create_fichemede();
gtk_widget_show(fichemede);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"affichefichemed")));
treeview1=lookup_widget(fichemede,"treeviewfichemed");
afficher_fichemed(treeview1);
}

