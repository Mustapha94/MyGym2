#include <gtk/gtk.h>



void
on_fichemed_clicked                    (GtkWidget      *button,
                                        gpointer         user_data);

void
on_gestcure_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);


void
on_savekine_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnespkine2_clicked               (GtkWidget      *button,
                                        gpointer         user_data);

void
on_retrnkine3_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_reclmtionrecu_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_reclmtionenvoi_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnrecl_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_envoirecl_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnkine4_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrngestcure_clicked               (GtkWidget      *button,
                                        gpointer         user_data);

void
on_retrnespkine5_clicked               (GtkWidget     *button,
                                        gpointer         user_data);

void
on_modifprfil_clicked                  (GtkWidget      *button,
                                        gpointer         user_data);

void
on_horairetravailkine_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_prfilkine_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_reclamationkine_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_decnxkine_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnrecl2_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);


void
on_afficherdvkine_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnprfilkine_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_affichefichemed_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnfichemed_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnespkinerec_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnenvoirecl_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_cancelbutton_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_okbuttonsave_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_affichefichemedi_clicked            (GtkWidget      *button,
                                        gpointer         user_data);

void
on_retrnfichemed_clicked               (GtkWidget       *button,
                                        gpointer         user_data);
