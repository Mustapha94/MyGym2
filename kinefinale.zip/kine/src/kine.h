#include <gtk/gtk.h>

typedef struct
{
char adress[100];
char mail[20];
char mail2[20];
}kine;

