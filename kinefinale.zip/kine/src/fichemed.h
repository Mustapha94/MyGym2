#include <gtk/gtk.h>

typedef struct
{
char cin[20];
char nom[20];
char prenom[20];
char age[20];
char poids[20];
char taille[20];
char fumeur[20];
char alcoolic[20];
char maladie[20];
char sang[20];
char blessure[20];

}fiche;
typedef struct
{
char cin[20];
char nom[20];
char prenom[20];
char jour[20];
char mois[20];
char annee[20];
char adress[20];
char num[20];
char pass[20];
int role;
}id;

void afficher_fichemed(GtkWidget *liste);
void afficher_adherents(GtkWidget *liste);
