#include <stdio.h>
#include <stdlib.h>
#include "ajout.h"
#include <string.h>

int emporter_liste_adherent(adherent tab[],int n)
{
int i=0;
char chemin[]="listeadherent.txt";
FILE*f;
f=fopen(chemin,"r");
while (fscanf(f,"%s %s %s %s %s %s %s %s %s\n",tab[i].titre,tab[i].nom,tab[i].prenom,tab[i].pays,tab[i].num,tab[i].adress,tab[i].mail,tab[i].jour,tab[i].mois,tab[i].annee)!=EOF)
i++;
n=i;
fclose(f);
return n;
}
int ajouter_adherent(adherent A,int n)
{
tabadherent[n]=A;
n=n+1;
return n;
}

