typedef struct 
{
char titre[20];
char nom[20];
char prenom[20];
char pays[20];
char num[20];
char adress[200];
char mail[50];
char jour[3];
char mois[3];
char annee[5];
}adherent;

adherent tabadherent[100];
int nbadherent;
int ajouter_adherent(adherent tabadherent , int n);
int emporter_liste_adherent(adherent tab[],int n);

