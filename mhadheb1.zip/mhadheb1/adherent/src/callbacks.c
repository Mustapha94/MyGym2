#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "ajout.h"
#include "imc.h"

GtkWidget *prfil;
GtkWidget *gymadvisor;
GtkWidget *avisrec;
GtkWidget *fichemed;
GtkWidget *modifprofil;
GtkWidget *espadhrnt;
GtkWidget *succesadherent;

void
on_exit_clicked                        (GtkWidget      *button,
                                        gpointer         user_data)
{
gtk_main_quit();
}


void
on_modif_clicked                       (GtkWidget      *button,
                                        gpointer         user_data)
{
modifprofil=create_modifprofil();
gtk_widget_show(modifprofil);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"prfil")));

}



void
on_return_clicked                      (GtkWidget       *button,
                                        gpointer         user_data)
{
char titre[20],nom[20],prenom[20],pays[20],num[20];
char adress[20],mail[20],jour[20],mois[20],annee[20];
char chemin[]="listeadherent.txt";
prfil=create_prfil();
gtk_widget_show(prfil);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"modifprofil")));
int i=1;
FILE*f;
f=fopen(chemin,"a+");
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s\n",titre,nom,prenom,pays,num,adress,mail,jour,mois,annee)!=EOF)
{
i++;
}
GtkWidget *labeltitle;
GtkWidget *labelname;
GtkWidget *labellastname;
GtkWidget *labelpays;
GtkWidget *labelphonmbr;
GtkWidget *labeladress;
GtkWidget *labelmailadress;
GtkWidget *labeljour;
GtkWidget *labelmois;
GtkWidget *labelannee;
labeltitle=lookup_widget(prfil,"title");
labelname=lookup_widget(prfil,"name");
labellastname=lookup_widget(prfil,"lastname");
labelpays=lookup_widget(prfil,"pays");
labelphonmbr=lookup_widget(prfil,"phonmbr");
labeladress=lookup_widget(prfil,"adress");
labelmailadress=lookup_widget(prfil,"mailadress");
labeljour=lookup_widget(prfil,"jour");
labelmois=lookup_widget(prfil,"mois");
labelannee=lookup_widget(prfil,"annee");
gtk_label_set_text(GTK_LABEL(labeltitle),titre);
gtk_label_set_text(GTK_LABEL(labelname),nom);
gtk_label_set_text(GTK_LABEL(labellastname),prenom);
gtk_label_set_text(GTK_LABEL(labelpays),pays);
gtk_label_set_text(GTK_LABEL(labelphonmbr),num);
gtk_label_set_text(GTK_LABEL(labeladress),adress);
gtk_label_set_text(GTK_LABEL(labelmailadress),mail);
gtk_label_set_text(GTK_LABEL(labeljour),jour);
gtk_label_set_text(GTK_LABEL(labelmois),mois);
gtk_label_set_text(GTK_LABEL(labelannee),annee);

fclose(f);

}


void
on_save_clicked                        (GtkWidget       *button,
                                        gpointer         user_data)
{
int i;
adherent A;
char chemin[]="listeadherent.txt";
GtkWidget *inputtitre;
GtkWidget *inputnom;
GtkWidget *inputprenom;
GtkWidget *inputpays;
GtkWidget *inputnum;
GtkWidget *inputadress;
GtkWidget *inputmail;
GtkWidget *inputjour;
GtkWidget *inputmois;
GtkWidget *inputannee;
GtkWidget *modifprfil;
inputtitre=lookup_widget(button,"comboboxentry1");
inputnom=lookup_widget(button,"entry1");
inputprenom=lookup_widget(button,"entry2");
inputpays=lookup_widget(button,"comboboxentry2");
inputnum=lookup_widget(button,"entry3");
inputadress=lookup_widget(button,"entryadress");
inputmail=lookup_widget(button,"entry4");
inputjour=lookup_widget(button,"comboboxentry3");
inputmois=lookup_widget(button,"comboboxentry4");
inputannee=lookup_widget(button,"comboboxentry5");
strcpy(A.titre,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputtitre)));
strcpy(A.nom,gtk_entry_get_text(GTK_ENTRY(inputnom)));
strcpy(A.prenom,gtk_entry_get_text(GTK_ENTRY(inputprenom)));
strcpy(A.pays,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputpays)));
strcpy(A.num,gtk_entry_get_text(GTK_ENTRY(inputnum)));
strcpy(A.adress,gtk_entry_get_text(GTK_ENTRY(inputadress)));
strcpy(A.mail,gtk_entry_get_text(GTK_ENTRY(inputmail)));
strcpy(A.jour,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputjour)));
strcpy(A.mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputmois)));
strcpy(A.annee,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputannee)));
nbadherent=ajouter_adherent(A,nbadherent);
FILE*f;
f=fopen(chemin,"a+");
for (i=0;i<nbadherent;i++)
{
fprintf(f,"%s %s %s %s %s %s %s %s %s %s \n",tabadherent[i].titre,tabadherent[i].nom,tabadherent[i].prenom,tabadherent[i].pays,tabadherent[i].num,tabadherent[i].adress,tabadherent[i].mail,tabadherent[i].jour,tabadherent[i].mois,tabadherent[i].annee);
}
fclose(f);
succesadherent=create_succesadherent();
gtk_widget_show(succesadherent);
gtk_widget_destroy(GTK_WIDGET(lookup_widget(button,"modifprofil")));

}

void
on_retrnesp3_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{
espadhrnt=create_espadhrnt();
gtk_widget_show(espadhrnt);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"fichemed")));
}

void
on_retrnprfil1_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{
espadhrnt=create_espadhrnt();
gtk_widget_show(espadhrnt);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"prfil")));
}


void
on_retrnesp1_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
espadhrnt=create_espadhrnt();
gtk_widget_show(espadhrnt);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"gymadvisor")));
}


void
on_retrnesp2_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
espadhrnt=create_espadhrnt();
gtk_widget_show(espadhrnt);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"avisrec")));
}

void
on_continue1_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
prfil=create_prfil();
gtk_widget_show(prfil);
gtk_widget_destroy(GTK_WIDGET(lookup_widget(button,"succesadherent")));


char titre[20],nom[20],prenom[20],pays[20],num[20];
char adress[20],mail[20],jour[20],mois[20],annee[20];
char chemin[]="listeadherent.txt";

int i=1;
FILE*f;
f=fopen(chemin,"a+");
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s\n",titre,nom,prenom,pays,num,adress,mail,jour,mois,annee)!=EOF)
{
i++;
}
GtkWidget *labeltitle;
GtkWidget *labelname;
GtkWidget *labellastname;
GtkWidget *labelpays;
GtkWidget *labelphonmbr;
GtkWidget *labeladress;
GtkWidget *labelmailadress;
GtkWidget *labeljour;
GtkWidget *labelmois;
GtkWidget *labelannee;
labeltitle=lookup_widget(prfil,"title");
labelname=lookup_widget(prfil,"name");
labellastname=lookup_widget(prfil,"lastname");
labelpays=lookup_widget(prfil,"pays");
labelphonmbr=lookup_widget(prfil,"phonmbr");
labeladress=lookup_widget(prfil,"adress");
labelmailadress=lookup_widget(prfil,"mailadress");
labeljour=lookup_widget(prfil,"jour");
labelmois=lookup_widget(prfil,"mois");
labelannee=lookup_widget(prfil,"annee");
gtk_label_set_text(GTK_LABEL(labeltitle),titre);
gtk_label_set_text(GTK_LABEL(labelname),nom);
gtk_label_set_text(GTK_LABEL(labellastname),prenom);
gtk_label_set_text(GTK_LABEL(labelpays),pays);
gtk_label_set_text(GTK_LABEL(labelphonmbr),num);
gtk_label_set_text(GTK_LABEL(labeladress),adress);
gtk_label_set_text(GTK_LABEL(labelmailadress),mail);
gtk_label_set_text(GTK_LABEL(labeljour),jour);
gtk_label_set_text(GTK_LABEL(labelmois),mois);
gtk_label_set_text(GTK_LABEL(labelannee),annee);

fclose(f);

}


void
on_buttonprfil_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{
char titre[20],nom[20],prenom[20],pays[20],num[20];
char adress[20],mail[20],jour[20],mois[20],annee[20];
char chemin[]="listeadherent.txt";
prfil=create_prfil();
gtk_widget_show(prfil);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"espadhrnt")));
int i=1;
FILE*f;
f=fopen(chemin,"a+");
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s\n",titre,nom,prenom,pays,num,adress,mail,jour,mois,annee)!=EOF)
{
i++;
}
GtkWidget *labeltitle;
GtkWidget *labelname;
GtkWidget *labellastname;
GtkWidget *labelpays;
GtkWidget *labelphonmbr;
GtkWidget *labeladress;
GtkWidget *labelmailadress;
GtkWidget *labeljour;
GtkWidget *labelmois;
GtkWidget *labelannee;
labeltitle=lookup_widget(prfil,"title");
labelname=lookup_widget(prfil,"name");
labellastname=lookup_widget(prfil,"lastname");
labelpays=lookup_widget(prfil,"pays");
labelphonmbr=lookup_widget(prfil,"phonmbr");
labeladress=lookup_widget(prfil,"adress");
labelmailadress=lookup_widget(prfil,"mailadress");
labeljour=lookup_widget(prfil,"jour");
labelmois=lookup_widget(prfil,"mois");
labelannee=lookup_widget(prfil,"annee");
gtk_label_set_text(GTK_LABEL(labeltitle),titre);
gtk_label_set_text(GTK_LABEL(labelname),nom);
gtk_label_set_text(GTK_LABEL(labellastname),prenom);
gtk_label_set_text(GTK_LABEL(labelpays),pays);
gtk_label_set_text(GTK_LABEL(labelphonmbr),num);
gtk_label_set_text(GTK_LABEL(labeladress),adress);
gtk_label_set_text(GTK_LABEL(labelmailadress),mail);
gtk_label_set_text(GTK_LABEL(labeljour),jour);
gtk_label_set_text(GTK_LABEL(labelmois),mois);
gtk_label_set_text(GTK_LABEL(labelannee),annee);

fclose(f);

}

void
on_buttongym_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *gymadvisor;
gymadvisor=create_gymadvisor();
gtk_widget_show(gymadvisor);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"espadhrnt")));

}

void
on_buttonavis_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *avisrec;
avisrec=create_avisrec();
gtk_widget_show(avisrec);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"espadhrnt")));
}

void
on_buttonmedi_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *fichemed;
fichemed=create_fichemed();
gtk_widget_show(fichemed);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"espadhrnt")));
}


void
on_buttongym1_clicked                  (GtkWidget        *button,
                                        gpointer         user_data)
{
GtkWidget *imc;
imc=create_imc();
gtk_widget_show(imc);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"gymadvisor")));
}


void
on_buttongym2_clicked                  (GtkWidget        *button,
                                        gpointer         user_data)
{

}


void
on_buttongym3_clicked                  (GtkWidget        *button,
                                        gpointer         user_data)
{
GtkWidget *tabregime;
tabregime=create_tabregime();
gtk_widget_show(tabregime);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"gymadvisor")));
}


void
on_buttongym4_clicked                  (GtkWidget        *button,
                                        gpointer         user_data)
{
GtkWidget *advice;
advice=create_advice();
gtk_widget_show(advice);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"gymadvisor")));
GtkWidget *inputadvice;
GtkWidget *inputadvice1;
GtkWidget *inputadvice2;
GtkWidget *inputadvice3;
char adv[40];
float ad;
inputadvice=lookup_widget(advice,"label40");
inputadvice1=lookup_widget(advice,"label41");
inputadvice2=lookup_widget(advice,"label42");
inputadvice3=lookup_widget(advice,"label43");
FILE *f;
f=fopen("liste_imc.txt","r");
while (fscanf(f," %s\n",adv)!=EOF);
ad=(float)atoi(adv);
if (ad<18.5)
{
gtk_label_set_text(GTK_LABEL(inputadvice),"Votre poids apparaît trop faible par rapport à votre taille.");
gtk_label_set_text(GTK_LABEL(inputadvice1),"Ce faible indice de masse corporel (IMC) est peut-être la conséquence d'une pathologie,");
gtk_label_set_text(GTK_LABEL(inputadvice2),"mais elle-même peut exposer à un certain nombre de risques pour votre santé (carences, anémie, ostéoporose...).");
gtk_label_set_text(GTK_LABEL(inputadvice3),"Parlez-en avec votre médecin traitant. Il pourra rechercher la cause de cette maigreur et vous conseiller.");
}
else if ((18.5<ad)&&(ad<24.9))
{
gtk_label_set_text(GTK_LABEL(inputadvice),"Votre poids est adapté à votre taille.");
gtk_label_set_text(GTK_LABEL(inputadvice1),"Gardez vos habitudes alimentaires pour conserver un indice de masse corporel (IMC) idéal et un poids qui vous assure un état de santé optimal.");
gtk_label_set_text(GTK_LABEL(inputadvice2),"Une alimentation équilibrée, sans excès de matières grasses, associée à une activité physique régulière vous aideront à maintenir votre poids idéal.");
}
else if ((25<ad)&&(ad<29.9))
{
gtk_label_set_text(GTK_LABEL(inputadvice),"Votre poids commence à devenir élevé par rapport à votre taille.");
gtk_label_set_text(GTK_LABEL(inputadvice1),"A long terme, un indice de masse corporel (IMC) élevé a des conséquences sur la santé.");
gtk_label_set_text(GTK_LABEL(inputadvice2),"L'excès de poids entraîne un risque accru de maladies métaboliques (diabète), cardiaques, respiratoires, articulaires et de cancer.");
gtk_label_set_text(GTK_LABEL(inputadvice3),"Si vous souhaitez commencer un régime pour perdre du poids, parlez-en au préalable avec votre médecin traitant.");
}
else if (30<ad)
{
gtk_label_set_text(GTK_LABEL(inputadvice),"Votre poids est trop élevé par rapport à votre taille.");
gtk_label_set_text(GTK_LABEL(inputadvice1),"Du point de vue médical, l'obésité est un excès de masse grasse ayant des conséquences sur la santé. ");
gtk_label_set_text(GTK_LABEL(inputadvice2)," L'excès de poids entraîne un risque accru de maladies métaboliques (diabète), cardiaques, respiratoires, articulaires et de cancer. ");
gtk_label_set_text(GTK_LABEL(inputadvice3),"Si vous souhaitez commencer un régime pour perdre du poids, parlez-en au préalable avec votre médecin traitant.");
}
}
void
on_buttoncal5_clicked                  (GtkWidget        *button,
                                        gpointer         user_data)
{
char t[40], p[40];
int ta=0,po=0;
float i;
int j=0;
char k[20];
GtkWidget *calimc;
GtkWidget *inputtaille;
GtkWidget *inputpoids;
GtkWidget *outputimc;
outputimc=lookup_widget(button,"calimc");
inputtaille=lookup_widget(button,"entrytaille5");
inputpoids=lookup_widget(button,"entrypoids6");
strcpy(t,gtk_entry_get_text(GTK_ENTRY(inputtaille)));
strcpy(p,gtk_entry_get_text(GTK_ENTRY(inputpoids)));
ta=(float)atoi(t);
po=(float)atoi(p);
i=imc1(po,ta);
memset(k,0,sizeof(k));
sprintf(k, "%f", i);
gtk_label_set_text(GTK_LABEL(outputimc),k);
FILE *f;
f=fopen("liste_imc.txt","a+");
{
fprintf(f,"%s \n",k);
}
fclose(f);
}

void
on_retrnimc_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
gymadvisor=create_gymadvisor();
gtk_widget_show(gymadvisor);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"imc")));
}


void
on_buttonrecla2_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *reclama;
reclama=create_reclama();
gtk_widget_show(reclama);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"avisrec")));
}

void
on_buttonavis3_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *avis;
avis=create_avis();
gtk_widget_show(avis);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"avisrec")));
}


void
on_retrnreclama_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
avisrec=create_avisrec();
gtk_widget_show(avisrec);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclama")));
}


void
on_buttonenvoi3_enter                  (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputreclama;
GtkWidget *inputrc;
char rc[40],dsc[100];
inputreclama=lookup_widget(button,"comboboxentryrecla6");
strcpy(rc,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputreclama)));
inputrc=lookup_widget(button,"entryrec5");
strcpy(dsc,gtk_entry_get_text(GTK_ENTRY(inputrc)));
if (strcmp(rc,"admin")==0)
{
FILE *f1;
f1=fopen("recla_admin.txt","a+");
fprintf(f1,"%s \n",dsc);
fclose(f1);
}
else if (strcmp(rc,"kine")==0)
{
FILE *f2;
f2=fopen("recla_kine.txt","a+");
fprintf(f2,"%s \n",dsc);
fclose(f2);
}
else if (strcmp(rc,"docteur")==0)
{
FILE *f3;
f3=fopen("recla_docteur.txt","a+");
fprintf(f3,"%s \n",dsc);
fclose(f3);
}
else if (strcmp(rc,"coach")==0)
{
FILE *f4;
f4=fopen("recla_coach.txt","a+");
fprintf(f4,"%s \n",dsc);
fclose(f4);
}
avisrec=create_avisrec();
gtk_widget_show(avisrec);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclama")));
}



void
on_radiobutton1_clicked                (GtkWidget        *button,
                                        gpointer         user_data)
{
FILE *f6;
f6=fopen("avis.txt","a+");
{
fprintf(f6,"%s \n","1");
}
fclose(f6);
}


void
on_radiobutton2_clicked                (GtkWidget        *button,
                                        gpointer         user_data)
{
FILE *f6;
f6=fopen("avis.txt","a+");
{
fprintf(f6,"%s \n","5");
}
fclose(f6);
}


void
on_radiobutton2officiel_clicked        (GtkWidget       *button,
                                        gpointer         user_data)
{
FILE *f6;
f6=fopen("avis.txt","a+");
{
fprintf(f6,"%s \n","2");
}
fclose(f6);
}


void
on_radiobutton3_clicked                (GtkWidget      *button,
                                        gpointer         user_data)
{
FILE *f6;
f6=fopen("avis.txt","a+");
{
fprintf(f6,"%s \n","3");
}
fclose(f6);
}


void
on_radiobutton4_clicked                (GtkWidget      *button,
                                        gpointer         user_data)
{
FILE *f6;
f6=fopen("avis.txt","a+");
{
fprintf(f6,"%s \n","4");
}
fclose(f6);
}


void
on_rtrnaviss_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
avisrec=create_avisrec();
gtk_widget_show(avisrec);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"avis")));
}


void
on_radioc6_clicked                     (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *inputavco;
char co[20];
inputavco=lookup_widget(button,"comboboxentrycoach1");
strcpy(co,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavco)));
FILE *f7;
f7=fopen("aviscoach.txt","a+");
{
fprintf(f7,"%s %s \n",co,"1");
}
fclose(f7);
}


void
on_radioc7_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputavcoa;
char coa[20];
inputavcoa=lookup_widget(button,"comboboxentrycoach1");
strcpy(coa,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavcoa)));
FILE *f7;
f7=fopen("aviscoach.txt","a+");
{
fprintf(f7,"%s %s \n",coa,"2");
}
fclose(f7);
}

void
on_radioc9_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputavco1;
char co1[20];
inputavco1=lookup_widget(button,"comboboxentrycoach1");
strcpy(co1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavco1)));
FILE *f7;
f7=fopen("aviscoach.txt","a+");
{
fprintf(f7,"%s %s \n",co1,"4");
}
fclose(f7);
}


void
on_radioc10_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputavcoa1;
char coa1[20];
inputavcoa1=lookup_widget(button,"comboboxentrycoach1");
strcpy(coa1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavcoa1)));
FILE *f7;
f7=fopen("aviscoach.txt","a+");
{
fprintf(f7,"%s %s \n",coa1,"5");
}
fclose(f7);
}


void
on_radioc8_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputavc;
char c[20];
inputavc=lookup_widget(button,"comboboxentrycoach1");
strcpy(c,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavc)));
FILE *f7;
f7=fopen("aviscoach.txt","a+");
{
fprintf(f7,"%s %s \n",c,"3");
}
fclose(f7);
}


void
on_radiok6_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputavki;
char ki[20];
inputavki=lookup_widget(button,"comboboxentrykine1");
strcpy(ki,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavki)));
FILE *f8;
f8=fopen("aviskine.txt","a+");
{
fprintf(f8,"%s %s \n",ki,"1");
}
fclose(f8);
}


void
on_radiok8_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputavkin;
char ki1[20];
inputavkin=lookup_widget(button,"comboboxentrykine1");
strcpy(ki1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavkin)));
FILE *f8;
f8=fopen("aviskine.txt","a+");
{
fprintf(f8,"%s %s \n",ki1,"3");
}
fclose(f8);
}

void
on_radiok9_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputavki1;
char kin[20];
inputavki1=lookup_widget(button,"comboboxentrykine1");
strcpy(kin,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavki1)));
FILE *f8;
f8=fopen("aviskine.txt","a+");
{
fprintf(f8,"%s %s \n",kin,"4");
}
fclose(f8);
}


void
on_radiok10_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputavkine;
char kin1[20];
inputavkine=lookup_widget(button,"comboboxentrykine1");
strcpy(kin1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavkine)));
FILE *f8;
f8=fopen("aviskine.txt","a+");
{
fprintf(f8,"%s %s \n",kin1,"5");
}
fclose(f8);
}


void
on_radiok7_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputavk;
char k[20];
inputavk=lookup_widget(button,"comboboxentrykine1");
strcpy(k,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavk)));
FILE *f8;
f8=fopen("aviskine.txt","a+");
{
fprintf(f8,"%s %s \n",k,"2");
}
fclose(f8);
}


void
on_radiomed3_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputamed;
char med[20];
inputamed=lookup_widget(button,"comboboxentrymedc1");
strcpy(med,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputamed)));
FILE *f9;
f9=fopen("avismedecin.txt","a+");
{
fprintf(f9,"%s %s \n",med,"2");
}
fclose(f9);
}


void
on_radiomed15_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputame;
char me[20];
inputame=lookup_widget(button,"comboboxentrymedc1");
strcpy(me,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputame)));
FILE *f9;
f9=fopen("avismedecin.txt","a+");
{
fprintf(f9,"%s %s \n",me,"4");
}
fclose(f9);
}


void
on_radiomed6_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputamede;
char mede[20];
inputamede=lookup_widget(button,"comboboxentrymedc1");
strcpy(mede,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputamede)));
FILE *f9;
f9=fopen("avismedecin.txt","a+");
{
fprintf(f9,"%s %s \n",mede,"5");
}
fclose(f9);
}


void
on_radiomed12_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputamedec;
char medec[20];
inputamedec=lookup_widget(button,"comboboxentrymedc1");
strcpy(medec,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputamedec)));
FILE *f9;
f9=fopen("avismedecin.txt","a+");
{
fprintf(f9,"%s %s \n",medec,"1");
}
fclose(f9);
}


void
on_radiomed14_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputam;
char m[20];
inputam=lookup_widget(button,"comboboxentrymedc1");
strcpy(m,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputam)));
FILE *f9;
f9=fopen("avismedecin.txt","a+");
{
fprintf(f9,"%s %s \n",m,"3");
}
fclose(f9);
}


void
on_prflcoac_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *prflcoach;
prflcoach=create_prflcoach();
gtk_widget_show(prflcoach);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"fichemed")));
GtkWidget *inputprfc;
GtkWidget *inputprfc1;
GtkWidget *inputprfc2;
GtkWidget *inputprfc3;
GtkWidget *inputprfc4;
GtkWidget *inputprfc5;
char prf[40],nomcoa[40],prenomco[40],numcoa[40],mailcoac[40],specia[40];
inputprfc=lookup_widget(button,"comboboxentrycoa9");
strcpy(prf,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputprfc)));
if (strcmp(prf,"coach1")==0)
{
FILE *f20;
f20=fopen("coach1.txt","r");
if(f20!=NULL)
{while (fscanf(f20,"%s %s %s %s %s\n",nomcoa,prenomco,numcoa,mailcoac,specia)!=EOF)
inputprfc1=lookup_widget(prflcoach,"nomc1");
inputprfc2=lookup_widget(prflcoach,"prenoc1");
inputprfc3=lookup_widget(prflcoach,"telcoach");
inputprfc4=lookup_widget(prflcoach,"emaic");
inputprfc5=lookup_widget(prflcoach,"spec1");
gtk_label_set_text(GTK_LABEL(inputprfc5),specia);
gtk_label_set_text(GTK_LABEL(inputprfc1),nomcoa);
gtk_label_set_text(GTK_LABEL(inputprfc2),prenomco);
gtk_label_set_text(GTK_LABEL(inputprfc3),numcoa);
gtk_label_set_text(GTK_LABEL(inputprfc4),mailcoac);
}
}
else if (strcmp(prf,"coach2")==0)
{
FILE *f24;
f24=fopen("coach2.txt","r");
if(f24!=NULL)
{while (fscanf(f24,"%s %s %s %s %s\n",nomcoa,prenomco,numcoa,mailcoac,specia)!=EOF)
inputprfc1=lookup_widget(prflcoach,"nomc1");
inputprfc2=lookup_widget(prflcoach,"prenoc1");
inputprfc3=lookup_widget(prflcoach,"telcoach");
inputprfc4=lookup_widget(prflcoach,"emaic");
inputprfc5=lookup_widget(prflcoach,"spec1");
gtk_label_set_text(GTK_LABEL(inputprfc5),specia);
gtk_label_set_text(GTK_LABEL(inputprfc1),nomcoa);
gtk_label_set_text(GTK_LABEL(inputprfc2),prenomco);
gtk_label_set_text(GTK_LABEL(inputprfc3),numcoa);
gtk_label_set_text(GTK_LABEL(inputprfc4),mailcoac);
}
}
else if (strcmp(prf,"coach3")==0)
{
FILE *f25;
f25=fopen("coach3.txt","r");
if(f25!=NULL)
{while (fscanf(f25,"%s %s %s %s %s\n",nomcoa,prenomco,numcoa,mailcoac,specia)!=EOF)
inputprfc1=lookup_widget(prflcoach,"nomc1");
inputprfc2=lookup_widget(prflcoach,"prenoc1");
inputprfc3=lookup_widget(prflcoach,"telcoach");
inputprfc4=lookup_widget(prflcoach,"emaic");
inputprfc5=lookup_widget(prflcoach,"spec1");
gtk_label_set_text(GTK_LABEL(inputprfc5),specia);
gtk_label_set_text(GTK_LABEL(inputprfc1),nomcoa);
gtk_label_set_text(GTK_LABEL(inputprfc2),prenomco);
gtk_label_set_text(GTK_LABEL(inputprfc3),numcoa);
gtk_label_set_text(GTK_LABEL(inputprfc4),mailcoac);
}
}
}

void
on_prflkin_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *prflkine;
prflkine=create_prflkine();
gtk_widget_show(prflkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"fichemed")));
GtkWidget *inputprfk;
GtkWidget *inputprfk1;
GtkWidget *inputprfk2;
GtkWidget *inputprfk3;
GtkWidget *inputprfk4;
GtkWidget *inputprfk5;
char prfk[40],nomk[40],prenomk[40],numk[40],mailki[40],speciak[40];
inputprfk=lookup_widget(button,"comboboxentryki10");
strcpy(prfk,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputprfk)));
if (strcmp(prfk,"kine1")==0)
{
FILE *f21;
f21=fopen("kine1.txt","r");
if(f21!=NULL)
{while (fscanf(f21,"%s %s %s %s %s\n",nomk,prenomk,numk,mailki,speciak)!=EOF)
inputprfk1=lookup_widget(prflkine,"nomki1");
inputprfk2=lookup_widget(prflkine,"prenki1");
inputprfk3=lookup_widget(prflkine,"numkin1");
inputprfk4=lookup_widget(prflkine,"mailkin1");
inputprfk5=lookup_widget(prflkine,"seckin");
gtk_label_set_text(GTK_LABEL(inputprfk5),speciak);
gtk_label_set_text(GTK_LABEL(inputprfk1),nomk);
gtk_label_set_text(GTK_LABEL(inputprfk2),prenomk);
gtk_label_set_text(GTK_LABEL(inputprfk3),numk);
gtk_label_set_text(GTK_LABEL(inputprfk4),mailki);
}
}
else if (strcmp(prfk,"kine2")==0)
{
FILE *f22;
f22=fopen("kine2.txt","r");
if(f22!=NULL)
{while (fscanf(f22,"%s %s %s %s %s\n",nomk,prenomk,numk,mailki,speciak)!=EOF)
inputprfk1=lookup_widget(prflkine,"nomki1");
inputprfk2=lookup_widget(prflkine,"prenki1");
inputprfk3=lookup_widget(prflkine,"numkin1");
inputprfk4=lookup_widget(prflkine,"mailkin1");
inputprfk5=lookup_widget(prflkine,"seckin");
gtk_label_set_text(GTK_LABEL(inputprfk5),speciak);
gtk_label_set_text(GTK_LABEL(inputprfk1),nomk);
gtk_label_set_text(GTK_LABEL(inputprfk2),prenomk);
gtk_label_set_text(GTK_LABEL(inputprfk3),numk);
gtk_label_set_text(GTK_LABEL(inputprfk4),mailki);
}
}
else if (strcmp(prfk,"kine3")==0)
{
FILE *f23;
f23=fopen("kine3.txt","r");
if(f23!=NULL)
{while (fscanf(f23,"%s %s %s %s %s\n",nomk,prenomk,numk,mailki,speciak)!=EOF)
inputprfk1=lookup_widget(prflkine,"nomki1");
inputprfk2=lookup_widget(prflkine,"prenki1");
inputprfk3=lookup_widget(prflkine,"numkin1");
inputprfk4=lookup_widget(prflkine,"mailkin1");
inputprfk5=lookup_widget(prflkine,"seckin");
gtk_label_set_text(GTK_LABEL(inputprfk5),speciak);
gtk_label_set_text(GTK_LABEL(inputprfk1),nomk);
gtk_label_set_text(GTK_LABEL(inputprfk2),prenomk);
gtk_label_set_text(GTK_LABEL(inputprfk3),numk);
gtk_label_set_text(GTK_LABEL(inputprfk4),mailki);
}
}
}


void
on_prflmede_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *prflmedecin;
prflmedecin=create_prflmedecin();
gtk_widget_show(prflmedecin);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"fichemed")));
GtkWidget *inputprfm;
GtkWidget *inputprfm1;
GtkWidget *inputprfm2;
GtkWidget *inputprfm3;
GtkWidget *inputprfm4;
GtkWidget *inputprfm5;
char prfm[40],nomm[40],prenomm[40],numm[40],mailm[40],speciam[40];
inputprfm=lookup_widget(button,"comboboxentrymed11");
strcpy(prfm,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputprfm)));
if (strcmp(prfm,"medecin1")==0)
{
FILE *f30;
f30=fopen("medecin1.txt","r");
if(f30!=NULL)
{while (fscanf(f30,"%s %s %s %s %s\n",nomm,prenomm,numm,mailm,speciam)!=EOF)
inputprfm1=lookup_widget(prflmedecin,"nommed1");
inputprfm2=lookup_widget(prflmedecin,"prenommede2");
inputprfm3=lookup_widget(prflmedecin,"nummedecin1");
inputprfm4=lookup_widget(prflmedecin,"mailmede3");
inputprfm5=lookup_widget(prflmedecin,"specmede5");
gtk_label_set_text(GTK_LABEL(inputprfm5),speciam);
gtk_label_set_text(GTK_LABEL(inputprfm1),nomm);
gtk_label_set_text(GTK_LABEL(inputprfm2),prenomm);
gtk_label_set_text(GTK_LABEL(inputprfm3),numm);
gtk_label_set_text(GTK_LABEL(inputprfm4),mailm);
}
}
else if (strcmp(prfm,"medecin2")==0)
{
FILE *f31;
f31=fopen("medecin2.txt","r");
if(f31!=NULL)
{while (fscanf(f31,"%s %s %s %s %s\n",nomm,prenomm,numm,mailm,speciam)!=EOF)
inputprfm1=lookup_widget(prflmedecin,"nommed1");
inputprfm2=lookup_widget(prflmedecin,"prenommede2");
inputprfm3=lookup_widget(prflmedecin,"nummedecin1");
inputprfm4=lookup_widget(prflmedecin,"mailmede3");
inputprfm5=lookup_widget(prflmedecin,"specmede5");
gtk_label_set_text(GTK_LABEL(inputprfm5),speciam);
gtk_label_set_text(GTK_LABEL(inputprfm1),nomm);
gtk_label_set_text(GTK_LABEL(inputprfm2),prenomm);
gtk_label_set_text(GTK_LABEL(inputprfm3),numm);
gtk_label_set_text(GTK_LABEL(inputprfm4),mailm);
}
}
else if (strcmp(prfm,"medecin3")==0)
{
FILE *f32;
f32=fopen("kine3.txt","r");
if(f32!=NULL)
{while (fscanf(f32,"%s %s %s %s %s\n",nomm,prenomm,numm,mailm,speciam)!=EOF)
inputprfm1=lookup_widget(prflmedecin,"nommed1");
inputprfm2=lookup_widget(prflmedecin,"prenommede2");
inputprfm3=lookup_widget(prflmedecin,"nummedecin1");
inputprfm4=lookup_widget(prflmedecin,"mailmede3");
inputprfm5=lookup_widget(prflmedecin,"specmede5");
gtk_label_set_text(GTK_LABEL(inputprfm5),speciam);
gtk_label_set_text(GTK_LABEL(inputprfm1),nomm);
gtk_label_set_text(GTK_LABEL(inputprfm2),prenomm);
gtk_label_set_text(GTK_LABEL(inputprfm3),numm);
gtk_label_set_text(GTK_LABEL(inputprfm4),mailm);
}
}
}


void
on_rnd3_clicked                        (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *rndvmedecin;
rndvmedecin=create_rndvmedecin();
gtk_widget_show(rndvmedecin);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"fichemed")));
}


void
on_rnd2_clicked                        (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *rndvkine;
rndvkine=create_rndvkine();
gtk_widget_show(rndvkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"fichemed")));
}
void
on_rnd1_clicked                        (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *rndvcoach;
rndvcoach=create_rndvcoach();
gtk_widget_show(rndvcoach);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"fichemed")));
}


void
on_retrncoa_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
fichemed=create_fichemed();
gtk_widget_show(fichemed);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"prflcoach")));
}


void
on_retrnkine1_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
fichemed=create_fichemed();
gtk_widget_show(fichemed);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"prflkine")));
}


void
on_rtrnmede4_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
fichemed=create_fichemed();
gtk_widget_show(fichemed);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"prflmedecin")));
}


void
on_rndv14_clicked                      (GtkWidget       *button,
                                        gpointer         user_data)
{
fichemed=create_fichemed();
gtk_widget_show(fichemed);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"rndvcoach")));
GtkWidget *inputavrd;
GtkWidget *inputavrd1;
GtkWidget *inputavrd2;
GtkWidget *inputavrd3;
char rd[20],rd1[20],rd2[20],rd3[200];
inputavrd=lookup_widget(button,"comboboxentrycoach16");
strcpy(rd,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavrd)));
inputavrd1=lookup_widget(button,"comboboxentryjour17");
strcpy(rd1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavrd1)));
inputavrd2=lookup_widget(button,"comboboxentryheure18");
strcpy(rd2,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavrd2)));
inputavrd3=lookup_widget(button,"entry5");
strcpy(rd3,gtk_entry_get_text(GTK_ENTRY(inputavrd3)));
FILE *f40;
f40=fopen("rendez_vous_coach.txt","a+");
{
fprintf(f40,"%s %s %s %s \n",rd,rd1,rd2,rd3);
}
fclose(f40);
}



void
on_rndvkine1_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
fichemed=create_fichemed();
gtk_widget_show(fichemed);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"rndvkine")));
GtkWidget *inputavrdki;
GtkWidget *inputavrdki1;
GtkWidget *inputavrdki2;
GtkWidget *inputavrdki3;
char rdk[20],rdk1[20],rdk2[20],rdk3[200];
inputavrdki=lookup_widget(button,"comboboxentrykine19");
strcpy(rdk,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavrdki)));
inputavrdki1=lookup_widget(button,"comboboxentryjkine10");
strcpy(rdk1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavrdki1)));
inputavrdki2=lookup_widget(button,"comboboxentry11");
strcpy(rdk2,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavrdki2)));
inputavrdki3=lookup_widget(button,"entry6");
strcpy(rdk3,gtk_entry_get_text(GTK_ENTRY(inputavrdki3)));
FILE *f50;
f50=fopen("rendez_vous_kine.txt","a+");
{
fprintf(f50,"%s %s %s %s \n",rdk,rdk1,rdk2,rdk3);
}
fclose(f50);
}


void
on_rndvmedecin1_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
fichemed=create_fichemed();
gtk_widget_show(fichemed);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"rndvmedecin")));
GtkWidget *inputavrdm;
GtkWidget *inputavrdm1;
GtkWidget *inputavrdm2;
GtkWidget *inputavrdm3;
char rm[20],rm1[20],rm2[20],rm3[200];
inputavrdm=lookup_widget(button,"comboboxentrymede12");
strcpy(rm,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavrdm)));
inputavrdm1=lookup_widget(button,"comboboxentrymede13");
strcpy(rm1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavrdm1)));
inputavrdm2=lookup_widget(button,"comboboxentrymede14");
strcpy(rm2,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavrdm2)));
inputavrdm3=lookup_widget(button,"entry7");
strcpy(rm3,gtk_entry_get_text(GTK_ENTRY(inputavrdm3)));
FILE *f55;
f55=fopen("rendez_vous_medecin.txt","a+");
{
fprintf(f55,"%s %s %s %s \n",rm,rm1,rm2,rm3);
}
fclose(f55);
}


void
on_rtrntab_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
gymadvisor=create_gymadvisor();
gtk_widget_show(gymadvisor);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"tabregime")));
}


void
on_rtrnadvice_clicked                  (GtkWidget        *button,
                                        gpointer         user_data)
{
gymadvisor=create_gymadvisor();
gtk_widget_show(gymadvisor);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"advice")));
}

