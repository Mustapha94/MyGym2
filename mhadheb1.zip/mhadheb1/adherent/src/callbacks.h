#include <gtk/gtk.h>


void
on_button1_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_exit_clicked                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_modif_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_dispo_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_return_clicked                      (GtkWidget      *button,
                                        gpointer         user_data);

void
on_retrn_clicked                       (GtkWidget        *button,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_save_clicked                        (GtkWidget        *button,
                                        gpointer         user_data);

void
on_retrnprfil1_clicked                 (GtkWidget    *button,
                                        gpointer         user_data);

void
on_retrnesp1_clicked                   (GtkWidget        *button,
                                        gpointer         user_data);

void
on_retrnesp2_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnprfil2_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnesp3_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_continue1_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonprfil_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttongym_clicked                   (GtkWidget      *button,
                                        gpointer         user_data);

void
on_buttonavis_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonmedi_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttongym1_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttongym2_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttongym3_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttongym4_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttoncal5_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnimc_clicked                    (GtkWidget        *button,
                                        gpointer         user_data);

void
on_buttonrecla2_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonavis3_clicked                 (GtkWidget      *button,
                                        gpointer         user_data);

void
on_retrnreclama_clicked                (GtkWidget        *button,
                                        gpointer         user_data);

void
on_buttonenvoi3_enter                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiobutton1_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiobutton2_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiobutton2officiel_clicked        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiobutton3_clicked                (GtkWidget      *button,
                                        gpointer         user_data);

void
on_radiobutton4_clicked                (GtkWidget      *button,
                                        gpointer         user_data);

void
on_rtrnaviss_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radioc6_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radioc7_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radioc9_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radioc10_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radioc8_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiok6_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiok8_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiok9_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiok10_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiok7_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiomed3_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiomed15_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiomed6_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiomed12_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiomed14_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_prflcoac_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_prflkin_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_prflmede_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_rnd3_clicked                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_rnd2_clicked                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_rnd1_clicked                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrncoa_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnkine1_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_rtrnmede4_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_rndv14_clicked                      (GtkWidget       *button,
                                        gpointer         user_data);

void
on_rndvkine1_clicked                   (GtkWidget     *button,
                                        gpointer         user_data);

void
on_rndvmedecin1_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_rtrntab_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_rtrnadvice_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);
