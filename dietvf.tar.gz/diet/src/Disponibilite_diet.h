#include <gtk/gtk.h>

typedef struct
{

char jour[20];
char debut[20];
char fin[30];

char mois[20];
char annee[20];
char cours[30];


}dispo;

void ajou_disponibilite_diet(dispo p);
void afficher_disponibilite_diet(GtkWidget *list);
