#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "Disponibilite_diet.h"
#include "personne.h"
#include "controle_saisie.h"
GtkWidget *conf_window;
GtkWidget *espace_diet;

void
on_calendar_diet_day_selected_double_click
                                        (GtkCalendar     *calendar,
                                        gpointer         user_data)
{

}


void
on_button_add_agenda_diet_clicked      (GtkButton       *widget,
                                        gpointer         user_data)
{ GtkWidget *combobox_jour_diet;
	GtkWidget *combobox_annee_diet;
	GtkWidget *combobox_mois_diet;
GtkWidget *combobox_debut_diet;
GtkWidget *combobox_fin_diet;
GtkWidget *combobox_cours_diet;

	dispo s;

	combobox_jour_diet=lookup_widget(widget, "combobox_jour_diet");
	combobox_mois_diet=lookup_widget(widget, "combobox_mois_diet");
	combobox_annee_diet=lookup_widget(widget, "combobox_annee_diet");
	combobox_cours_diet=lookup_widget(widget, "combobox_cours_diet");
	combobox_debut_diet=lookup_widget(widget, "combobox_debut_diet");
	combobox_fin_diet=lookup_widget(widget, "combobox_fin_diet");
	

	strcpy(s.jour,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_jour_diet)));
	strcpy(s.mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_mois_diet)));
	strcpy(s.annee,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_annee_diet)));
	strcpy(s.cours,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_cours_diet)));
	
	strcpy(s.debut,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_debut_diet)));
	strcpy(s.fin,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_fin_diet)));

	ajou_disponibilite_diet(s);
GtkWidget *conf_window;

    conf_window = create_conf_window ();
    gtk_widget_show (conf_window);


/****************affichage**************************/
	/*GtkWidget *treeview_agenda_diet;

	espace_diet=lookup_widget(widget,"espace_diet");

	espace_diet=create_espace_diet();
	gtk_widget_show(espace_diet);	
	treeview_agenda_diet=lookup_widget(espace_diet,"treeview_agenda_diet");
	afficher_disponibilite_diet(treeview_agenda_diet);*/
}


void
on_button_chercher_fiche_clicked       (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *treeview_akhaw ;

 espace_diet=create_espace_diet();
gtk_widget_show(espace_diet);
treeview_akhaw=lookup_widget(espace_diet,"treeview_akhaw");

afficher_personne(treeview_akhaw);

   

    
}




void
on_treeview_agenda_diet_show           (GtkWidget       *widget,
                                        gpointer         user_data)
{

}


void
on_ref_diet_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

	GtkWidget *espace_diet;
	GtkWidget *treeview_agenda_diet;

	espace_diet=create_espace_diet();
	gtk_widget_show(espace_diet);	
	treeview_agenda_diet=lookup_widget(espace_diet,"treeview_agenda_diet");
	afficher_disponibilite_diet(treeview_agenda_diet);	
}






void
on_button_sauver_cin_clicked           (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *espace_diet;

espace_diet=create_espace_diet();


GtkWidget *input1 , *input2,*output;


char cin[30];
char regime[300];

input1=lookup_widget(objet_graphique,"entry_cinreg");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input1)));
input2=lookup_widget(objet_graphique,"entry_regime");
strcpy(regime,gtk_entry_get_text(GTK_ENTRY(input2)));

output= lookup_widget(objet_graphique, "labelreg");
 if ((controle_saisie_numero(cin)==0))
{
gtk_label_set_text(GTK_LABEL(output), "veuillez verifier votre saisie !");


}
else{ 
FILE *f;
f=fopen("regime.txt","a+");
fprintf(f,"%s %s \n",cin,regime);
fclose(f);

conf_window=create_conf_window();
gtk_widget_show(conf_window);
}

}

