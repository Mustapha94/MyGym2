#include <gtk/gtk.h>


void
on_calendar_diet_day_selected_double_click
                                        (GtkCalendar     *calendar,
                                        gpointer         user_data);

void
on_button_add_agenda_diet_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_chercher_fiche_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_ref_diet_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_akhaw_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_sauver_cin_clicked           (GtkButton       *button,
                                        gpointer         user_data);
