#include <gtk/gtk.h>

typedef struct
{

char NomPrenom[30];
char datenaiss[10];
char cin[30];
char poids[10];
char Maladie[300];
char Fumeur[10];
char Ancien[30];
char Taille[30];
char alcoolic[30];
char urg[30];
char group[30];



}Personne;

void ajouter_personne(Personne p);
void afficher_personne(GtkWidget *liste);
void sup_specin(char cin[30]);
void modifier(char NomPrenom[30],char datenaiss[10],char cin[30],char poids[10],char Maladie[300],char Fumeur[10],char Ancien[30],char Taille[30],char alcoolic[30],char urg[30],char group[30]);
