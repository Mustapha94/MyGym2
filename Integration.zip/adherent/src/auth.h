int Authent(char login[],char password[]);
