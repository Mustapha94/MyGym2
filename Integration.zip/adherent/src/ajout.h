typedef struct 
{
char cin[20];
char nom[20];
char prenom[20];
char jour[20];
char mois[20];
char annee[20];
char adress[50];
char num[20];
char pass[20];
int role;
}idadh;



