#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif
#include "auth.h"
#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "ajout.h"
#include "imc.h"
#include "fichemed.h"

GtkWidget *espkine;
GtkWidget *modifprfilkine;
GtkWidget *fichemede;
GtkWidget *reclamationkine;
GtkWidget *reclamationrecu;
GtkWidget *reclamationenvoi;
GtkWidget *gestseancecure;
GtkWidget *gestrdvkine;
GtkWidget *prfilkine;
GtkWidget *affichefichemed;
GtkWidget *prfil;
GtkWidget *gymadvisor;
GtkWidget *avisrec;
GtkWidget *fichemed;
GtkWidget *modifprofil;
GtkWidget *espadhrnt;
GtkWidget *succesadherent;
GtkWidget *espagent;
GtkWidget *prfilagent;
GtkWidget *modifprofilagent;
GtkWidget *reclamationagent;
GtkWidget *reclamationrecuagent;
GtkWidget *reclamationenvoiagent;
GtkWidget *horairetravailagent;
GtkWidget *succreclagent;
GtkWidget *failreclagent;

void
on_exit_clicked                        (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *connect;
connect=create_connect();
gtk_widget_show(connect);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"espadhrnt")));
}


void
on_modif_clicked                       (GtkWidget      *button,
                                        gpointer         user_data)
{
idadh A;
char chemin[]="listeadherent.txt";
GtkWidget *modifprofil;

modifprofil=create_modifprofil();
gtk_widget_show(modifprofil);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"prfil")));
int i=1;
FILE*f;
f=fopen(chemin,"a+");
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %d\n",A.cin,A.nom,A.prenom,A.jour,A.mois,A.annee,A.adress,A.num,A.pass,&A.role)!=EOF)
{i++;
}
GtkWidget *inputcin;
GtkWidget *inputnom;
GtkWidget *inputprenom;
GtkWidget *inputadress;
GtkWidget *inputnum;
GtkWidget *inputpass;

GtkWidget *inputjour;
GtkWidget *inputmois;
GtkWidget *inputannee;

inputcin=lookup_widget(modifprofil,"entrycin");
inputnom=lookup_widget(modifprofil,"entry1");
inputprenom=lookup_widget(modifprofil,"entry2");
inputadress=lookup_widget(modifprofil,"entryadress");
inputnum=lookup_widget(modifprofil,"entry3");
inputpass=lookup_widget(modifprofil,"entrypass");

inputjour=lookup_widget(modifprofil,"entryjour");
inputmois=lookup_widget(modifprofil,"entrymois");
inputannee=lookup_widget(modifprofil,"entryannee");
gtk_entry_set_text(GTK_ENTRY(inputcin),A.cin);
gtk_entry_set_text(GTK_ENTRY(inputnom),A.nom);
gtk_entry_set_text(GTK_ENTRY(inputprenom),A.prenom);
gtk_entry_set_text(GTK_ENTRY(inputadress),A.adress);
gtk_entry_set_text(GTK_ENTRY(inputnum),A.num);
gtk_entry_set_text(GTK_ENTRY(inputpass),A.pass);

gtk_entry_set_text(GTK_ENTRY(inputjour),A.jour);
gtk_entry_set_text(GTK_ENTRY(inputmois),A.mois);
gtk_entry_set_text(GTK_ENTRY(inputannee),A.annee);
fclose(f);

}





void
on_save_clicked                        (GtkWidget       *button,
                                        gpointer         user_data)
{
int i=1;
idadh A;
char chemin[]="listeadherent.txt";
succesadherent=create_succesadherent();
gtk_widget_show(succesadherent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"modifprofil")));
GtkWidget *inputcin;
GtkWidget *inputnom;
GtkWidget *inputprenom;
GtkWidget *inputadress;
GtkWidget *inputnum;
GtkWidget *inputpass;

GtkWidget *inputjour;
GtkWidget *inputmois;
GtkWidget *inputannee;

inputcin=lookup_widget(button,"entrycin");
inputnom=lookup_widget(button,"entry1");
inputprenom=lookup_widget(button,"entry2");
inputadress=lookup_widget(button,"entryadress");
inputnum=lookup_widget(button,"entry3");
inputpass=lookup_widget(button,"entrypass");

inputjour=lookup_widget(button,"entryjour");
inputmois=lookup_widget(button,"entrymois");
inputannee=lookup_widget(button,"entryannee");
strcpy(A.cin,gtk_entry_get_text(GTK_ENTRY(inputcin)));
strcpy(A.nom,gtk_entry_get_text(GTK_ENTRY(inputnom)));
strcpy(A.prenom,gtk_entry_get_text(GTK_ENTRY(inputprenom)));
strcpy(A.adress,gtk_entry_get_text(GTK_ENTRY(inputadress)));
strcpy(A.num,gtk_entry_get_text(GTK_ENTRY(inputnum)));
strcpy(A.pass,gtk_entry_get_text(GTK_ENTRY(inputpass)));

strcpy(A.jour,gtk_entry_get_text(GTK_ENTRY(inputjour)));
strcpy(A.mois,gtk_entry_get_text(GTK_ENTRY(inputmois)));
strcpy(A.annee,gtk_entry_get_text(GTK_ENTRY(inputannee)));

FILE*f;
f=fopen(chemin,"a+");

fprintf(f,"%s %s %s %s %s %s %s %s %s %s\n",A.cin,A.nom,A.prenom,A.adress,A.num,A.pass,A.jour,A.mois,A.annee,"2");

fclose(f);


}

void
on_retrnesp3_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{
espadhrnt=create_espadhrnt();
gtk_widget_show(espadhrnt);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"fichemed")));
}

void
on_retrnprfil1_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{
espadhrnt=create_espadhrnt();
gtk_widget_show(espadhrnt);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"prfil")));
}


void
on_retrnesp1_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
espadhrnt=create_espadhrnt();
gtk_widget_show(espadhrnt);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"gymadvisor")));
}


void
on_retrnesp2_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
espadhrnt=create_espadhrnt();
gtk_widget_show(espadhrnt);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"avisrec")));
}

void
on_continue1_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
idadh A;
char chemin[]="listeadherent.txt";
prfil=create_prfil();
gtk_widget_show(prfil);
gtk_widget_destroy(GTK_WIDGET(lookup_widget(button,"succesadherent")));
int i=0;
FILE*f;
f=fopen(chemin,"a+");
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %d\n",A.cin,A.nom,A.prenom,A.jour,A.mois,A.annee,A.adress,A.num,A.pass,&A.role)!=EOF)
{
i++;
}
GtkWidget *labelcin;
GtkWidget *labelnom;
GtkWidget *labelprenom;
GtkWidget *labeladress;
GtkWidget *labelnum;
GtkWidget *labelpass;

GtkWidget *labeljour;
GtkWidget *labelmois;
GtkWidget *labelannee;
labelcin=lookup_widget(prfil,"cin");
labelnom=lookup_widget(prfil,"nom");
labelprenom=lookup_widget(prfil,"prenom");
labeladress=lookup_widget(prfil,"adress");
labelnum=lookup_widget(prfil,"num");
labelpass=lookup_widget(prfil,"pass");

labeljour=lookup_widget(prfil,"jour");
labelmois=lookup_widget(prfil,"mois");
labelannee=lookup_widget(prfil,"annee");
gtk_label_set_text(GTK_LABEL(labelcin),A.cin);
gtk_label_set_text(GTK_LABEL(labelnom),A.nom);
gtk_label_set_text(GTK_LABEL(labelprenom),A.prenom);
gtk_label_set_text(GTK_LABEL(labeladress),A.adress);
gtk_label_set_text(GTK_LABEL(labelnum),A.num);
gtk_label_set_text(GTK_LABEL(labelpass),A.pass);

gtk_label_set_text(GTK_LABEL(labeljour),A.jour);
gtk_label_set_text(GTK_LABEL(labelmois),A.mois);
gtk_label_set_text(GTK_LABEL(labelannee),A.annee);

fclose(f);


}



void
on_buttonprfil_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{
idadh A;
char chemin[]="listeadherent.txt";
prfil=create_prfil();
gtk_widget_show(prfil);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"espadhrnt")));
int i=0;
FILE*f;
f=fopen(chemin,"a+");
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %d\n",A.cin,A.nom,A.prenom,A.jour,A.mois,A.annee,A.adress,A.num,A.pass,&A.role)!=EOF)
{
i++;
}
GtkWidget *labelcin;
GtkWidget *labelnom;
GtkWidget *labelprenom;
GtkWidget *labeladress;
GtkWidget *labelnum;
GtkWidget *labelpass;

GtkWidget *labeljour;
GtkWidget *labelmois;
GtkWidget *labelannee;
labelcin=lookup_widget(prfil,"cin");
labelnom=lookup_widget(prfil,"nom");
labelprenom=lookup_widget(prfil,"prenom");
labeladress=lookup_widget(prfil,"adress");
labelnum=lookup_widget(prfil,"num");
labelpass=lookup_widget(prfil,"pass");

labeljour=lookup_widget(prfil,"jour");
labelmois=lookup_widget(prfil,"mois");
labelannee=lookup_widget(prfil,"annee");
gtk_label_set_text(GTK_LABEL(labelcin),A.cin);
gtk_label_set_text(GTK_LABEL(labelnom),A.nom);
gtk_label_set_text(GTK_LABEL(labelprenom),A.prenom);
gtk_label_set_text(GTK_LABEL(labeladress),A.adress);
gtk_label_set_text(GTK_LABEL(labelnum),A.num);
gtk_label_set_text(GTK_LABEL(labelpass),A.pass);

gtk_label_set_text(GTK_LABEL(labeljour),A.jour);
gtk_label_set_text(GTK_LABEL(labelmois),A.mois);
gtk_label_set_text(GTK_LABEL(labelannee),A.annee);

fclose(f);

}

void
on_buttongym_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *gymadvisor;
gymadvisor=create_gymadvisor();
gtk_widget_show(gymadvisor);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"espadhrnt")));

}

void
on_buttonavis_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *avisrec;
avisrec=create_avisrec();
gtk_widget_show(avisrec);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"espadhrnt")));
}

void
on_buttonmedi_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *fichemed;
fichemed=create_fichemed();
gtk_widget_show(fichemed);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"espadhrnt")));
}


void
on_buttongym1_clicked                  (GtkWidget        *button,
                                        gpointer         user_data)
{
GtkWidget *imc;
imc=create_imc();
gtk_widget_show(imc);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"gymadvisor")));
}


void
on_buttongym2_clicked                  (GtkWidget        *button,
                                        gpointer         user_data)
{

}


void
on_buttongym3_clicked                  (GtkWidget        *button,
                                        gpointer         user_data)
{
GtkWidget *tabregime;
tabregime=create_tabregime();
gtk_widget_show(tabregime);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"gymadvisor")));
}


void
on_buttongym4_clicked                  (GtkWidget        *button,
                                        gpointer         user_data)
{
GtkWidget *advice;
advice=create_advice();
gtk_widget_show(advice);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"gymadvisor")));
GtkWidget *inputadvice;
GtkWidget *inputadvice1;
GtkWidget *inputadvice2;
GtkWidget *inputadvice3;
char adv[40];
float ad;
inputadvice=lookup_widget(advice,"label40");
inputadvice1=lookup_widget(advice,"label41");
inputadvice2=lookup_widget(advice,"label42");
inputadvice3=lookup_widget(advice,"label43");
FILE *f;
f=fopen("liste_imc.txt","r");
while (fscanf(f," %s\n",adv)!=EOF);
ad=(float)atoi(adv);
if (ad<18.5)
{
gtk_label_set_text(GTK_LABEL(inputadvice),"Votre poids apparaît trop faible par rapport à votre taille.");
gtk_label_set_text(GTK_LABEL(inputadvice1),"Ce faible indice de masse corporel (IMC) est peut-être la conséquence d'une pathologie,");
gtk_label_set_text(GTK_LABEL(inputadvice2),"mais elle-même peut exposer à un certain nombre de risques pour votre santé (carences, anémie, ostéoporose...).");
gtk_label_set_text(GTK_LABEL(inputadvice3),"Parlez-en avec votre médecin traitant. Il pourra rechercher la cause de cette maigreur et vous conseiller.");
}
else if ((18.5<ad)&&(ad<24.9))
{
gtk_label_set_text(GTK_LABEL(inputadvice),"Votre poids est adapté à votre taille.");
gtk_label_set_text(GTK_LABEL(inputadvice1),"Gardez vos habitudes alimentaires pour conserver un indice de masse corporel (IMC) idéal et un poids qui vous assure un état de santé optimal.");
gtk_label_set_text(GTK_LABEL(inputadvice2),"Une alimentation équilibrée, sans excès de matières grasses, associée à une activité physique régulière vous aideront à maintenir votre poids idéal.");
}
else if ((25<ad)&&(ad<29.9))
{
gtk_label_set_text(GTK_LABEL(inputadvice),"Votre poids commence à devenir élevé par rapport à votre taille.");
gtk_label_set_text(GTK_LABEL(inputadvice1),"A long terme, un indice de masse corporel (IMC) élevé a des conséquences sur la santé.");
gtk_label_set_text(GTK_LABEL(inputadvice2),"L'excès de poids entraîne un risque accru de maladies métaboliques (diabète), cardiaques, respiratoires, articulaires et de cancer.");
gtk_label_set_text(GTK_LABEL(inputadvice3),"Si vous souhaitez commencer un régime pour perdre du poids, parlez-en au préalable avec votre médecin traitant.");
}
else if (30<ad)
{
gtk_label_set_text(GTK_LABEL(inputadvice),"Votre poids est trop élevé par rapport à votre taille.");
gtk_label_set_text(GTK_LABEL(inputadvice1),"Du point de vue médical, l'obésité est un excès de masse grasse ayant des conséquences sur la santé. ");
gtk_label_set_text(GTK_LABEL(inputadvice2)," L'excès de poids entraîne un risque accru de maladies métaboliques (diabète), cardiaques, respiratoires, articulaires et de cancer. ");
gtk_label_set_text(GTK_LABEL(inputadvice3),"Si vous souhaitez commencer un régime pour perdre du poids, parlez-en au préalable avec votre médecin traitant.");
}
}
void
on_buttoncal5_clicked                  (GtkWidget        *button,
                                        gpointer         user_data)
{
char t[40], p[40];
int ta=0,po=0;
float i;
int j=0;
char k[20];
GtkWidget *calimc;
GtkWidget *inputtaille;
GtkWidget *inputpoids;
GtkWidget *outputimc;
outputimc=lookup_widget(button,"calimc");
inputtaille=lookup_widget(button,"entrytaille5");
inputpoids=lookup_widget(button,"entrypoids6");
strcpy(t,gtk_entry_get_text(GTK_ENTRY(inputtaille)));
strcpy(p,gtk_entry_get_text(GTK_ENTRY(inputpoids)));
ta=(float)atoi(t);
po=(float)atoi(p);
i=imc1(po,ta);
memset(k,0,sizeof(k));
sprintf(k, "%f", i);
gtk_label_set_text(GTK_LABEL(outputimc),k);
FILE *f;
f=fopen("liste_imc.txt","a+");
{
fprintf(f,"%s \n",k);
}
fclose(f);
}

void
on_retrnimc_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
gymadvisor=create_gymadvisor();
gtk_widget_show(gymadvisor);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"imc")));
}


void
on_buttonrecla2_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *reclama;
reclama=create_reclama();
gtk_widget_show(reclama);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"avisrec")));
}

void
on_buttonavis3_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *avis;
avis=create_avis();
gtk_widget_show(avis);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"avisrec")));
}


void
on_retrnreclama_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
avisrec=create_avisrec();
gtk_widget_show(avisrec);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclama")));
}


void
on_buttonenvoi3_enter                  (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputreclama;
GtkWidget *inputrc;
GtkWidget *inputrca;
char rc[40],dsc[100],ca[20];
inputreclama=lookup_widget(button,"comboboxentryrecla6");
strcpy(rc,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputreclama)));
inputrc=lookup_widget(button,"entryrec5");
strcpy(dsc,gtk_entry_get_text(GTK_ENTRY(inputrc)));
inputrca=lookup_widget(button,"entrycin77");
strcpy(ca,gtk_entry_get_text(GTK_ENTRY(inputrca)));
if (strcmp(rc,"admin")==0)
{
FILE *f1;
f1=fopen("recla_admin.txt","a+");
fprintf(f1,"%s %s \n",ca,dsc);
fclose(f1);
}
else if (strcmp(rc,"kine")==0)
{
FILE *f2;
f2=fopen("recla_kine.txt","a+");
fprintf(f2,"%s %s \n",ca,dsc);
fclose(f2);
}
else if (strcmp(rc,"docteur")==0)
{
FILE *f3;
f3=fopen("recla_docteur.txt","a+");
fprintf(f3,"%s %s \n",ca,dsc);
fclose(f3);
}
else if (strcmp(rc,"coach")==0)
{
FILE *f4;
f4=fopen("recla_coach.txt","a+");
fprintf(f4,"%s %s \n",ca,dsc);
fclose(f4);
}
avisrec=create_avisrec();
gtk_widget_show(avisrec);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclama")));
}



void
on_radiobutton1_clicked                (GtkWidget        *button,
                                        gpointer         user_data)
{
FILE *f6;
f6=fopen("avis.txt","a+");
{
fprintf(f6,"%s \n","1");
}
fclose(f6);
}


void
on_radiobutton2_clicked                (GtkWidget        *button,
                                        gpointer         user_data)
{
FILE *f6;
f6=fopen("avis.txt","a+");
{
fprintf(f6,"%s \n","5");
}
fclose(f6);
}


void
on_radiobutton2officiel_clicked        (GtkWidget       *button,
                                        gpointer         user_data)
{
FILE *f6;
f6=fopen("avis.txt","a+");
{
fprintf(f6,"%s \n","2");
}
fclose(f6);
}


void
on_radiobutton3_clicked                (GtkWidget      *button,
                                        gpointer         user_data)
{
FILE *f6;
f6=fopen("avis.txt","a+");
{
fprintf(f6,"%s \n","3");
}
fclose(f6);
}


void
on_radiobutton4_clicked                (GtkWidget      *button,
                                        gpointer         user_data)
{
FILE *f6;
f6=fopen("avis.txt","a+");
{
fprintf(f6,"%s \n","4");
}
fclose(f6);
}


void
on_rtrnaviss_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
avisrec=create_avisrec();
gtk_widget_show(avisrec);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"avis")));
}


void
on_radioc6_clicked                     (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *inputavco;
char co[20];
inputavco=lookup_widget(button,"comboboxentrycoach1");
strcpy(co,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavco)));
FILE *f7;
f7=fopen("aviscoach.txt","a+");
{
fprintf(f7,"%s %s \n",co,"1");
}
fclose(f7);
}


void
on_radioc7_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputavcoa;
char coa[20];
inputavcoa=lookup_widget(button,"comboboxentrycoach1");
strcpy(coa,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavcoa)));
FILE *f7;
f7=fopen("aviscoach.txt","a+");
{
fprintf(f7,"%s %s \n",coa,"2");
}
fclose(f7);
}

void
on_radioc9_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputavco1;
char co1[20];
inputavco1=lookup_widget(button,"comboboxentrycoach1");
strcpy(co1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavco1)));
FILE *f7;
f7=fopen("aviscoach.txt","a+");
{
fprintf(f7,"%s %s \n",co1,"4");
}
fclose(f7);
}


void
on_radioc10_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputavcoa1;
char coa1[20];
inputavcoa1=lookup_widget(button,"comboboxentrycoach1");
strcpy(coa1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavcoa1)));
FILE *f7;
f7=fopen("aviscoach.txt","a+");
{
fprintf(f7,"%s %s \n",coa1,"5");
}
fclose(f7);
}


void
on_radioc8_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputavc;
char c[20];
inputavc=lookup_widget(button,"comboboxentrycoach1");
strcpy(c,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavc)));
FILE *f7;
f7=fopen("aviscoach.txt","a+");
{
fprintf(f7,"%s %s \n",c,"3");
}
fclose(f7);
}


void
on_radiok6_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputavki;
char ki[20];
inputavki=lookup_widget(button,"comboboxentrykine1");
strcpy(ki,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavki)));
FILE *f8;
f8=fopen("aviskine.txt","a+");
{
fprintf(f8,"%s %s \n",ki,"1");
}
fclose(f8);
}


void
on_radiok8_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputavkin;
char ki1[20];
inputavkin=lookup_widget(button,"comboboxentrykine1");
strcpy(ki1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavkin)));
FILE *f8;
f8=fopen("aviskine.txt","a+");
{
fprintf(f8,"%s %s \n",ki1,"3");
}
fclose(f8);
}

void
on_radiok9_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputavki1;
char kin[20];
inputavki1=lookup_widget(button,"comboboxentrykine1");
strcpy(kin,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavki1)));
FILE *f8;
f8=fopen("aviskine.txt","a+");
{
fprintf(f8,"%s %s \n",kin,"4");
}
fclose(f8);
}


void
on_radiok10_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputavkine;
char kin1[20];
inputavkine=lookup_widget(button,"comboboxentrykine1");
strcpy(kin1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavkine)));
FILE *f8;
f8=fopen("aviskine.txt","a+");
{
fprintf(f8,"%s %s \n",kin1,"5");
}
fclose(f8);
}


void
on_radiok7_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputavk;
char k[20];
inputavk=lookup_widget(button,"comboboxentrykine1");
strcpy(k,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavk)));
FILE *f8;
f8=fopen("aviskine.txt","a+");
{
fprintf(f8,"%s %s \n",k,"2");
}
fclose(f8);
}


void
on_radiomed3_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputamed;
char med[20];
inputamed=lookup_widget(button,"comboboxentrymedc1");
strcpy(med,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputamed)));
FILE *f9;
f9=fopen("avismedecin.txt","a+");
{
fprintf(f9,"%s %s \n",med,"2");
}
fclose(f9);
}


void
on_radiomed15_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputame;
char me[20];
inputame=lookup_widget(button,"comboboxentrymedc1");
strcpy(me,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputame)));
FILE *f9;
f9=fopen("avismedecin.txt","a+");
{
fprintf(f9,"%s %s \n",me,"4");
}
fclose(f9);
}


void
on_radiomed6_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputamede;
char mede[20];
inputamede=lookup_widget(button,"comboboxentrymedc1");
strcpy(mede,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputamede)));
FILE *f9;
f9=fopen("avismedecin.txt","a+");
{
fprintf(f9,"%s %s \n",mede,"5");
}
fclose(f9);
}


void
on_radiomed12_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputamedec;
char medec[20];
inputamedec=lookup_widget(button,"comboboxentrymedc1");
strcpy(medec,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputamedec)));
FILE *f9;
f9=fopen("avismedecin.txt","a+");
{
fprintf(f9,"%s %s \n",medec,"1");
}
fclose(f9);
}


void
on_radiomed14_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *inputam;
char m[20];
inputam=lookup_widget(button,"comboboxentrymedc1");
strcpy(m,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputam)));
FILE *f9;
f9=fopen("avismedecin.txt","a+");
{
fprintf(f9,"%s %s \n",m,"3");
}
fclose(f9);
}


void
on_prflcoac_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *prflcoach;
prflcoach=create_prflcoach();
gtk_widget_show(prflcoach);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"fichemed")));
GtkWidget *inputprfc;
GtkWidget *inputprfc1;
GtkWidget *inputprfc2;
GtkWidget *inputprfc3;
GtkWidget *inputprfc4;
GtkWidget *inputprfc5;
char prf[40],nomcoa[40],prenomco[40],numcoa[40],mailcoac[40],specia[40];
inputprfc=lookup_widget(button,"comboboxentrycoa9");
strcpy(prf,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputprfc)));
if (strcmp(prf,"coach1")==0)
{
FILE *f20;
f20=fopen("coach1.txt","r");
if(f20!=NULL)
{while (fscanf(f20,"%s %s %s %s %s\n",nomcoa,prenomco,numcoa,mailcoac,specia)!=EOF)
inputprfc1=lookup_widget(prflcoach,"nomc1");
inputprfc2=lookup_widget(prflcoach,"prenoc1");
inputprfc3=lookup_widget(prflcoach,"telcoach");
inputprfc4=lookup_widget(prflcoach,"emaic");
inputprfc5=lookup_widget(prflcoach,"spec1");
gtk_label_set_text(GTK_LABEL(inputprfc5),specia);
gtk_label_set_text(GTK_LABEL(inputprfc1),nomcoa);
gtk_label_set_text(GTK_LABEL(inputprfc2),prenomco);
gtk_label_set_text(GTK_LABEL(inputprfc3),numcoa);
gtk_label_set_text(GTK_LABEL(inputprfc4),mailcoac);
}
}
else if (strcmp(prf,"coach2")==0)
{
FILE *f24;
f24=fopen("coach2.txt","r");
if(f24!=NULL)
{while (fscanf(f24,"%s %s %s %s %s\n",nomcoa,prenomco,numcoa,mailcoac,specia)!=EOF)
inputprfc1=lookup_widget(prflcoach,"nomc1");
inputprfc2=lookup_widget(prflcoach,"prenoc1");
inputprfc3=lookup_widget(prflcoach,"telcoach");
inputprfc4=lookup_widget(prflcoach,"emaic");
inputprfc5=lookup_widget(prflcoach,"spec1");
gtk_label_set_text(GTK_LABEL(inputprfc5),specia);
gtk_label_set_text(GTK_LABEL(inputprfc1),nomcoa);
gtk_label_set_text(GTK_LABEL(inputprfc2),prenomco);
gtk_label_set_text(GTK_LABEL(inputprfc3),numcoa);
gtk_label_set_text(GTK_LABEL(inputprfc4),mailcoac);
}
}
else if (strcmp(prf,"coach3")==0)
{
FILE *f25;
f25=fopen("coach3.txt","r");
if(f25!=NULL)
{while (fscanf(f25,"%s %s %s %s %s\n",nomcoa,prenomco,numcoa,mailcoac,specia)!=EOF)
inputprfc1=lookup_widget(prflcoach,"nomc1");
inputprfc2=lookup_widget(prflcoach,"prenoc1");
inputprfc3=lookup_widget(prflcoach,"telcoach");
inputprfc4=lookup_widget(prflcoach,"emaic");
inputprfc5=lookup_widget(prflcoach,"spec1");
gtk_label_set_text(GTK_LABEL(inputprfc5),specia);
gtk_label_set_text(GTK_LABEL(inputprfc1),nomcoa);
gtk_label_set_text(GTK_LABEL(inputprfc2),prenomco);
gtk_label_set_text(GTK_LABEL(inputprfc3),numcoa);
gtk_label_set_text(GTK_LABEL(inputprfc4),mailcoac);
}
}
}

void
on_prflkin_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *prflkine;
prflkine=create_prflkine();
gtk_widget_show(prflkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"fichemed")));
GtkWidget *inputprfk;
GtkWidget *inputprfk1;
GtkWidget *inputprfk2;
GtkWidget *inputprfk3;
GtkWidget *inputprfk4;
GtkWidget *inputprfk5;
char prfk[40],nomk[40],prenomk[40],numk[40],mailki[40],speciak[40];
inputprfk=lookup_widget(button,"comboboxentryki10");
strcpy(prfk,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputprfk)));
if (strcmp(prfk,"kine1")==0)
{
FILE *f21;
f21=fopen("kine1.txt","r");
if(f21!=NULL)
{while (fscanf(f21,"%s %s %s %s %s\n",nomk,prenomk,numk,mailki,speciak)!=EOF)
inputprfk1=lookup_widget(prflkine,"nomki1");
inputprfk2=lookup_widget(prflkine,"prenki1");
inputprfk3=lookup_widget(prflkine,"numkin1");
inputprfk4=lookup_widget(prflkine,"mailkin1");
inputprfk5=lookup_widget(prflkine,"seckin");
gtk_label_set_text(GTK_LABEL(inputprfk5),speciak);
gtk_label_set_text(GTK_LABEL(inputprfk1),nomk);
gtk_label_set_text(GTK_LABEL(inputprfk2),prenomk);
gtk_label_set_text(GTK_LABEL(inputprfk3),numk);
gtk_label_set_text(GTK_LABEL(inputprfk4),mailki);
}
}
else if (strcmp(prfk,"kine2")==0)
{
FILE *f22;
f22=fopen("kine2.txt","r");
if(f22!=NULL)
{while (fscanf(f22,"%s %s %s %s %s\n",nomk,prenomk,numk,mailki,speciak)!=EOF)
inputprfk1=lookup_widget(prflkine,"nomki1");
inputprfk2=lookup_widget(prflkine,"prenki1");
inputprfk3=lookup_widget(prflkine,"numkin1");
inputprfk4=lookup_widget(prflkine,"mailkin1");
inputprfk5=lookup_widget(prflkine,"seckin");
gtk_label_set_text(GTK_LABEL(inputprfk5),speciak);
gtk_label_set_text(GTK_LABEL(inputprfk1),nomk);
gtk_label_set_text(GTK_LABEL(inputprfk2),prenomk);
gtk_label_set_text(GTK_LABEL(inputprfk3),numk);
gtk_label_set_text(GTK_LABEL(inputprfk4),mailki);
}
}
else if (strcmp(prfk,"kine3")==0)
{
FILE *f23;
f23=fopen("kine3.txt","r");
if(f23!=NULL)
{while (fscanf(f23,"%s %s %s %s %s\n",nomk,prenomk,numk,mailki,speciak)!=EOF)
inputprfk1=lookup_widget(prflkine,"nomki1");
inputprfk2=lookup_widget(prflkine,"prenki1");
inputprfk3=lookup_widget(prflkine,"numkin1");
inputprfk4=lookup_widget(prflkine,"mailkin1");
inputprfk5=lookup_widget(prflkine,"seckin");
gtk_label_set_text(GTK_LABEL(inputprfk5),speciak);
gtk_label_set_text(GTK_LABEL(inputprfk1),nomk);
gtk_label_set_text(GTK_LABEL(inputprfk2),prenomk);
gtk_label_set_text(GTK_LABEL(inputprfk3),numk);
gtk_label_set_text(GTK_LABEL(inputprfk4),mailki);
}
}
}


void
on_prflmede_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *prflmedecin;
prflmedecin=create_prflmedecin();
gtk_widget_show(prflmedecin);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"fichemed")));
GtkWidget *inputprfm;
GtkWidget *inputprfm1;
GtkWidget *inputprfm2;
GtkWidget *inputprfm3;
GtkWidget *inputprfm4;
GtkWidget *inputprfm5;
char prfm[40],nomm[40],prenomm[40],numm[40],mailm[40],speciam[40];
inputprfm=lookup_widget(button,"comboboxentrymed11");
strcpy(prfm,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputprfm)));
if (strcmp(prfm,"medecin1")==0)
{
FILE *f30;
f30=fopen("medecin1.txt","r");
if(f30!=NULL)
{while (fscanf(f30,"%s %s %s %s %s\n",nomm,prenomm,numm,mailm,speciam)!=EOF)
inputprfm1=lookup_widget(prflmedecin,"nommed1");
inputprfm2=lookup_widget(prflmedecin,"prenommede2");
inputprfm3=lookup_widget(prflmedecin,"nummedecin1");
inputprfm4=lookup_widget(prflmedecin,"mailmede3");
inputprfm5=lookup_widget(prflmedecin,"specmede5");
gtk_label_set_text(GTK_LABEL(inputprfm5),speciam);
gtk_label_set_text(GTK_LABEL(inputprfm1),nomm);
gtk_label_set_text(GTK_LABEL(inputprfm2),prenomm);
gtk_label_set_text(GTK_LABEL(inputprfm3),numm);
gtk_label_set_text(GTK_LABEL(inputprfm4),mailm);
}
}
else if (strcmp(prfm,"medecin2")==0)
{
FILE *f31;
f31=fopen("medecin2.txt","r");
if(f31!=NULL)
{while (fscanf(f31,"%s %s %s %s %s\n",nomm,prenomm,numm,mailm,speciam)!=EOF)
inputprfm1=lookup_widget(prflmedecin,"nommed1");
inputprfm2=lookup_widget(prflmedecin,"prenommede2");
inputprfm3=lookup_widget(prflmedecin,"nummedecin1");
inputprfm4=lookup_widget(prflmedecin,"mailmede3");
inputprfm5=lookup_widget(prflmedecin,"specmede5");
gtk_label_set_text(GTK_LABEL(inputprfm5),speciam);
gtk_label_set_text(GTK_LABEL(inputprfm1),nomm);
gtk_label_set_text(GTK_LABEL(inputprfm2),prenomm);
gtk_label_set_text(GTK_LABEL(inputprfm3),numm);
gtk_label_set_text(GTK_LABEL(inputprfm4),mailm);
}
}
else if (strcmp(prfm,"medecin3")==0)
{
FILE *f32;
f32=fopen("kine3.txt","r");
if(f32!=NULL)
{while (fscanf(f32,"%s %s %s %s %s\n",nomm,prenomm,numm,mailm,speciam)!=EOF)
inputprfm1=lookup_widget(prflmedecin,"nommed1");
inputprfm2=lookup_widget(prflmedecin,"prenommede2");
inputprfm3=lookup_widget(prflmedecin,"nummedecin1");
inputprfm4=lookup_widget(prflmedecin,"mailmede3");
inputprfm5=lookup_widget(prflmedecin,"specmede5");
gtk_label_set_text(GTK_LABEL(inputprfm5),speciam);
gtk_label_set_text(GTK_LABEL(inputprfm1),nomm);
gtk_label_set_text(GTK_LABEL(inputprfm2),prenomm);
gtk_label_set_text(GTK_LABEL(inputprfm3),numm);
gtk_label_set_text(GTK_LABEL(inputprfm4),mailm);
}
}
}


void
on_rnd3_clicked                        (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *rndvmedecin;
rndvmedecin=create_rndvmedecin();
gtk_widget_show(rndvmedecin);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"fichemed")));
}


void
on_rnd2_clicked                        (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *rndvkine;
rndvkine=create_rndvkine();
gtk_widget_show(rndvkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"fichemed")));
}
void
on_rnd1_clicked                        (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *rndvcoach;
rndvcoach=create_rndvcoach();
gtk_widget_show(rndvcoach);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"fichemed")));
}


void
on_retrncoa_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
fichemed=create_fichemed();
gtk_widget_show(fichemed);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"prflcoach")));
}


void
on_retrnkine1_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
fichemed=create_fichemed();
gtk_widget_show(fichemed);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"prflkine")));
}


void
on_rtrnmede4_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
fichemed=create_fichemed();
gtk_widget_show(fichemed);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"prflmedecin")));
}


void
on_rndv14_clicked                      (GtkWidget       *button,
                                        gpointer         user_data)
{
fichemed=create_fichemed();
gtk_widget_show(fichemed);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"rndvcoach")));
GtkWidget *inputavrd;
GtkWidget *inputavrd1;
GtkWidget *inputavrd2;
GtkWidget *inputavrd3;
GtkWidget *inputavrd4;
char rd[20],rd1[20],rd2[20],rd3[200],rd4[10];
inputavrd=lookup_widget(button,"comboboxentrycoach16");
strcpy(rd,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavrd)));
inputavrd1=lookup_widget(button,"comboboxentryjour17");
strcpy(rd1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavrd1)));
inputavrd2=lookup_widget(button,"comboboxentryheure18");
strcpy(rd2,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavrd2)));
inputavrd3=lookup_widget(button,"entry5");
strcpy(rd3,gtk_entry_get_text(GTK_ENTRY(inputavrd3)));
inputavrd4=lookup_widget(button,"entry1cin0");
strcpy(rd4,gtk_entry_get_text(GTK_ENTRY(inputavrd4)));
FILE *f40;
f40=fopen("rendez_vous_coach.txt","a+");
{
fprintf(f40,"%s %s %s %s %s \n",rd4,rd,rd1,rd2,rd3);
}
fclose(f40);
}



void
on_rndvkine1_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
fichemed=create_fichemed();
gtk_widget_show(fichemed);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"rndvkine")));
GtkWidget *inputavrdki;
GtkWidget *inputavrdki1;
GtkWidget *inputavrdki2;
GtkWidget *inputavrdki3;
GtkWidget *inputavrdki4;
char rdk[20],rdk1[20],rdk2[20],rdk3[200],rdk4[10];
inputavrdki=lookup_widget(button,"comboboxentrykine19");
strcpy(rdk,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavrdki)));
inputavrdki1=lookup_widget(button,"comboboxentryjkine10");
strcpy(rdk1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavrdki1)));
inputavrdki2=lookup_widget(button,"comboboxentry11");
strcpy(rdk2,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavrdki2)));
inputavrdki3=lookup_widget(button,"entry6");
strcpy(rdk3,gtk_entry_get_text(GTK_ENTRY(inputavrdki3)));
inputavrdki4=lookup_widget(button,"entrycin19");
strcpy(rdk4,gtk_entry_get_text(GTK_ENTRY(inputavrdki4)));
FILE *f50;
f50=fopen("rendez_vous_kine.txt","a+");
{
fprintf(f50,"%s %s %s %s %s \n",rdk4,rdk,rdk1,rdk2,rdk3);
}
fclose(f50);
}


void
on_rndvmedecin1_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
fichemed=create_fichemed();
gtk_widget_show(fichemed);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"rndvmedecin")));
GtkWidget *inputavrdm;
GtkWidget *inputavrdm1;
GtkWidget *inputavrdm2;
GtkWidget *inputavrdm3;
GtkWidget *inputavrdm4;
char rm[20],rm1[20],rm2[20],rm3[200],rm4[10];
inputavrdm=lookup_widget(button,"comboboxentrymede12");
strcpy(rm,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavrdm)));
inputavrdm1=lookup_widget(button,"comboboxentrymede13");
strcpy(rm1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavrdm1)));
inputavrdm2=lookup_widget(button,"comboboxentrymede14");
strcpy(rm2,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputavrdm2)));
inputavrdm3=lookup_widget(button,"entry7");
strcpy(rm3,gtk_entry_get_text(GTK_ENTRY(inputavrdm3)));
inputavrdm4=lookup_widget(button,"votrecin1");
strcpy(rm4,gtk_entry_get_text(GTK_ENTRY(inputavrdm4)));
FILE *f55;
f55=fopen("rendez_vous_medecin.txt","a+");
{
fprintf(f55,"%s %s %s %s %s\n",rm4,rm,rm1,rm2,rm3);
}
fclose(f55);
}


void
on_rtrntab_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
gymadvisor=create_gymadvisor();
gtk_widget_show(gymadvisor);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"tabregime")));
}


void
on_rtrnadvice_clicked                  (GtkWidget        *button,
                                        gpointer         user_data)
{
gymadvisor=create_gymadvisor();
gtk_widget_show(gymadvisor);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"advice")));
}




void
on_retrn1111_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{

idadh A;
char chemin[]="listeadherent.txt";
prfil=create_prfil();
gtk_widget_show(prfil);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"modifprofil")));
int i=0;
FILE*f;
f=fopen(chemin,"a+");
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %d\n",A.cin,A.nom,A.prenom,A.jour,A.mois,A.annee,A.adress,A.num,A.pass,&A.role)!=EOF)
{
i++;
}
GtkWidget *labelcin;
GtkWidget *labelnom;
GtkWidget *labelprenom;
GtkWidget *labeladress;
GtkWidget *labelnum;
GtkWidget *labelpass;

GtkWidget *labeljour;
GtkWidget *labelmois;
GtkWidget *labelannee;
labelcin=lookup_widget(prfil,"cin");
labelnom=lookup_widget(prfil,"nom");
labelprenom=lookup_widget(prfil,"prenom");
labeladress=lookup_widget(prfil,"adress");
labelnum=lookup_widget(prfil,"num");
labelpass=lookup_widget(prfil,"pass");

labeljour=lookup_widget(prfil,"jour");
labelmois=lookup_widget(prfil,"mois");
labelannee=lookup_widget(prfil,"annee");
gtk_label_set_text(GTK_LABEL(labelcin),A.cin);
gtk_label_set_text(GTK_LABEL(labelnom),A.nom);
gtk_label_set_text(GTK_LABEL(labelprenom),A.prenom);
gtk_label_set_text(GTK_LABEL(labeladress),A.adress);
gtk_label_set_text(GTK_LABEL(labelnum),A.num);
gtk_label_set_text(GTK_LABEL(labelpass),A.pass);

gtk_label_set_text(GTK_LABEL(labeljour),A.jour);
gtk_label_set_text(GTK_LABEL(labelmois),A.mois);
gtk_label_set_text(GTK_LABEL(labelannee),A.annee);

fclose(f);

}


void
on_login_clicked                       (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *login1;
GtkWidget *mdp1;
GtkWidget *verif;
int t;
char v[20],mdp[20],login[20];
espadhrnt=create_espadhrnt();
espkine=create_espkine();
espagent=create_espagent();
login1=lookup_widget(button,"entryid");
mdp1=lookup_widget(button,"entrypass");
verif=lookup_widget(button,"error");
strcpy(login,gtk_entry_get_text(GTK_ENTRY(login1)));
strcpy(mdp,gtk_entry_get_text(GTK_ENTRY(mdp1)));
t=Authent(login,mdp);
switch (t)
{case -1 : strcpy(v,"-1");break;

case 2 : strcpy(v,"Adhérent");
gtk_widget_show(espadhrnt);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"connect")));

break;
case 4 : strcpy(v,"Kinésithérapeute");
gtk_widget_show(espkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"connect")));
break;
case 6 : strcpy(v,"Agent de Nétoyage");
gtk_widget_show(espagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"connect")));
default : break;
}
gtk_label_set_text(GTK_LABEL(verif),v);
}







void
on_exit1_clicked                       (GtkWidget       *button,
                                        gpointer         user_data)
{
gtk_main_quit();
}

void
on_fichemed_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{

GtkWidget *treeview1;


fichemede=lookup_widget(button,"fichemede");
fichemede=create_fichemede();
gtk_widget_show(fichemede);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"espkine")));
treeview1=lookup_widget(fichemede,"treeviewfichemed");
afficher_fichemed(treeview1);

}


void
on_gestcure_clicked                    (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1;

gestseancecure=lookup_widget(button,"gestseancecure");
gestseancecure=create_gestseancecure();
gtk_widget_show(gestseancecure);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"espkine")));
treeview1=lookup_widget(gestseancecure,"treeviewadherent");
afficher_adherents(treeview1);

}

void
on_savekine_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
id A;

char chemin[]="listekine.txt";

espkine=create_espkine();
gtk_widget_show(espkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"modifprfilkine")));
GtkWidget *labelnom;
GtkWidget *labelprenom;
GtkWidget *labelCIN;
GtkWidget *labeljour;
GtkWidget *labelmois;
GtkWidget *labelannee;
GtkWidget *labeladress;
GtkWidget *labelnum;
GtkWidget *labelpass;
GtkWidget *labelrole;
int i=1;

labelnom=lookup_widget(button,"nomkine");
labelprenom=lookup_widget(button,"prenomkine");
labeljour=lookup_widget(button,"jourkine");
labelmois=lookup_widget(button,"moiskine");
labelannee=lookup_widget(button,"anneekine");
labeladress=lookup_widget(button,"adresskine");
labelnum=lookup_widget(button,"numkine");
labelCIN=lookup_widget(button,"cinkine");
labelpass=lookup_widget(button,"passkine");

strcpy(A.nom,gtk_label_get_text(GTK_LABEL(labelnom)));
strcpy(A.prenom,gtk_label_get_text(GTK_LABEL(labelprenom)));
strcpy(A.cin,gtk_label_get_text(GTK_LABEL(labelCIN)));
strcpy(A.jour,gtk_label_get_text(GTK_LABEL(labeljour)));
strcpy(A.mois,gtk_label_get_text(GTK_LABEL(labelmois)));
strcpy(A.annee,gtk_label_get_text(GTK_LABEL(labelannee)));
strcpy(A.adress,gtk_entry_get_text(GTK_ENTRY(labeladress)));
strcpy(A.num,gtk_entry_get_text(GTK_ENTRY(labelnum)));
strcpy(A.pass,gtk_entry_get_text(GTK_ENTRY(labelpass)));
FILE*f;
f=fopen(chemin,"a+");
fprintf(f,"%s %s %s %s %s %s %s %s %s 4 \n",A.cin,A.nom,A.prenom,A.jour,A.mois,A.annee,A.adress,A.num,A.pass);
fclose(f);
}


void
on_retrnespkine2_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *espkine;
espkine=create_espkine();
gtk_widget_show(espkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"fichemede")));
}


void
on_retrnespkine3_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *espkine;
espkine=create_espkine();
gtk_widget_show(espkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationkine")));
}


void
on_reclmtionrecu_clicked               (GtkWidget     *button,
                                        gpointer         user_data)
{
GtkWidget *reclamationrecu;
reclamationrecu=create_reclamationrecu();
gtk_widget_show(reclamationrecu);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationkine")));
int i=1;
char chemin[]="recla_kine.txt";
GtkWidget *labelrecu;
char cont[300];
FILE*f;
f=fopen(chemin,"a+");
while(fscanf(f,"%s \n",cont)!=EOF)
{
i++;
}
labelrecu=lookup_widget(reclamationrecu,"labelcontenureclrecu");
gtk_label_set_text(GTK_LABEL(labelrecu),cont);
fclose(f);

}


void
on_reclmtionenvoi_clicked              (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *reclamationenvoi;
reclamationenvoi=create_reclamationenvoi();
gtk_widget_show(reclamationenvoi);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationkine")));
}


void
on_retrnrecl_clicked                   (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *reclamationkine;
reclamationkine=create_reclamationkine();
gtk_widget_show(reclamationkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationrecu")));
}


void
on_envoirecl_clicked                   (GtkWidget    *button,
                                        gpointer         user_data)
{
GtkWidget *inputreclama;
GtkWidget *inputdest;
char dest[40],cont[100];
inputreclama=lookup_widget(button,"comboboxentryrecl");
strcpy(dest,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputreclama)));
inputdest=lookup_widget(button,"entryreclenvoi");
strcpy(cont,gtk_entry_get_text(GTK_ENTRY(inputdest)));
if (strcmp(dest,"Agent de Nétoyage")==0)
{
FILE *f1;
f1=fopen("recla_agentnet.txt","a+");
fprintf(f1,"%s \n",cont);
fclose(f1);
}
else if (strcmp(dest,"Coach")==0)
{
FILE *f2;
f2=fopen("recla_coach.txt","a+");
fprintf(f2,"%s \n",cont);
fclose(f2);
}
else if (strcmp(dest,"Kinésithérapeute")==0)
{
FILE *f3;
f3=fopen("recla_kine.txt","a+");
fprintf(f3,"%s \n",cont);
fclose(f3);
}
else if (strcmp(dest,"Diététicien")==0)
{
FILE *f4;
f4=fopen("recla_diet.txt","a+");
fprintf(f4,"%s \n",cont);
fclose(f4);
}
else if (strcmp(dest,"Médecin Nutritioniste")==0)
{
FILE *f5;
f5=fopen("recla_docteur.txt","a+");
fprintf(f5,"%s \n",cont);
fclose(f5);
}
if (cont != " " && dest != " ")
{
GtkWidget *succreclenvoi;
succreclenvoi=create_succreclenvoi();
gtk_widget_show(succreclenvoi);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationenvoi")));
}
else
{
GtkWidget *failenvoirec;
failenvoirec=create_failenvoirec();
gtk_widget_show(failenvoirec);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationenvoi")));
}

}


void
on_retrnespkine4_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *espkine;
espkine=create_espkine();
gtk_widget_show(espkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"gestseancecure")));
}


void
on_retrngestcure_clicked               (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
GtkWidget *gestseancecure;
gestseancecure=create_gestseancecure();
gtk_widget_show(gestseancecure);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"gestrdvkine")));
treeview1=lookup_widget(gestseancecure,"treeviewadherent");
afficher_adherents(treeview1);
}


void
on_retrnespkine5_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *espkine;
espkine=create_espkine();
gtk_widget_show(espkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"prfilkine")));
}


void
on_modifprfil_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
id A;
char chemin[]="listekine.txt";

GtkWidget *modifprfilkine;
modifprfilkine=create_modifprfilkine();
gtk_widget_show(modifprfilkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"prfilkine")));
int i=1;

FILE*f;
f=fopen(chemin,"a+");

while(fscanf(f,"%s %s %s %s %s %s %s %s %s %d\n",A.cin,A.nom,A.prenom,A.jour,A.mois,A.annee,A.adress,A.num,A.pass,&A.role)!=EOF)
{i++;
}
GtkWidget *labelnom;
GtkWidget *labelprenom;
GtkWidget *labelCIN;
GtkWidget *labeljour;
GtkWidget *labelmois;
GtkWidget *labelannee;
GtkWidget *labeladress;
GtkWidget *labelnum;
GtkWidget *labelpass;
GtkWidget *labelrole;

labelnom=lookup_widget(modifprfilkine,"nomkine");
labelprenom=lookup_widget(modifprfilkine,"prenomkine");
labeljour=lookup_widget(modifprfilkine,"jourkine");
labelmois=lookup_widget(modifprfilkine,"moiskine");
labelannee=lookup_widget(modifprfilkine,"anneekine");
labeladress=lookup_widget(modifprfilkine,"adresskine");
labelnum=lookup_widget(modifprfilkine,"numkine");
labelCIN=lookup_widget(modifprfilkine,"CINkine");
labelpass=lookup_widget(modifprfilkine,"passkine");

gtk_label_set_text(GTK_LABEL(labelnom),A.nom);
gtk_label_set_text(GTK_LABEL(labelprenom),A.prenom);
gtk_label_set_text(GTK_LABEL(labelCIN),A.cin);
gtk_label_set_text(GTK_LABEL(labeljour),A.jour);
gtk_label_set_text(GTK_LABEL(labelmois),A.mois);
gtk_label_set_text(GTK_LABEL(labelannee),A.annee);
gtk_entry_set_text(GTK_ENTRY(labeladress),A.adress);
gtk_entry_set_text(GTK_ENTRY(labelnum),A.num);
gtk_entry_set_text(GTK_ENTRY(labelpass),A.pass);

fclose(f);


}


void
on_horairetravailkine_clicked          (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *horairetravail;
horairetravail=create_horairetravail();
gtk_widget_show(horairetravail);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"espkine")));
}


void
on_prfilkine_clicked                   (GtkWidget      *button,
                                        gpointer         user_data)
{
id A;

char chemin[]="listekine.txt";
GtkWidget *prfilkine;
prfilkine=create_prfilkine();
gtk_widget_show(prfilkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"espkine")));
GtkWidget *labelnom;
GtkWidget *labelprenom;
GtkWidget *labelCIN;
GtkWidget *labeljour;
GtkWidget *labelmois;
GtkWidget *labelannee;
GtkWidget *labeladress;
GtkWidget *labelnum;
GtkWidget *labelpass;
GtkWidget *labelrole;
int i=1;
FILE*f;
f=fopen(chemin,"a+");
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %d\n",A.cin,A.nom,A.prenom,A.jour,A.mois,A.annee,A.adress,A.num,A.pass,&A.role)!=EOF)
{

}
labelnom=lookup_widget(prfilkine,"nomkine");
labelprenom=lookup_widget(prfilkine,"prenomkine");
labeljour=lookup_widget(prfilkine,"jourkine");
labelmois=lookup_widget(prfilkine,"moiskine");
labelannee=lookup_widget(prfilkine,"anneekine");
labeladress=lookup_widget(prfilkine,"adresskine");
labelnum=lookup_widget(prfilkine,"phonekine");
labelCIN=lookup_widget(prfilkine,"CINkine");
labelpass=lookup_widget(prfilkine,"passkine");

gtk_label_set_text(GTK_LABEL(labelnom),A.nom);
gtk_label_set_text(GTK_LABEL(labelprenom),A.prenom);
gtk_label_set_text(GTK_LABEL(labelCIN),A.cin);
gtk_label_set_text(GTK_LABEL(labeljour),A.jour);
gtk_label_set_text(GTK_LABEL(labelmois),A.mois);
gtk_label_set_text(GTK_LABEL(labelannee),A.annee);
gtk_label_set_text(GTK_LABEL(labeladress),A.adress);
gtk_label_set_text(GTK_LABEL(labelnum),A.num);
gtk_label_set_text(GTK_LABEL(labelpass),A.pass);
fclose(f);

}


void
on_reclamationkine_clicked             (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *reclamationkine;
reclamationkine=create_reclamationkine();
gtk_widget_show(reclamationkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"espkine")));
}


void
on_decnxkine_clicked                   (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *connect;
connect=create_connect();
gtk_widget_show(connect);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"espkine")));
}
void
on_retrnrecl2_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *reclamationkine;
reclamationkine=create_reclamationkine();
gtk_widget_show(reclamationkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationenvoi")));

}



void
on_afficherdvkine_clicked              (GtkWidget       *button,
                                        gpointer         user_data)
{


GtkWidget *input;
char s[30];
char cin1[20],nom1[20],jour1[20],quand1[20],comment1[20];

char chemin[]="rendez_vous_adherent.txt";
input=lookup_widget(gestseancecure,"entryadherentrecherche");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(input)));
GtkWidget *gestrdvkine;
gestrdvkine=create_gestrdvkine();
gtk_widget_show(gestrdvkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"gestseancecure")));

GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;

FILE*f;
f=fopen(chemin,"a+");
if(f!=NULL)
{
while (fscanf(f,"%s %s %s %s %s\n",cin1,nom1,jour1,quand1,comment1)!=EOF)
{

if(strcmp(s,cin1)==0)
{



input1=lookup_widget(gestrdvkine,"cinadherent");
input2=lookup_widget(gestrdvkine,"nomadherent");
input3=lookup_widget(gestrdvkine,"jouradherent");
input4=lookup_widget(gestrdvkine,"quandkine");
input5=lookup_widget(gestrdvkine,"commentkine");



gtk_label_set_text(GTK_LABEL(input1),cin1);

gtk_label_set_text(GTK_LABEL(input2),nom1);

gtk_label_set_text(GTK_LABEL(input3),jour1);

gtk_label_set_text(GTK_LABEL(input4),quand1);

gtk_label_set_text(GTK_LABEL(input5),comment1);




}}



fclose(f);}
}



void
on_retrnprfilkine_clicked              (GtkWidget       *button,
                                        gpointer         user_data)
{
id A;

char chemin[]="listekine.txt";
GtkWidget *prfilkine;
prfilkine=create_prfilkine();
gtk_widget_show(prfilkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"modifprfilkine")));
GtkWidget *labelnom;
GtkWidget *labelprenom;
GtkWidget *labelCIN;
GtkWidget *labeljour;
GtkWidget *labelmois;
GtkWidget *labelannee;
GtkWidget *labeladress;
GtkWidget *labelnum;
GtkWidget *labelpass;
GtkWidget *labelrole;
int i=1;
FILE*f;
f=fopen(chemin,"a+");
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %d\n",A.cin,A.nom,A.prenom,A.jour,A.mois,A.annee,A.adress,A.num,A.pass,&A.role)!=EOF)
{

}
labelnom=lookup_widget(prfilkine,"nomkine");
labelprenom=lookup_widget(prfilkine,"prenomkine");
labeljour=lookup_widget(prfilkine,"jourkine");
labelmois=lookup_widget(prfilkine,"moiskine");
labelannee=lookup_widget(prfilkine,"anneekine");
labeladress=lookup_widget(prfilkine,"adresskine");
labelnum=lookup_widget(prfilkine,"phonekine");
labelCIN=lookup_widget(prfilkine,"CINkine");
labelpass=lookup_widget(prfilkine,"passkine");

gtk_label_set_text(GTK_LABEL(labelnom),A.nom);
gtk_label_set_text(GTK_LABEL(labelprenom),A.prenom);
gtk_label_set_text(GTK_LABEL(labelCIN),A.cin);
gtk_label_set_text(GTK_LABEL(labeljour),A.jour);
gtk_label_set_text(GTK_LABEL(labelmois),A.mois);
gtk_label_set_text(GTK_LABEL(labelannee),A.annee);
gtk_label_set_text(GTK_LABEL(labeladress),A.adress);
gtk_label_set_text(GTK_LABEL(labelnum),A.num);
gtk_label_set_text(GTK_LABEL(labelpass),A.pass);
fclose(f);
}



void
on_retrnespkinerec_clicked             (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *reclamationkine;
reclamationkine=create_reclamationkine();
gtk_widget_show(reclamationkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"succreclenvoi")));
}


void
on_retrnenvoirecl_clicked              (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *reclamationenvoi;
reclamationenvoi=create_reclamationenvoi();
gtk_widget_show(reclamationenvoi);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"failenvoirec")));
}


void
on_cancelbutton_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *espkine;
espkine=create_espkine();
gtk_widget_show(espkine);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"horairetravail")));
}


void
on_okbuttonsave_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
char jour[20],de[20],a[20];
GtkWidget *inputjour;
GtkWidget *inputde;
GtkWidget *inputa;
char chemin[]="horairetravailkine.txt";
inputjour=lookup_widget(button,"comboboxentryjour");
strcpy(jour,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputjour)));
inputde=lookup_widget(button,"comboboxentrycommence");
strcpy(de,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputde)));
inputa=lookup_widget(button,"comboboxentryfini");
strcpy(a,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputa)));
FILE*f;
f=fopen(chemin,"a+");
fprintf(f,"%s %s %s\n",jour,de,a);
fclose(f);
}


void
on_affichefichemedi_clicked            (GtkWidget      *button,
                                        gpointer         user_data)
{
fiche A;
char s[30];
affichefichemed=create_affichefichemed();
gtk_widget_show(affichefichemed);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"fichemede")));
GtkWidget *input;
input=lookup_widget(fichemede,"entryficherecherche");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(input)));

{
FILE*f;
f=fopen("fichemed.txt","a+");
if(f!=NULL)
{
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s\n",A.cin,A.nom,A.prenom,A.age,A.poids,A.taille,A.fumeur,A.alcoolic,A.maladie,A.sang,A.blessure)!=EOF)
{


if(strcmp(s,A.cin)==0)

{

GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget *input6;
GtkWidget *input7;
GtkWidget *input8;
GtkWidget *input9;
GtkWidget *input10;
GtkWidget *input11;
input1=lookup_widget(affichefichemed,"cinkine");
input2=lookup_widget(affichefichemed,"nomkine");
input3=lookup_widget(affichefichemed,"prenomkine");
input4=lookup_widget(affichefichemed,"datekine");
input5=lookup_widget(affichefichemed,"pointurekine");
input6=lookup_widget(affichefichemed,"contactkine");
input7=lookup_widget(affichefichemed,"fumekine");
input8=lookup_widget(affichefichemed,"alcoolkine");
input9=lookup_widget(affichefichemed,"maladiekine");
input10=lookup_widget(affichefichemed,"sangkine");
input11=lookup_widget(affichefichemed,"blessurekine");

gtk_label_set_text(GTK_LABEL(input1),A.cin);

gtk_label_set_text(GTK_LABEL(input2),A.nom);

gtk_label_set_text(GTK_LABEL(input3),A.prenom);

gtk_label_set_text(GTK_LABEL(input4),A.age);

gtk_label_set_text(GTK_LABEL(input5),A.poids);

gtk_label_set_text(GTK_LABEL(input6),A.taille);

gtk_label_set_text(GTK_LABEL(input7),A.fumeur);

gtk_label_set_text(GTK_LABEL(input8),A.alcoolic);

gtk_label_set_text(GTK_LABEL(input9),A.maladie);

gtk_label_set_text(GTK_LABEL(input10),A.sang);

gtk_label_set_text(GTK_LABEL(input11),A.blessure);


}
}
fclose(f);
}

}

}


void
on_retrnfichemed_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1;


fichemede=lookup_widget(button,"fichemede");
fichemede=create_fichemede();
gtk_widget_show(fichemede);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"affichefichemed")));
treeview1=lookup_widget(fichemede,"treeviewfichemed");
afficher_fichemed(treeview1);

}



void
on_prfilagent_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
id A;

char chemin[]="listeagent.txt";
GtkWidget *prfilagent;
prfilagent=create_prfilagent();
gtk_widget_show(prfilagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"espagent")));
GtkWidget *labelnom;
GtkWidget *labelprenom;
GtkWidget *labelCIN;
GtkWidget *labeljour;
GtkWidget *labelmois;
GtkWidget *labelannee;
GtkWidget *labeladress;
GtkWidget *labelnum;
GtkWidget *labelpass;
GtkWidget *labelrole;
int i=1;
FILE*f;
f=fopen(chemin,"a+");
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %d\n",A.cin,A.nom,A.prenom,A.jour,A.mois,A.annee,A.adress,A.num,A.pass,&A.role)!=EOF)
{

}
labelnom=lookup_widget(prfilagent,"nomagent");
labelprenom=lookup_widget(prfilagent,"prenomagent");
labeljour=lookup_widget(prfilagent,"jouragent");
labelmois=lookup_widget(prfilagent,"moisagent");
labelannee=lookup_widget(prfilagent,"anneeagent");
labeladress=lookup_widget(prfilagent,"adressagent");
labelnum=lookup_widget(prfilagent,"phoneagent");
labelCIN=lookup_widget(prfilagent,"CINagent");
labelpass=lookup_widget(prfilagent,"passagent");

gtk_label_set_text(GTK_LABEL(labelnom),A.nom);
gtk_label_set_text(GTK_LABEL(labelprenom),A.prenom);
gtk_label_set_text(GTK_LABEL(labelCIN),A.cin);
gtk_label_set_text(GTK_LABEL(labeljour),A.jour);
gtk_label_set_text(GTK_LABEL(labelmois),A.mois);
gtk_label_set_text(GTK_LABEL(labelannee),A.annee);
gtk_label_set_text(GTK_LABEL(labeladress),A.adress);
gtk_label_set_text(GTK_LABEL(labelnum),A.num);
gtk_label_set_text(GTK_LABEL(labelpass),A.pass);
fclose(f);

}



void
on_recagent_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *reclamationagent;
reclamationagent=create_reclamationagent();
gtk_widget_show(reclamationagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"espagent")));
}


void
on_horairetravailagent_clicked         (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *horairetravailagent;
horairetravailagent=create_horairetravailagent();
gtk_widget_show(horairetravailagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"espagent")));
}


void
on_exit2_clicked                       (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *connect;
connect=create_connect();
gtk_widget_show(connect);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"espagent")));
}

void
on_modifprfilagent_clicked             (GtkWidget      *button,
                                        gpointer         user_data)
{

id A;
char chemin[]="listeagent.txt";
GtkWidget *modifprofilagent;

modifprofilagent=create_modifprofilagent();
gtk_widget_show(modifprofilagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"prfilagent")));
int i=1;

FILE*f;
f=fopen(chemin,"a+");

while(fscanf(f,"%s %s %s %s %s %s %s %s %s %d\n",A.cin,A.nom,A.prenom,A.jour,A.mois,A.annee,A.adress,A.num,A.pass,&A.role)!=EOF)
{i++;
}
GtkWidget *labelnom;
GtkWidget *labelprenom;
GtkWidget *labelCIN;
GtkWidget *labeljour;
GtkWidget *labelmois;
GtkWidget *labelannee;
GtkWidget *labeladress;
GtkWidget *labelnum;
GtkWidget *labelpass;
GtkWidget *labelrole;

labelnom=lookup_widget(modifprofilagent,"nomagent");
labelprenom=lookup_widget(modifprofilagent,"prenomagent");
labeljour=lookup_widget(modifprofilagent,"jouragent");
labelmois=lookup_widget(modifprofilagent,"moisagent");
labelannee=lookup_widget(modifprofilagent,"anneeagent");
labeladress=lookup_widget(modifprofilagent,"entryadressagent");
labelnum=lookup_widget(modifprofilagent,"entrynumagent");
labelCIN=lookup_widget(modifprofilagent,"CINagent");
labelpass=lookup_widget(modifprofilagent,"entrypassagent");

gtk_label_set_text(GTK_LABEL(labelnom),A.nom);
gtk_label_set_text(GTK_LABEL(labelprenom),A.prenom);
gtk_label_set_text(GTK_LABEL(labelCIN),A.cin);
gtk_label_set_text(GTK_LABEL(labeljour),A.jour);
gtk_label_set_text(GTK_LABEL(labelmois),A.mois);
gtk_label_set_text(GTK_LABEL(labelannee),A.annee);
gtk_entry_set_text(GTK_ENTRY(labeladress),A.adress);
gtk_entry_set_text(GTK_ENTRY(labelnum),A.num);
gtk_entry_set_text(GTK_ENTRY(labelpass),A.pass);

fclose(f);


}


void
on_retrnespagent1_clicked              (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *espagent;
espagent=create_espagent();
gtk_widget_show(espagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"prfilagent")));
}


void
on_retrnprfilagent_clicked             (GtkWidget      *button,
                                        gpointer         user_data)
{

id A;

char chemin[]="listeagent.txt";
GtkWidget *prfilagent;

prfilagent=create_prfilagent();
gtk_widget_show(prfilagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"modifprofilagent")));
GtkWidget *labelnom;
GtkWidget *labelprenom;
GtkWidget *labelCIN;
GtkWidget *labeljour;
GtkWidget *labelmois;
GtkWidget *labelannee;
GtkWidget *labeladress;
GtkWidget *labelnum;
GtkWidget *labelpass;
GtkWidget *labelrole;
int i=1;
FILE*f;
f=fopen(chemin,"a+");
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %d\n",A.cin,A.nom,A.prenom,A.jour,A.mois,A.annee,A.adress,A.num,A.pass,&A.role)!=EOF)
{

}
labelnom=lookup_widget(prfilagent,"nomagent");
labelprenom=lookup_widget(prfilagent,"prenomagent");
labeljour=lookup_widget(prfilagent,"jouragent");
labelmois=lookup_widget(prfilagent,"moisagent");
labelannee=lookup_widget(prfilagent,"anneeagent");
labeladress=lookup_widget(prfilagent,"adressagent");
labelnum=lookup_widget(prfilagent,"phoneagent");
labelCIN=lookup_widget(prfilagent,"CINagent");
labelpass=lookup_widget(prfilagent,"passagent");

gtk_label_set_text(GTK_LABEL(labelnom),A.nom);
gtk_label_set_text(GTK_LABEL(labelprenom),A.prenom);
gtk_label_set_text(GTK_LABEL(labelCIN),A.cin);
gtk_label_set_text(GTK_LABEL(labeljour),A.jour);
gtk_label_set_text(GTK_LABEL(labelmois),A.mois);
gtk_label_set_text(GTK_LABEL(labelannee),A.annee);
gtk_label_set_text(GTK_LABEL(labeladress),A.adress);
gtk_label_set_text(GTK_LABEL(labelnum),A.num);
gtk_label_set_text(GTK_LABEL(labelpass),A.pass);
fclose(f);

}



void
on_saveagent_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
id A;

char chemin[]="listeagent.txt";
GtkWidget *espagent;
espagent=create_espagent();
gtk_widget_show(espagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"modifprofilagent")));
GtkWidget *labelnom;
GtkWidget *labelprenom;
GtkWidget *labelCIN;
GtkWidget *labeljour;
GtkWidget *labelmois;
GtkWidget *labelannee;
GtkWidget *labeladress;
GtkWidget *labelnum;
GtkWidget *labelpass;
GtkWidget *labelrole;
int i=1;

labelnom=lookup_widget(button,"nomagent");
labelprenom=lookup_widget(button,"prenomagent");
labeljour=lookup_widget(button,"jouragent");
labelmois=lookup_widget(button,"moisagent");
labelannee=lookup_widget(button,"anneeagent");
labeladress=lookup_widget(button,"entryadressagent");
labelnum=lookup_widget(button,"entrynumagent");
labelCIN=lookup_widget(button,"CINagent");
labelpass=lookup_widget(button,"entrypassagent");

strcpy(A.nom,gtk_label_get_text(GTK_LABEL(labelnom)));
strcpy(A.prenom,gtk_label_get_text(GTK_LABEL(labelprenom)));
strcpy(A.cin,gtk_label_get_text(GTK_LABEL(labelCIN)));
strcpy(A.jour,gtk_label_get_text(GTK_LABEL(labeljour)));
strcpy(A.mois,gtk_label_get_text(GTK_LABEL(labelmois)));
strcpy(A.annee,gtk_label_get_text(GTK_LABEL(labelannee)));
strcpy(A.adress,gtk_entry_get_text(GTK_ENTRY(labeladress)));
strcpy(A.num,gtk_entry_get_text(GTK_ENTRY(labelnum)));
strcpy(A.pass,gtk_entry_get_text(GTK_ENTRY(labelpass)));
FILE*f;
f=fopen(chemin,"a+");
fprintf(f,"%s %s %s %s %s %s %s %s %s 6 \n",A.cin,A.nom,A.prenom,A.jour,A.mois,A.annee,A.adress,A.num,A.pass);
fclose(f);
}



void
on_reclmtionagentenvoi_clicked         (GtkWidget       *button,
                                        gpointer         user_data)

{
GtkWidget *reclamationenvoiagent;
reclamationenvoiagent=create_reclamationenvoiagent();
gtk_widget_show(reclamationenvoiagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationagent")));
}




void
on_reclmtionagentrecu_clicked          (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *reclamationrecuagent;
reclamationrecuagent=create_reclamationrecuagent();
gtk_widget_show(reclamationrecuagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationagent")));
int i=1;
char chemin[]="recla_agent.txt";
GtkWidget *labelrecu;
char cont[300];
FILE*f;
f=fopen(chemin,"a+");
while(fscanf(f,"%s \n",cont)!=EOF)
{
i++;
}
labelrecu=lookup_widget(reclamationrecuagent,"reclagentrecu");
gtk_label_set_text(GTK_LABEL(labelrecu),cont);
fclose(f);

}


void
on_retrnespagent2_clicked              (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *espagent;
espagent=create_espagent();
gtk_widget_show(espagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationagent")));
}


void
on_retrnreclagent1_clicked             (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *reclamationagent;
reclamationagent=create_reclamationagent();
gtk_widget_show(reclamationagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationrecuagent")));
}


void
on_retrnreclagent2_clicked             (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *reclamationagent;
reclamationagent=create_reclamationagent();
gtk_widget_show(reclamationagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationenvoiagent")));
}



void
on_okbuttonagent_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{
char jour[20],de[20],a[20];
GtkWidget *inputjour;
GtkWidget *inputde;
GtkWidget *inputa;
char chemin[]="horairetravailagent.txt";
inputjour=lookup_widget(button,"comboboxentryjour");
strcpy(jour,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputjour)));
inputde=lookup_widget(button,"comboboxentrycommence");
strcpy(de,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputde)));
inputa=lookup_widget(button,"comboboxentryfini");
strcpy(a,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputa)));
FILE*f;
f=fopen(chemin,"a+");
fprintf(f,"%s %s %s\n",jour,de,a);
fclose(f);

}


void
on_retrnespagent4_clicked              (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *espagent;
espagent=create_espagent();
gtk_widget_show(espagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"horairetravailagent")));
}


void
on_envoireclagent_clicked              (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *inputreclama;
GtkWidget *inputdest;
char dest[40],cont[100];
inputreclama=lookup_widget(button,"comboboxentryenvoi");
strcpy(dest,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inputreclama)));
inputdest=lookup_widget(button,"entrycontenuagent");
strcpy(cont,gtk_entry_get_text(GTK_ENTRY(inputdest)));
if (strcmp(dest,"Agent de Nétoyage")==0)
{
FILE *f1;
f1=fopen("recla_agent.txt","a+");
fprintf(f1,"%s \n",cont);
fclose(f1);
}
else if (strcmp(dest,"Coach")==0)
{
FILE *f2;
f2=fopen("recla_coach.txt","a+");
fprintf(f2,"%s \n",cont);
fclose(f2);
}
else if (strcmp(dest,"Kinésithérapeute")==0)
{
FILE *f3;
f3=fopen("recla_kine.txt","a+");
fprintf(f3,"%s \n",cont);
fclose(f3);
}
else if (strcmp(dest,"Diététicien")==0)
{
FILE *f4;
f4=fopen("recla_diet.txt","a+");
fprintf(f4,"%s \n",cont);
fclose(f4);
}
else if (strcmp(dest,"Médecin Nutritioniste")==0)
{
FILE *f5;
f5=fopen("recla_docteur.txt","a+");
fprintf(f5,"%s \n",cont);
fclose(f5);
}
if (cont != " " && dest != " ")
{
GtkWidget *succreclagent;
succreclagent=create_succreclagent();
gtk_widget_show(succreclagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationenvoiagent")));
}
else
{
GtkWidget *failreclagent;
failreclagent=create_failreclagent();
gtk_widget_show(failreclagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationenvoiagent")));
}
}

void
on_retrnreclagent3_clicked             (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *reclamationagent;
reclamationagent=create_reclamationagent();
gtk_widget_show(reclamationagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"succreclagent")));
}


void
on_retrnreclagent4_clicked             (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *reclamationagent;
reclamationagent=create_reclamationagent();
gtk_widget_show(reclamationagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"failreclagent")));
}
void
on_retrnreclagent_clicked             (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *reclamationagent;
reclamationagent=create_reclamationagent();
gtk_widget_show(reclamationagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"reclamationrecuagent")));
}





