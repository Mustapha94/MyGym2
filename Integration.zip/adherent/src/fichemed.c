#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <string.h>
#include "fichemed.h"
#include <gtk/gtk.h>

enum
{	
	CIN,
	NOM,
	PRENOM,
	AGE,
	POIDS,
	TAILLE,
	FUMEUR,
	ALCOOLIC,
	MALADIE,
	SANG,
	BLESSURE,
	COLUMNS

};

void afficher_fichemed(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter  iter;
GtkListStore *store;

char cin[20];
char nom[20];
char prenom[20];
char age[20];
char poids[20];
char taille[20];
char fumeur[20];
char alcoolic[20];
char maladie[20];
char sang[20];
char blessure[20];

store=NULL;

FILE *f;
//store=GTK_LIST_STORE(gtk_tree_view_get_model(GTK_TREE_VIEW(liste)));

if(store==NULL)
{
	renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" cin",renderer,"text",CIN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" age",renderer,"text",AGE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" poids",renderer,"text",POIDS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" taille",renderer,"text",TAILLE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" fumeur",renderer,"text",FUMEUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" alcoolic",renderer,"text",ALCOOLIC,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" maladie",renderer,"text",MALADIE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" sang",renderer,"text",SANG,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" blessure",renderer,"text",BLESSURE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("fichemed.txt","a+");
if(f==NULL)
{
return;
}
else
{
//f=fopen("fichemed.txt","a+");
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s \n",cin,nom,prenom,age,poids,taille,fumeur,alcoolic,maladie,sang,blessure) !=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,CIN,cin,NOM,nom,PRENOM,prenom,AGE,age,POIDS,poids,TAILLE,taille,FUMEUR,fumeur,ALCOOLIC,alcoolic,MALADIE,maladie,SANG,sang,BLESSURE,blessure,  -1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
//****************************************************************
enum
{

	CIN2,
	NOM2,
	PRENOM2,
	JOUR2,
	MOIS2,
	ANNEE2,
	ADRESS2,
	NUM2,
	PWD2,
	ROLE2,
	COLUMNS2

};

void afficher_adherents(GtkWidget *liste)
{
	char cin[20];
	char nom[20];
	char prenom[20];
	char jour[20];
	char mois[20];
	char annee[20];
	char adress[20];
	char num[20];
	char pass[20];
	char role[20];
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	store=NULL;
	FILE *f5;
	
	//store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
	if(store==NULL)
	{
	renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  CIN ",renderer,"text",CIN2,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		
	renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Nom de l'adhérent  ",renderer,"text",NOM2,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

	renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  Prénom  ",renderer,"text",PRENOM2,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


	renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  JOUR ",renderer,"text",JOUR2,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


	renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes(" MOIS ",renderer,"text",MOIS2,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

	renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  ANNEE ",renderer,"text",ANNEE2,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	
	renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  ADRESS ",renderer,"text",ADRESS2,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	
	renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  NUM",renderer,"text",NUM2,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

	renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("   PASSE",renderer,"text",PWD2,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	
	renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("  ROLE",renderer,"text",ROLE2,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

}


	store=gtk_list_store_new(COLUMNS2,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);



f5=fopen("listeadherents.txt","a+");
if(f5==NULL)
{return;
}
	 //f1=fopen("listeadherent.txt","a+");
else{
		while(fscanf(f5,"%s %s %s %s %s %s %s %s %s %s\n",cin,nom,prenom,jour,mois,annee,adress,num,pass,role)!=EOF)
	{   

		gtk_list_store_append(store, &iter);
				gtk_list_store_set(store,&iter,CIN2,cin,NOM2,nom,PRENOM2,prenom,JOUR2,jour,MOIS2,mois,ANNEE2,annee,ADRESS2,adress,NUM2,num,PWD2,pass,ROLE2,role, -1);
	  
}
	   fclose(f5);
}	gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
	g_object_unref(store);
	
}










