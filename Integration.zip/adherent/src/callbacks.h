#include <gtk/gtk.h>


void
on_button1_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_exit_clicked                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_modif_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_dispo_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);



void
on_retrn_clicked                       (GtkWidget        *button,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_save_clicked                        (GtkWidget        *button,
                                        gpointer         user_data);

void
on_retrnprfil1_clicked                 (GtkWidget    *button,
                                        gpointer         user_data);

void
on_retrnesp1_clicked                   (GtkWidget        *button,
                                        gpointer         user_data);

void
on_retrnesp2_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnprfil2_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnesp3_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_continue1_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonprfil_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttongym_clicked                   (GtkWidget      *button,
                                        gpointer         user_data);

void
on_buttonavis_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonmedi_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttongym1_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttongym2_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttongym3_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttongym4_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttoncal5_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnimc_clicked                    (GtkWidget        *button,
                                        gpointer         user_data);

void
on_buttonrecla2_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonavis3_clicked                 (GtkWidget      *button,
                                        gpointer         user_data);

void
on_retrnreclama_clicked                (GtkWidget        *button,
                                        gpointer         user_data);

void
on_buttonenvoi3_enter                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiobutton1_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiobutton2_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiobutton2officiel_clicked        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiobutton3_clicked                (GtkWidget      *button,
                                        gpointer         user_data);

void
on_radiobutton4_clicked                (GtkWidget      *button,
                                        gpointer         user_data);

void
on_rtrnaviss_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radioc6_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radioc7_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radioc9_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radioc10_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radioc8_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiok6_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiok8_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiok9_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiok10_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiok7_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiomed3_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiomed15_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiomed6_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiomed12_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiomed14_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_prflcoac_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_prflkin_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_prflmede_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_rnd3_clicked                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_rnd2_clicked                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_rnd1_clicked                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrncoa_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnkine1_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_rtrnmede4_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_rndv14_clicked                      (GtkWidget       *button,
                                        gpointer         user_data);

void
on_rndvkine1_clicked                   (GtkWidget     *button,
                                        gpointer         user_data);

void
on_rndvmedecin1_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_rtrntab_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_rtrnadvice_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);




void
on_retrn1111_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_login_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);


void
on_exit1_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_fichemed_clicked                    (GtkWidget      *button,
                                        gpointer         user_data);

void
on_gestcure_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);


void
on_savekine_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnespkine2_clicked               (GtkWidget      *button,
                                        gpointer         user_data);

void
on_retrnespkine3_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_reclmtionrecu_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_reclmtionenvoi_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnrecl_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_envoirecl_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnespkine4_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrngestcure_clicked               (GtkWidget      *button,
                                        gpointer         user_data);

void
on_retrnespkine5_clicked               (GtkWidget     *button,
                                        gpointer         user_data);

void
on_modifprfil_clicked                  (GtkWidget      *button,
                                        gpointer         user_data);

void
on_horairetravailkine_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_prfilkine_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_reclamationkine_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_decnxkine_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnrecl2_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);


void
on_afficherdvkine_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnprfilkine_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_affichefichemed_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnfichemed_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnespkinerec_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnenvoirecl_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_cancelbutton_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_okbuttonsave_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_affichefichemedi_clicked            (GtkWidget      *button,
                                        gpointer         user_data);

void
on_retrnfichemed_clicked               (GtkWidget       *button,
                                        gpointer         user_data);



void
on_prfilagent_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_recagent_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_horairetravailagent_clicked         (GtkWidget      *button,
                                        gpointer         user_data);

void
on_exit2_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_modifprfilagent_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnespagent1_clicked              (GtkWidget      *button,
                                        gpointer         user_data);

void
on_retrnprfilagent_clicked             (GtkWidget      *button,
                                        gpointer         user_data);

void
on_saveagent_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_reclmtionagentenvoi_clicked         (GtkWidget       *button,
                                        gpointer         user_data);

void
on_reclmtionagentrecu_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnespagent2_clicked              (GtkWidget      *button,
                                        gpointer         user_data);

void
on_retrnreclagent1_clicked             (GtkWidget      *button,
                                        gpointer         user_data);

void
on_retrnreclagent2_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_okbuttonagent_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnespagent4_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnreclagent3_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retrnreclagent4_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_envoireclagent_clicked              (GtkWidget      *button,
                                        gpointer         user_data);

void
on_envoireclagent_clicked              (GtkWidget      *button,
                                        gpointer         user_data);
void
on_retrnreclagent_clicked             (GtkWidget       *button,
                                        gpointer         user_data);



