#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int Authent(char login[],char password[])
{ FILE *f;
char login1[20],password1[20] ;
int role ;
f=fopen("personne.txt","r");
while(fscanf(f,"%s %s %d ",login1,password1,&role)!=EOF)
{
if( strcmp(login,login1)==0 && strcmp ( password1, password)==0)
{
fclose(f);
return role ;}
}
fclose(f);
return -1;
}
