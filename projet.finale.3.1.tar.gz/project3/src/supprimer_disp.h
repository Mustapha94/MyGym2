#include <gtk/gtk.h>

void sup_dispo(char a[30]);
