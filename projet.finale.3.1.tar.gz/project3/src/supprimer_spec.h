#include <gtk/gtk.h>

void sup_speci(char a[20]);
