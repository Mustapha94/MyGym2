#include <gtk/gtk.h>


typedef struct
{

char s[20];


}spec;


void ajou_specialite (spec s);
void afficher_specialite(GtkWidget *list);

