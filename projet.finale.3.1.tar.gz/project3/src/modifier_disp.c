#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif


#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Disponibilite.h"
#include "modifier_disp.h"



void modif_dispo(dispon p)//parametre mte3na
{
	FILE *f;
	FILE *ftemp;
	FILE *file_ptr;
	dispon x;
	f=fopen("Disponibilite.txt","r");
	ftemp=fopen("Disponibilite.tmp","w");
	if (f!=NULL)
	{
    		while(fscanf(f,"%s %s %s\n",x.jour,x.debut,x.fin)!=EOF)//na9raw il fichier mte3na
    		{
      			if(strcmp(p.jour,x.jour)!=0){//ken il parametre different mil ligne na3mlou copie mak i ligne fil fichier ejdid
        			fprintf(ftemp,"%s %s %s\n",x.jour,x.debut,x.fin);}

      			else{//ken il parametre kima i ligne ili na9rawfeha nwaliw najoutiw i ligne iliejdida w na79rou le9dima mehech rajel
        			fprintf(ftemp,"%s %s %s\n",p.jour,p.debut,p.fin);//l ajout mta3 i ligne elmodifier fel fichier ijdid
         	}
	}
}
	fclose(f);
	fclose(ftemp);
	remove("Disponibilite.txt");//nfaskhou ilfichier lasleni 
	rename("Disponibilite.tmp","Disponibilite.txt");//nranomiw il fichier ejdid besm li9dim bech ye5ou blastou
}
