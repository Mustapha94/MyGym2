#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif




#include <stdio.h>
#include <string.h>
#include "specialitee.h"
#include <gtk/gtk.h>

enum   
{       
        S,
	COLUMNS
        
};

void ajou_specialite (spec s)
{	
	FILE *f;
  	f=fopen("specialitee.txt","a+");
  	if(f!=NULL) 
  	{
  		fprintf(f,"%s\n", s.s);
  		fclose(f);
	}
}

//Afficher specialite


void afficher_specialite(GtkWidget *list)
{
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;

	char s [30];
        store=NULL;

       FILE *f;
	
	store=gtk_tree_view_get_model(list);	
	if (store==NULL)
	{

                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("specialitée", renderer,"text",S, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (list), column);               
	
	}

	
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING);

	f = fopen("specialitee.txt", "r");
	
	if(f==NULL)
	{

		return;
	}		
	else 

	{ f = fopen("specialitee.txt", "a+");
              while(fscanf(f,"%s \n",s)!=EOF)
		{
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter, S,s, -1); 
		}
		fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (list),  GTK_TREE_MODEL (store));
    g_object_unref (store);
	}
}

