#include <gtk/gtk.h>

typedef struct
{

char jour[20];
char debut[20];
char fin[30];


}dispo;

void ajou_disponibilite(dispo p);
void afficher_disponibilite(GtkWidget *list);
